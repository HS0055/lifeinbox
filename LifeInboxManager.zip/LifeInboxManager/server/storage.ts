import {
  users,
  emails,
  accounts,
  transactions,
  notes,
  accountConnections,
  type User,
  type UpsertUser,
  type Email,
  type InsertEmail,
  type Account,
  type InsertAccount,
  type Transaction,
  type InsertTransaction,
  type Note,
  type InsertNote,
  type AccountConnection,
  type InsertAccountConnection,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Account Connection operations
  createAccountConnection(connection: InsertAccountConnection): Promise<AccountConnection>;
  getAccountConnection(userId: string, provider: string): Promise<AccountConnection | undefined>;
  updateAccountConnection(id: number, data: Partial<InsertAccountConnection>): Promise<AccountConnection>;
  
  // Email operations
  createEmail(email: InsertEmail): Promise<Email>;
  getEmails(userId: string, limit?: number): Promise<Email[]>;
  getEmailById(id: number): Promise<Email | undefined>;
  updateEmail(id: number, data: Partial<InsertEmail>): Promise<Email>;
  getUnreadEmailCount(userId: string): Promise<number>;
  
  // Account operations
  createAccount(account: InsertAccount): Promise<Account>;
  getAccounts(userId: string): Promise<Account[]>;
  updateAccount(id: number, data: Partial<InsertAccount>): Promise<Account>;
  
  // Transaction operations
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactions(userId: string, limit?: number): Promise<Transaction[]>;
  getRecentTransactions(userId: string, limit?: number): Promise<Transaction[]>;
  
  // Note operations
  createNote(note: InsertNote): Promise<Note>;
  getNotes(userId: string, status?: string): Promise<Note[]>;
  getNote(id: number): Promise<Note | undefined>;
  updateNote(id: number, data: Partial<InsertNote>): Promise<Note>;
  deleteNote(id: number): Promise<void>;
  getActiveNotesCount(userId: string): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  // User operations (IMPORTANT) these user operations are mandatory for Replit Auth.
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Account Connection operations
  async createAccountConnection(connection: InsertAccountConnection): Promise<AccountConnection> {
    const [result] = await db.insert(accountConnections).values(connection).returning();
    return result;
  }

  async getAccountConnection(userId: string, provider: string): Promise<AccountConnection | undefined> {
    const [connection] = await db
      .select()
      .from(accountConnections)
      .where(and(eq(accountConnections.userId, userId), eq(accountConnections.provider, provider)));
    return connection;
  }

  async updateAccountConnection(id: number, data: Partial<InsertAccountConnection>): Promise<AccountConnection> {
    const [updated] = await db
      .update(accountConnections)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(accountConnections.id, id))
      .returning();
    return updated;
  }

  // Email operations
  async createEmail(email: InsertEmail): Promise<Email> {
    const [result] = await db.insert(emails).values(email).returning();
    return result;
  }

  async getEmails(userId: string, limit = 50): Promise<Email[]> {
    return await db
      .select()
      .from(emails)
      .where(eq(emails.userId, userId))
      .orderBy(desc(emails.receivedAt))
      .limit(limit);
  }

  async getEmailById(id: number): Promise<Email | undefined> {
    if (!id || isNaN(id) || id <= 0) {
      console.error("Invalid email ID provided:", id);
      return undefined;
    }
    const [email] = await db.select().from(emails).where(eq(emails.id, id));
    return email;
  }

  async updateEmail(id: number, data: Partial<InsertEmail>): Promise<Email> {
    const [updated] = await db
      .update(emails)
      .set(data)
      .where(eq(emails.id, id))
      .returning();
    return updated;
  }

  async getUnreadEmailCount(userId: string): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(emails)
      .where(and(eq(emails.userId, userId), eq(emails.isRead, false)));
    return result.count;
  }

  // Account operations
  async createAccount(account: InsertAccount): Promise<Account> {
    const [result] = await db.insert(accounts).values(account).returning();
    return result;
  }

  async getAccounts(userId: string): Promise<Account[]> {
    return await db
      .select()
      .from(accounts)
      .where(eq(accounts.userId, userId))
      .orderBy(accounts.name);
  }

  async updateAccount(id: number, data: Partial<InsertAccount>): Promise<Account> {
    const [updated] = await db
      .update(accounts)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(accounts.id, id))
      .returning();
    return updated;
  }

  // Transaction operations
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [result] = await db.insert(transactions).values(transaction).returning();
    return result;
  }

  async getTransactions(userId: string, limit = 100): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.transactionDate))
      .limit(limit);
  }

  async getRecentTransactions(userId: string, limit = 10): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.transactionDate))
      .limit(limit);
  }

  // Note operations
  async createNote(note: InsertNote): Promise<Note> {
    const [result] = await db.insert(notes).values(note).returning();
    return result;
  }

  async getNotes(userId: string, status?: string): Promise<Note[]> {
    if (status) {
      return await db
        .select()
        .from(notes)
        .where(and(eq(notes.userId, userId), eq(notes.status, status)))
        .orderBy(desc(notes.createdAt));
    }
    
    return await db
      .select()
      .from(notes)
      .where(eq(notes.userId, userId))
      .orderBy(desc(notes.createdAt));
  }

  async getNote(id: number): Promise<Note | undefined> {
    const [note] = await db.select().from(notes).where(eq(notes.id, id));
    return note;
  }

  async updateNote(id: number, data: Partial<InsertNote>): Promise<Note> {
    const [updated] = await db
      .update(notes)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(notes.id, id))
      .returning();
    return updated;
  }

  async deleteNote(id: number): Promise<void> {
    await db.delete(notes).where(eq(notes.id, id));
  }

  async getActiveNotesCount(userId: string): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(notes)
      .where(and(eq(notes.userId, userId), eq(notes.status, "active")));
    return result.count;
  }
}

export const storage = new DatabaseStorage();

import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Smart urgent email detection with heuristics + AI
export class UrgentEmailDetector {
  private promoKeywords = [
    'promotion', 'bonus', 'exclusive offer', 'win now', 'casino promo', 
    'limited time', 'act now', 'special deal', 'discount', 'sale',
    'free gift', 'congratulations', 'winner', 'jackpot', 'prize'
  ];

  private urgentKeywords = [
    'payment due', 'action required', 'account suspended', 'verify your identity',
    'security alert', 'suspicious activity', 'deadline', 'expires today',
    'immediate action', 'urgent', 'overdue', 'final notice', 'warning',
    'account locked', 'verify now', 'confirm immediately'
  ];

  private promoSenderPatterns = [
    'promo', 'newsletter', 'marketing', 'deals', 'offers', 'noreply',
    'casino', 'gambling', 'ads', 'promotions', 'campaigns'
  ];

  // Pre-filter emails using heuristics before AI analysis
  private isLikelyPromo(email: any): boolean {
    const sender = email.fromEmail?.toLowerCase() || '';
    const subject = email.subject?.toLowerCase() || '';
    const snippet = email.snippet?.toLowerCase() || '';

    // Check sender patterns
    if (this.promoSenderPatterns.some(pattern => sender.includes(pattern))) {
      return true;
    }

    // Check promo keywords in subject/content
    if (this.promoKeywords.some(keyword => 
      subject.includes(keyword) || snippet.includes(keyword)
    )) {
      return true;
    }

    return false;
  }

  private hasUrgentSignals(email: any): boolean {
    const subject = email.subject?.toLowerCase() || '';
    const snippet = email.snippet?.toLowerCase() || '';

    return this.urgentKeywords.some(keyword =>
      subject.includes(keyword) || snippet.includes(keyword)
    );
  }

  // Analyze emails for urgency using smart heuristics
  async analyzeUrgentEmails(emails: any[]): Promise<{
    urgentEmails: any[];
    totalUrgent: number;
    urgencyBreakdown: {
      financial: number;
      security: number;
      deadlines: number;
      work: number;
    };
  }> {
    try {
      // Step 1: Pre-filter obvious promos
      const nonPromoEmails = emails.filter(email => !this.isLikelyPromo(email));
      
      // Step 2: Find emails with urgent signals using heuristics
      const urgentEmails = nonPromoEmails.filter(email => 
        this.hasUrgentSignals(email) || 
        email.priority === 'high'
      ).map(email => {
        // Categorize urgency based on keywords
        const subject = email.subject?.toLowerCase() || '';
        const snippet = email.snippet?.toLowerCase() || '';
        
        let urgencyCategory = 'work';
        let urgencyReason = 'Contains urgent keywords';
        
        if (subject.includes('payment') || subject.includes('invoice') || subject.includes('bank')) {
          urgencyCategory = 'financial';
          urgencyReason = 'Financial action required';
        } else if (subject.includes('security') || subject.includes('alert') || subject.includes('verify')) {
          urgencyCategory = 'security';
          urgencyReason = 'Security verification needed';
        } else if (subject.includes('deadline') || subject.includes('expires') || subject.includes('due')) {
          urgencyCategory = 'deadline';
          urgencyReason = 'Time-sensitive deadline';
        }
        
        return {
          ...email,
          urgencyReason,
          suggestedAction: 'review',
          urgencyCategory
        };
      });

      // Calculate breakdown
      const urgencyBreakdown = {
        financial: urgentEmails.filter(e => e.urgencyCategory === 'financial').length,
        security: urgentEmails.filter(e => e.urgencyCategory === 'security').length,
        deadlines: urgentEmails.filter(e => e.urgencyCategory === 'deadline').length,
        work: urgentEmails.filter(e => e.urgencyCategory === 'work').length,
      };

      return {
        urgentEmails,
        totalUrgent: urgentEmails.length,
        urgencyBreakdown
      };

    } catch (error) {
      console.error('Error analyzing urgent emails:', error);
      
      return {
        urgentEmails: [],
        totalUrgent: 0,
        urgencyBreakdown: { financial: 0, security: 0, deadlines: 0, work: 0 }
      };
    }
  }

  // Quick urgency check for real-time notifications
  isEmailUrgent(email: any): boolean {
    if (this.isLikelyPromo(email)) return false;
    return this.hasUrgentSignals(email) || email.priority === 'high';
  }
}

export const urgentEmailDetector = new UrgentEmailDetector();
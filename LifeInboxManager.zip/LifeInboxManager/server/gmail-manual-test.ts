import { simpleGmailAuth } from "./gmail-auth";
import { gmailSyncService } from "./gmail-sync";
import { storage } from "./storage";
import { Logger } from "./logger";

// Manual Gmail test with step-by-step validation
export async function testGmailCredentialsAndFlow(): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `manual_test_${Date.now()}`;
  const userId = '41192121'; // Current authenticated user
  
  try {
    console.log('=== Gmail Manual Test Started ===');
    
    // Step 1: Validate environment variables
    const credentials = {
      clientId: process.env.GMAIL_CLIENT_ID,
      clientSecret: process.env.GMAIL_CLIENT_SECRET,
      hasClientId: !!process.env.GMAIL_CLIENT_ID,
      hasClientSecret: !!process.env.GMAIL_CLIENT_SECRET
    };
    
    console.log('Step 1 - Credentials Check:', {
      hasClientId: credentials.hasClientId,
      hasClientSecret: credentials.hasClientSecret,
      clientIdLength: credentials.clientId?.length,
      clientSecretLength: credentials.clientSecret?.length
    });
    
    if (!credentials.hasClientId || !credentials.hasClientSecret) {
      return {
        success: false,
        message: "Gmail credentials missing from environment",
        details: credentials
      };
    }
    
    // Step 2: Test OAuth URL generation
    console.log('Step 2 - OAuth URL Generation');
    const authUrl = simpleGmailAuth.getAuthUrl();
    console.log('Generated OAuth URL:', authUrl.substring(0, 120) + '...');
    
    // Step 3: Check database state
    console.log('Step 3 - Database State Check');
    const existingConnection = await storage.getAccountConnection(userId, 'gmail');
    const currentEmails = await storage.getEmails(userId, 5);
    
    console.log('Database state:', {
      hasConnection: !!existingConnection,
      connectionId: existingConnection?.id,
      connectionStatus: existingConnection?.status,
      emailCount: currentEmails.length,
      isDemoData: currentEmails.some(e => e.gmailId?.startsWith('demo_'))
    });
    
    // Step 4: Test user authentication
    console.log('Step 4 - User Authentication Check');
    const user = await storage.getUser(userId);
    console.log('User data:', {
      exists: !!user,
      email: user?.email,
      id: user?.id
    });
    
    return {
      success: true,
      message: "Gmail manual test completed - credentials valid, OAuth URL generated",
      details: {
        credentials: {
          hasClientId: credentials.hasClientId,
          hasClientSecret: credentials.hasClientSecret
        },
        authUrl: authUrl.substring(0, 150) + '...',
        database: {
          hasConnection: !!existingConnection,
          emailCount: currentEmails.length,
          isDemoData: currentEmails.some(e => e.gmailId?.startsWith('demo_'))
        },
        user: {
          exists: !!user,
          email: user?.email
        },
        nextSteps: [
          "1. Visit OAuth URL to authorize Gmail access",
          "2. Extract authorization code from callback URL",
          "3. Use /api/gmail/exchange endpoint with the code",
          "4. Verify email sync replaces demo data"
        ]
      }
    };
    
  } catch (error) {
    Logger.error("Gmail manual test failed", error, { requestId, userId });
    console.error('Manual test error:', error);
    
    return {
      success: false,
      message: "Gmail manual test failed",
      details: { 
        error: (error as Error).message,
        stack: (error as Error).stack?.substring(0, 300)
      }
    };
  }
}

// Test the complete OAuth exchange manually with a provided code
export async function manualGmailTokenExchange(authCode: string): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `manual_exchange_${Date.now()}`;
  const userId = '41192121';
  
  try {
    console.log('=== Manual Gmail Token Exchange Started ===');
    console.log('Authorization code provided:', authCode.substring(0, 20) + '...');
    
    // Step 1: Exchange code for tokens
    console.log('Step 1 - Token Exchange');
    const tokens = await simpleGmailAuth.exchangeCodeForTokens(authCode);
    
    console.log('Token exchange result:', {
      hasAccessToken: !!tokens.accessToken,
      hasRefreshToken: !!tokens.refreshToken,
      accessTokenStart: tokens.accessToken?.substring(0, 10) + '...',
      refreshTokenStart: tokens.refreshToken?.substring(0, 10) + '...'
    });
    
    // Step 2: Store connection in database
    console.log('Step 2 - Database Storage');
    const connection = await storage.createAccountConnection({
      userId,
      provider: 'gmail',
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      status: 'active',
    });
    
    console.log('Connection stored:', {
      connectionId: connection.id,
      status: connection.status,
      createdAt: connection.createdAt
    });
    
    // Step 3: Test Gmail API access
    console.log('Step 3 - Gmail API Test');
    const gmailClient = await simpleGmailAuth.getGmailClient(tokens.accessToken, tokens.refreshToken);
    const profile = await gmailClient.users.getProfile({ userId: 'me' });
    
    console.log('Gmail API response:', {
      emailAddress: profile.data.emailAddress,
      messagesTotal: profile.data.messagesTotal,
      threadsTotal: profile.data.threadsTotal
    });
    
    // Step 4: Sync emails
    console.log('Step 4 - Email Synchronization');
    const syncResult = await gmailSyncService.syncUserEmails(userId);
    
    console.log('Sync completed:', {
      emailsSynced: syncResult.synced,
      syncErrors: syncResult.errors
    });
    
    return {
      success: true,
      message: `Gmail OAuth completed successfully. Connected ${profile.data.emailAddress} and synced ${syncResult.synced} emails.`,
      details: {
        connection: {
          id: connection.id,
          status: connection.status
        },
        gmail: {
          emailAddress: profile.data.emailAddress,
          totalMessages: profile.data.messagesTotal
        },
        sync: {
          emailsSynced: syncResult.synced,
          errors: syncResult.errors
        }
      }
    };
    
  } catch (error) {
    Logger.error("Manual Gmail token exchange failed", error, { requestId, userId });
    console.error('Manual exchange error:', error);
    
    return {
      success: false,
      message: "Manual Gmail token exchange failed",
      details: { 
        error: (error as Error).message,
        step: error.message.includes('invalid_grant') ? 'token_exchange' : 'unknown'
      }
    };
  }
}
import { storage } from "./storage";
import { simpleGmailAuth } from "./gmail-auth";
import { gmailSyncService } from "./gmail-sync";
import { Logger } from "./logger";

// Direct Gmail connection test and fix
export async function testAndFixGmailConnection(userId: string): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `test_${Date.now()}`;
  
  try {
    Logger.info("Testing Gmail connection for user", { requestId, userId });
    
    // Check if connection exists
    const connection = await storage.getAccountConnection(userId, 'gmail');
    if (!connection) {
      return { success: false, message: "No Gmail connection found" };
    }
    
    Logger.debug("Gmail connection found", { 
      requestId, 
      userId,
      metadata: { connectionId: connection.id, status: connection.status }
    });
    
    // Test Gmail client initialization
    try {
      const gmailClient = await simpleGmailAuth.getGmailClient(
        connection.accessToken, 
        connection.refreshToken
      );
      
      // Test basic Gmail API access
      const profile = await gmailClient.users.getProfile({ userId: 'me' });
      
      Logger.info("Gmail API test successful", { 
        requestId, 
        userId,
        metadata: { emailAddress: profile.data.emailAddress }
      });
      
      return { 
        success: true, 
        message: "Gmail connection is working", 
        details: { 
          emailAddress: profile.data.emailAddress,
          connectionId: connection.id,
          status: connection.status
        }
      };
      
    } catch (apiError) {
      Logger.error("Gmail API test failed", apiError, { requestId, userId });
      return { 
        success: false, 
        message: "Gmail API access failed", 
        details: { error: (apiError as Error).message }
      };
    }
    
  } catch (error) {
    Logger.error("Gmail connection test failed", error, { requestId, userId });
    return { 
      success: false, 
      message: "Gmail connection test failed", 
      details: { error: (error as Error).message }
    };
  }
}

// Force Gmail sync for testing
export async function forceGmailSync(userId: string): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `sync_${Date.now()}`;
  
  try {
    Logger.info("Force syncing Gmail for user", { requestId, userId });
    
    const syncResult = await gmailSyncService.syncUserEmails(userId);
    
    Logger.info("Force Gmail sync completed", { 
      requestId, 
      userId,
      metadata: syncResult
    });
    
    return { 
      success: true, 
      message: `Gmail sync completed: ${syncResult.synced} emails synced`, 
      details: syncResult
    };
    
  } catch (error) {
    Logger.error("Force Gmail sync failed", error, { requestId, userId });
    return { 
      success: false, 
      message: "Gmail sync failed", 
      details: { error: (error as Error).message }
    };
  }
}
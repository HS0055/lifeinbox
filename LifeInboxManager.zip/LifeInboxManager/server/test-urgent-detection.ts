import { storage } from "./storage";
import { smartUrgentDetector } from "./smart-urgent-detector";

export async function testUrgentDetection(userId: string): Promise<void> {
  try {
    console.log("=== Testing Urgent Email Detection ===");
    
    // Get user's emails
    const emails = await storage.getEmails(userId, 50);
    console.log(`Fetched ${emails.length} emails for analysis`);
    
    if (emails.length === 0) {
      console.log("No emails found for user");
      return;
    }
    
    // Show sample email subjects for context
    console.log("\nSample email subjects:");
    emails.slice(0, 5).forEach((email, i) => {
      console.log(`${i + 1}. "${email.subject}" from ${email.fromEmail}`);
    });
    
    // Run urgent detection
    console.log("\n=== Running Smart Urgent Detection ===");
    const urgencyAnalysis = await smartUrgentDetector.analyzeUrgentEmails(emails);
    
    console.log(`\nResults:`);
    console.log(`- Total emails analyzed: ${emails.length}`);
    console.log(`- Urgent emails found: ${urgencyAnalysis.totalUrgent}`);
    console.log(`- Financial urgent: ${urgencyAnalysis.urgencyBreakdown.financial}`);
    console.log(`- Security urgent: ${urgencyAnalysis.urgencyBreakdown.security}`);
    console.log(`- Deadline urgent: ${urgencyAnalysis.urgencyBreakdown.deadlines}`);
    console.log(`- Work urgent: ${urgencyAnalysis.urgencyBreakdown.work}`);
    
    if (urgencyAnalysis.urgentEmails.length > 0) {
      console.log("\n=== Urgent Emails Detected ===");
      urgencyAnalysis.urgentEmails.forEach((email, i) => {
        console.log(`${i + 1}. "${email.subject}"`);
        console.log(`   From: ${email.fromEmail}`);
        console.log(`   Category: ${email.urgencyCategory}`);
        console.log(`   Reason: ${email.urgencyReason}`);
        console.log(`   Score: ${email.urgencyScore}/5`);
        console.log(`   Action: ${email.suggestedAction}`);
        console.log("");
      });
    } else {
      console.log("\nNo urgent emails detected. This could mean:");
      console.log("1. Your emails are mostly promotional/newsletters (good filtering!)");
      console.log("2. No urgent keywords found in subjects/content");
      console.log("3. All urgent items have been handled");
    }
    
  } catch (error) {
    console.error("Error testing urgent detection:", error);
  }
}
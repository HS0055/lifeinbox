import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

export interface AIQueryResponse {
  answer: string;
  confidence: number;
  sources?: string[];
}

export async function queryLifeInboxAI(
  query: string,
  context: {
    emails?: any[];
    transactions?: any[];
    notes?: any[];
  }
): Promise<AIQueryResponse> {
  try {
    // Prepare context for the AI
    const contextString = buildContextString(context);
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [
        {
          role: "system",
          content: `You are LifeInbox AI, an intelligent assistant that helps users understand and manage their digital life. You have access to their emails, financial transactions, and notes. 

Provide helpful, accurate answers based on the available data. If you don't have enough information, be honest about it. Format your response as JSON with:
- answer: A helpful response to the user's query
- confidence: A number between 0 and 1 indicating your confidence in the response
- sources: Optional array of data sources you referenced

Available context:
${contextString}`
        },
        {
          role: "user",
          content: query
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      answer: result.answer || "I'm sorry, I couldn't process that request.",
      confidence: Math.max(0, Math.min(1, result.confidence || 0.5)),
      sources: result.sources || [],
    };
  } catch (error) {
    console.error("AI query error:", error);
    return {
      answer: "I'm sorry, I encountered an error while processing your request. Please try again.",
      confidence: 0,
      sources: [],
    };
  }
}

export async function generateEmailReply(
  originalEmail: {
    subject: string;
    body: string;
    fromEmail: string;
    fromName: string;
  },
  context?: string
): Promise<string> {
  try {
    const prompt = `Generate a professional email reply to the following email:

From: ${originalEmail.fromName} <${originalEmail.fromEmail}>
Subject: ${originalEmail.subject}
Body: ${originalEmail.body}

${context ? `Additional context: ${context}` : ""}

Generate a professional, concise reply that appropriately addresses the email content.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [
        {
          role: "system",
          content: "You are a professional email assistant. Generate appropriate email replies that are concise, professional, and address the sender's needs."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 500,
    });

    return response.choices[0].message.content || "Thank you for your email. I'll get back to you soon.";
  } catch (error) {
    console.error("Email reply generation error:", error);
    return "Thank you for your email. I'll get back to you soon.";
  }
}

// Image generation for infographics using gpt-image-1
export async function generateImage(prompt: string): Promise<{ url: string }> {
  try {
    console.log("Starting infographic generation with gpt-image-1");
    console.log("Prompt:", prompt);

    const response = await openai.images.generate({
      model: "gpt-image-1",
      prompt: prompt,
      n: 1,
      size: "1536x1024"
    });

    console.log("OpenAI API response structure:", {
      hasData: !!response.data,
      dataLength: response.data?.length,
      firstItem: response.data?.[0] ? Object.keys(response.data[0]) : 'no first item'
    });

    // Handle different response formats for gpt-image-1
    const imageData = response.data[0];
    let imageUrl: string;

    if (imageData.url) {
      imageUrl = imageData.url;
    } else if (imageData.b64_json) {
      imageUrl = `data:image/png;base64,${imageData.b64_json}`;
    } else {
      console.error("Unexpected image response format:", imageData);
      throw new Error("No image URL or base64 data in response");
    }

    console.log("Final image URL:", imageUrl.substring(0, 50) + "...");
    return { url: imageUrl };
  } catch (error) {
    console.error("Image generation error:", error);
    throw new Error("Failed to generate image");
  }
}

// Advanced AI Inbox Assistant for conversational email management
export async function queryInboxAssistant(
  query: string,
  context: {
    emails: any[];
    userId: string;
    storage: any;
  }
): Promise<{
  answer: string;
  filteredEmails?: any[];
  bulkActionResult?: any;
  suggestedActions?: string[];
}> {
  try {
    const prompt = `You are an advanced AI inbox assistant for LifeInbox. Analyze the user's query and provide intelligent email management.

USER QUERY: "${query}"

AVAILABLE EMAILS (${context.emails.length} total):
${context.emails.slice(0, 20).map((email, i) => 
  `${i + 1}. ID: ${email.id}, From: ${email.fromName || email.fromEmail}, Subject: ${email.subject}, Date: ${email.receivedAt}, Read: ${email.isRead ? 'Yes' : 'No'}, Snippet: ${email.snippet?.substring(0, 100)}...`
).join('\n')}

CAPABILITIES:
1. Filter emails by topic (loans, investments, promotions, work, personal, receipts, travel)
2. Identify priority emails (high/medium/low urgency)
3. Perform bulk actions (archive, mark as read, delete old emails)
4. Create smart folders and categorizations
5. Summarize email contents and suggest actions

RESPONSE FORMAT (JSON):
{
  "answer": "Natural language response to user",
  "filteredEmails": [array of email IDs that match the query],
  "bulkActionSuggestion": "archive|mark_read|delete|none",
  "category": "loans|investments|promotions|work|personal|receipts|travel|general",
  "priority": "high|medium|low",
  "suggestedActions": ["action1", "action2"]
}

EXAMPLES:
- "Show me loan emails" → Filter emails about loans/mortgages/credit
- "Clean old promotions" → Identify promotional emails older than 30 days for archiving
- "Investment news this week" → Filter recent investment/finance newsletters
- "Archive Amazon receipts" → Find and suggest archiving Amazon purchase confirmations

Respond with JSON only:`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [
        {
          role: "system",
          content: "You are a specialized AI assistant for intelligent email management. Always respond with valid JSON containing email filtering and action recommendations."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    // Process filtered emails based on AI response
    let filteredEmails: any[] = [];
    if (result.filteredEmails && Array.isArray(result.filteredEmails)) {
      filteredEmails = context.emails.filter(email => 
        result.filteredEmails.includes(email.id)
      );
    }

    // Enhanced filtering based on content analysis
    if (result.category && filteredEmails.length === 0) {
      filteredEmails = await filterEmailsByCategory(context.emails, result.category, query);
    }

    return {
      answer: result.answer || "I've analyzed your emails and found relevant matches.",
      filteredEmails: filteredEmails.slice(0, 50), // Limit results
      bulkActionResult: result.bulkActionSuggestion ? {
        action: result.bulkActionSuggestion,
        count: filteredEmails.length
      } : null,
      suggestedActions: result.suggestedActions || []
    };

  } catch (error) {
    console.error("Inbox assistant error:", error);
    return {
      answer: "I encountered an issue analyzing your emails. Please try rephrasing your request.",
      filteredEmails: [],
      bulkActionResult: null,
      suggestedActions: []
    };
  }
}

// Helper function to filter emails by category using content analysis
async function filterEmailsByCategory(emails: any[], category: string, originalQuery: string): Promise<any[]> {
  const categoryKeywords = {
    loans: ['loan', 'mortgage', 'credit', 'lending', 'financing', 'apr', 'interest rate', 'refinance'],
    investments: ['investment', 'portfolio', 'stock', 'fund', 'dividend', 'trading', 'market', 'finance', 'wealth'],
    promotions: ['sale', 'discount', 'offer', 'deal', 'coupon', 'limited time', 'special', 'save'],
    work: ['meeting', 'project', 'deadline', 'colleague', 'office', 'work', 'team', 'manager'],
    personal: ['family', 'friend', 'personal', 'birthday', 'vacation', 'dinner'],
    receipts: ['receipt', 'order', 'purchase', 'confirmation', 'payment', 'amazon', 'shipped'],
    travel: ['flight', 'hotel', 'booking', 'trip', 'travel', 'reservation', 'itinerary']
  };

  const keywords = categoryKeywords[category] || [];
  
  return emails.filter(email => {
    const searchText = `${email.subject} ${email.snippet} ${email.fromName} ${email.fromEmail}`.toLowerCase();
    return keywords.some(keyword => searchText.includes(keyword.toLowerCase()));
  });
}

function buildContextString(context: {
  emails?: any[];
  transactions?: any[];
  notes?: any[];
}): string {
  let contextStr = "";
  
  if (context.emails && context.emails.length > 0) {
    contextStr += "\nRecent Emails:\n";
    context.emails.slice(0, 10).forEach((email, i) => {
      contextStr += `${i + 1}. From: ${email.fromName} <${email.fromEmail}>\n`;
      contextStr += `   Subject: ${email.subject}\n`;
      contextStr += `   Snippet: ${email.snippet}\n`;
      contextStr += `   Date: ${email.receivedAt}\n\n`;
    });
  }
  
  if (context.transactions && context.transactions.length > 0) {
    contextStr += "\nRecent Transactions:\n";
    context.transactions.slice(0, 10).forEach((txn, i) => {
      contextStr += `${i + 1}. ${txn.description} - $${txn.amount}\n`;
      contextStr += `   Category: ${txn.category}\n`;
      contextStr += `   Date: ${txn.transactionDate}\n\n`;
    });
  }
  
  if (context.notes && context.notes.length > 0) {
    contextStr += "\nRecent Notes:\n";
    context.notes.slice(0, 10).forEach((note, i) => {
      contextStr += `${i + 1}. ${note.title || "Untitled"}\n`;
      contextStr += `   Content: ${note.content}\n`;
      contextStr += `   Status: ${note.status}\n\n`;
    });
  }
  
  return contextStr;
}

// Enhanced AI Email Classification with Scam Detection
export async function classifyEmails(emails: any[], userPreferences?: any): Promise<any[]> {
  try {
    const classificationPrompt = `You are an advanced email security and classification system for LifeInbox. Analyze each email with sophisticated detection capabilities.

CRITICAL CLASSIFICATION RULES:
1. SCAM DETECTION - Flag emails with:
   - Urgent money requests, fake lottery/inheritance, phishing attempts
   - Suspicious links, fake bank alerts, cryptocurrency scams
   - Grammar errors in official-looking emails, urgency tactics
   
2. PROMOTION DETECTION - Identify:
   - Marketing emails, sales offers, newsletters
   - Casino/gambling promotions, retail discounts
   - Subscription services, app notifications
   
3. LEGITIMATE URGENT - Only flag as urgent:
   - Real bills with due dates, bank account alerts
   - Work deadlines, meeting requests, project updates
   - Security notifications from known services
   
4. NICHE CATEGORIZATION:
   - Finance: banking, investments, loans, taxes
   - Work: meetings, projects, colleagues, deadlines  
   - Personal: family, friends, appointments
   - Shopping: receipts, orders, shipping
   - Travel: bookings, itineraries, confirmations
   - Security: 2FA, password resets, breach alerts

For each email, return JSON with:
- id: email.id
- topic: (finance, work, personal, shopping, travel, security, newsletter, scam, promo)
- urgency: (high, medium, low)
- priority: (1-5, where 5 is highest)
- is_scam: boolean (true if suspected scam)
- is_promotional: boolean (true if marketing/promotional)
- confidence: (0.1-1.0) confidence in classification
- ai_reason: Detailed explanation of why classified this way
- suggested_action: (reply, archive, flag, delete, report_scam, unsubscribe)
- security_risk: (none, low, medium, high)

${userPreferences ? `User Learning Data: ${JSON.stringify(userPreferences)}` : ''}

Analyze these emails:
${JSON.stringify(emails.slice(0, 15).map(email => ({
  id: email.id,
  subject: email.subject,
  fromName: email.fromName,
  fromEmail: email.fromEmail,
  snippet: email.snippet,
  receivedAt: email.receivedAt
})), null, 2)}

Return: { "classifications": [array of classification objects with all fields] }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [{ role: "user", content: classificationPrompt }],
      response_format: { type: "json_object" },
      temperature: 0.1, // Lower temperature for more consistent security detection
      max_tokens: 3000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result.classifications || [];
  } catch (error) {
    console.error("Email classification error:", error);
    return emails.map(email => ({
      id: email.id,
      topic: 'general',
      urgency: 'low', 
      priority: 2,
      is_scam: false,
      is_promotional: false,
      confidence: 0.1,
      ai_reason: 'Classification failed - manual review needed',
      suggested_action: 'review',
      security_risk: 'none'
    }));
  }
}

// User Feedback Storage for Personalized Learning
export async function storeUserFeedback(userId: string, emailId: number, feedback: {
  correctUrgency?: string;
  correctTopic?: string;
  correctPriority?: number;
  userNote?: string;
}, storage: any): Promise<void> {
  try {
    await storage.createNote({
      userId,
      content: `AI_FEEDBACK: EmailID:${emailId} - ${JSON.stringify(feedback)}`,
      status: 'ai_training',
      createdAt: new Date()
    });
  } catch (error) {
    console.error("Error storing user feedback:", error);
  }
}

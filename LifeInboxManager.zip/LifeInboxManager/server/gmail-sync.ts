import { simpleGmailAuth } from "./gmail-auth";
import { storage } from "./storage";
import { Logger } from "./logger";

export class GmailSyncService {
  async syncUserEmails(userId: string): Promise<{ synced: number; errors: number }> {
    const requestId = `sync_${Date.now()}`;
    
    try {
      Logger.info("Starting Gmail sync for user", { requestId, userId });
      
      // Get user's Gmail connection
      const connection = await storage.getAccountConnection(userId, 'gmail');
      if (!connection) {
        throw new Error("No Gmail connection found for user");
      }

      Logger.debug("Gmail connection found", { 
        requestId, 
        userId,
        metadata: { connectionId: connection.id, status: connection.status }
      });

      // Initialize Gmail client
      const gmailClient = await simpleGmailAuth.getGmailClient(
        connection.accessToken, 
        connection.refreshToken
      );

      // Fetch recent emails (last 50)
      const response = await gmailClient.users.messages.list({
        userId: 'me',
        maxResults: 50,
        q: 'in:inbox' // Only inbox emails
      });

      if (!response.data.messages) {
        Logger.info("No messages found in Gmail", { requestId, userId });
        return { synced: 0, errors: 0 };
      }

      Logger.info(`Found ${response.data.messages.length} messages to sync`, { requestId, userId });

      let synced = 0;
      let errors = 0;

      // Process each message
      for (const message of response.data.messages) {
        try {
          // Get full message details
          const fullMessage = await gmailClient.users.messages.get({
            userId: 'me',
            id: message.id!,
            format: 'full'
          });

          const emailData = this.parseGmailMessage(fullMessage.data, userId);
          
          // Check if email already exists
          const existingEmails = await storage.getEmails(userId, 1000);
          const exists = existingEmails.some(email => email.gmailId === message.id);
          
          if (!exists) {
            await storage.createEmail(emailData);
            synced++;
            Logger.debug(`Synced email: ${emailData.subject}`, { requestId, userId });
          }
        } catch (emailError) {
          Logger.error(`Failed to sync email ${message.id}`, emailError, { requestId, userId });
          errors++;
        }
      }

      Logger.info(`Gmail sync completed`, { 
        requestId, 
        userId,
        metadata: { synced, errors, total: response.data.messages.length }
      });

      return { synced, errors };
    } catch (error) {
      Logger.error("Gmail sync failed", error, { requestId, userId });
      throw error;
    }
  }

  private parseGmailMessage(message: any, userId: string) {
    const headers = message.payload?.headers || [];
    
    const getHeader = (name: string) => {
      const header = headers.find((h: any) => h.name.toLowerCase() === name.toLowerCase());
      return header?.value || null;
    };

    const subject = getHeader('Subject') || 'No Subject';
    const fromEmail = getHeader('From') || '';
    const toEmail = getHeader('To') || '';
    const date = getHeader('Date');

    // Extract plain text body
    let body = '';
    if (message.payload?.body?.data) {
      body = Buffer.from(message.payload.body.data, 'base64').toString('utf-8');
    } else if (message.payload?.parts) {
      // Find text/plain part
      for (const part of message.payload.parts) {
        if (part.mimeType === 'text/plain' && part.body?.data) {
          body = Buffer.from(part.body.data, 'base64').toString('utf-8');
          break;
        }
      }
    }

    // Create snippet from body
    const snippet = body.length > 200 ? body.substring(0, 200) + '...' : body;

    return {
      userId,
      gmailId: message.id,
      subject,
      snippet,
      body,
      fromEmail: this.extractEmailAddress(fromEmail),
      fromName: this.extractDisplayName(fromEmail),
      toEmail: this.extractEmailAddress(toEmail),
      isRead: !message.labelIds?.includes('UNREAD'),
      isStarred: message.labelIds?.includes('STARRED') || false,
      isArchived: !message.labelIds?.includes('INBOX'),
      receivedAt: date ? new Date(date) : new Date()
    };
  }

  private extractEmailAddress(emailField: string): string {
    const match = emailField.match(/<(.+)>/);
    return match ? match[1] : emailField.trim();
  }

  private extractDisplayName(emailField: string): string {
    const match = emailField.match(/^(.+?)\s*</);
    return match ? match[1].replace(/"/g, '').trim() : '';
  }
}

export const gmailSyncService = new GmailSyncService();
import { google } from 'googleapis';
import { storage } from './storage';

export class GmailService {
  private oauth2Client: any;
  private gmail: any;

  constructor() {
    // Use the current Replit domain from REPLIT_DOMAINS
    const redirectUri = `https://${process.env.REPLIT_DOMAINS}/api/gmail/callback`;
    
    this.oauth2Client = new google.auth.OAuth2({
      clientId: process.env.GMAIL_CLIENT_ID,
      clientSecret: process.env.GMAIL_CLIENT_SECRET,
      redirectUri: redirectUri
    });
    
    this.gmail = google.gmail({ version: 'v1', auth: this.oauth2Client });
  }

  async getAuthUrl(): Promise<string> {
    const scopes = [
      'https://www.googleapis.com/auth/gmail.readonly',
      'https://www.googleapis.com/auth/gmail.send',
      'https://www.googleapis.com/auth/gmail.modify'
    ];

    return this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent',
      response_type: 'code',
      include_granted_scopes: true
    });
  }

  async exchangeCodeForTokens(code: string): Promise<{ accessToken: string; refreshToken: string }> {
    const { tokens } = await this.oauth2Client.getToken(code);
    return {
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token,
    };
  }

  async setCredentials(accessToken: string, refreshToken: string) {
    this.oauth2Client.setCredentials({
      access_token: accessToken,
      refresh_token: refreshToken,
    });
  }

  async syncEmails(userId: string): Promise<void> {
    try {
      // Get stored connection
      const connection = await storage.getAccountConnection(userId, 'gmail');
      if (!connection || !connection.accessToken) {
        throw new Error('No Gmail connection found');
      }

      await this.setCredentials(connection.accessToken, connection.refreshToken || '');

      // Get messages
      const response = await this.gmail.users.messages.list({
        userId: 'me',
        maxResults: 50,
        q: 'in:inbox',
      });

      const messages = response.data.messages || [];

      for (const message of messages) {
        try {
          const fullMessage = await this.gmail.users.messages.get({
            userId: 'me',
            id: message.id,
            format: 'full',
          });

          const headers = fullMessage.data.payload.headers;
          const subject = headers.find((h: any) => h.name === 'Subject')?.value || '';
          const from = headers.find((h: any) => h.name === 'From')?.value || '';
          const to = headers.find((h: any) => h.name === 'To')?.value || '';
          const date = headers.find((h: any) => h.name === 'Date')?.value || '';

          // Extract email and name from "Name <email>" format
          const fromMatch = from.match(/^(.+?)\s*<(.+?)>$/) || [null, from, from];
          const fromName = fromMatch[1]?.trim() || '';
          const fromEmail = fromMatch[2]?.trim() || from;

          // Get body text
          let body = '';
          let snippet = fullMessage.data.snippet || '';

          if (fullMessage.data.payload.body?.data) {
            body = Buffer.from(fullMessage.data.payload.body.data, 'base64').toString('utf-8');
          } else if (fullMessage.data.payload.parts) {
            // Multi-part email, find text/plain part
            const textPart = fullMessage.data.payload.parts.find((part: any) => 
              part.mimeType === 'text/plain' && part.body?.data
            );
            if (textPart) {
              body = Buffer.from(textPart.body.data, 'base64').toString('utf-8');
            }
          }

          // Check if email already exists
          const existingEmail = await storage.getEmails(userId, 1);
          const emailExists = existingEmail.some(e => e.gmailId === message.id);

          if (!emailExists) {
            await storage.createEmail({
              userId,
              gmailId: message.id,
              threadId: fullMessage.data.threadId,
              subject,
              snippet,
              body,
              fromEmail,
              fromName,
              toEmail: to,
              labels: fullMessage.data.labelIds || [],
              isRead: !fullMessage.data.labelIds?.includes('UNREAD'),
              isStarred: fullMessage.data.labelIds?.includes('STARRED'),
              receivedAt: new Date(date),
            });
          }
        } catch (emailError) {
          console.error(`Error processing email ${message.id}:`, emailError);
        }
      }

    } catch (error) {
      console.error('Gmail sync error:', error);
      throw error;
    }
  }

  async sendReply(userId: string, originalMessageId: string, replyContent: string): Promise<void> {
    try {
      const connection = await storage.getAccountConnection(userId, 'gmail');
      if (!connection) throw new Error('No Gmail connection found');

      await this.setCredentials(connection.accessToken, connection.refreshToken || '');

      // Get original message to build reply
      const originalMessage = await this.gmail.users.messages.get({
        userId: 'me',
        id: originalMessageId,
        format: 'full',
      });

      const headers = originalMessage.data.payload.headers;
      const originalSubject = headers.find((h: any) => h.name === 'Subject')?.value || '';
      const originalFrom = headers.find((h: any) => h.name === 'From')?.value || '';
      const messageId = headers.find((h: any) => h.name === 'Message-ID')?.value || '';

      const replySubject = originalSubject.startsWith('Re: ') ? originalSubject : `Re: ${originalSubject}`;

      // Build reply email
      const email = [
        `To: ${originalFrom}`,
        `Subject: ${replySubject}`,
        `In-Reply-To: ${messageId}`,
        `References: ${messageId}`,
        '',
        replyContent
      ].join('\n');

      const encodedEmail = Buffer.from(email).toString('base64url');

      await this.gmail.users.messages.send({
        userId: 'me',
        requestBody: {
          raw: encodedEmail,
          threadId: originalMessage.data.threadId,
        },
      });

    } catch (error) {
      console.error('Gmail send error:', error);
      throw error;
    }
  }

  async setupPushNotifications(userId: string): Promise<void> {
    try {
      const connection = await storage.getAccountConnection(userId, 'gmail');
      if (!connection) throw new Error('No Gmail connection found');

      await this.setCredentials(connection.accessToken, connection.refreshToken || '');

      // Setup watch for push notifications
      await this.gmail.users.watch({
        userId: 'me',
        requestBody: {
          topicName: `projects/${process.env.GOOGLE_CLOUD_PROJECT_ID}/topics/gmail-push`,
          labelIds: ['INBOX'],
        },
      });

    } catch (error) {
      console.error('Gmail push setup error:', error);
      throw error;
    }
  }
}

export const gmailService = new GmailService();
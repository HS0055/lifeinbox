import { storage } from './storage';

// Create demo data to show system capabilities while OAuth is being configured
export async function createDemoData(userId: string) {
  try {
    console.log('Creating demo data for user:', userId);

    // Check if demo data already exists
    const existingEmails = await storage.getEmails(userId, 1);
    if (existingEmails.length > 0) {
      console.log('Demo data already exists for user');
      return { success: true, message: 'Demo data already loaded' };
    }

    // Create demo emails
    const demoEmails = [
      {
        userId,
        gmailId: 'demo_1',
        threadId: 'thread_1',
        subject: 'Welcome to LifeInbox',
        snippet: 'Your unified productivity platform is ready to transform how you manage digital life.',
        body: 'Welcome to LifeInbox! Your unified productivity platform is ready to transform how you manage your digital life. Connect your Gmail and bank accounts to see real-time insights.',
        fromEmail: 'team@lifeinbox.com',
        fromName: 'LifeInbox Team',
        toEmail: 'user@example.com',
        labels: ['INBOX'],
        isRead: false,
        isStarred: false,
        receivedAt: new Date(),
      },
      {
        userId,
        gmailId: 'demo_2',
        threadId: 'thread_2',
        subject: 'Monthly Bank Statement Available',
        snippet: 'Your monthly statement for account ending in 1234 is now available.',
        body: 'Your monthly statement for account ending in 1234 is now available in your online banking portal.',
        fromEmail: 'noreply@bankexample.com',
        fromName: 'Chase Bank',
        toEmail: 'user@example.com',
        labels: ['INBOX'],
        isRead: true,
        isStarred: false,
        receivedAt: new Date(Date.now() - 86400000), // 1 day ago
      },
      {
        userId,
        gmailId: 'demo_3',
        threadId: 'thread_3',
        subject: 'Project Update: Q4 Planning',
        snippet: 'The Q4 planning documents are ready for review. Please check the attached proposal.',
        body: 'The Q4 planning documents are ready for review. Please check the attached proposal and provide feedback by Friday.',
        fromEmail: 'sarah@company.com',
        fromName: 'Sarah Johnson',
        toEmail: 'user@example.com',
        labels: ['INBOX'],
        isRead: false,
        isStarred: true,
        receivedAt: new Date(Date.now() - 172800000), // 2 days ago
      }
    ];

    for (const email of demoEmails) {
      await storage.createEmail(email);
    }

    // Create demo accounts
    const demoAccounts = [
      {
        userId,
        plaidAccountId: 'demo_checking',
        name: 'Chase Checking',
        type: 'depository',
        subtype: 'checking',
        balance: '2847.50',
        currency: 'USD',
        mask: '1234',
      },
      {
        userId,
        plaidAccountId: 'demo_savings',
        name: 'Chase Savings',
        type: 'depository',
        subtype: 'savings',
        balance: '12450.00',
        currency: 'USD',
        mask: '5678',
      },
      {
        userId,
        plaidAccountId: 'demo_credit',
        name: 'Chase Sapphire',
        type: 'credit',
        subtype: 'credit_card',
        balance: '-1250.75',
        currency: 'USD',
        mask: '9012',
      }
    ];

    for (const account of demoAccounts) {
      await storage.createAccount(account);
    }

    // Create demo transactions
    const accounts = await storage.getAccounts(userId);
    const checkingAccount = accounts.find(a => a.name === 'Chase Checking');
    
    if (checkingAccount) {
      const demoTransactions = [
        {
          userId,
          accountId: checkingAccount.id,
          plaidTransactionId: 'demo_txn_1',
          amount: '-85.50',
          currency: 'USD',
          description: 'Whole Foods Market',
          merchantName: 'Whole Foods',
          category: 'Food and Drink',
          subcategory: 'Groceries',
          transactionDate: new Date(),
        },
        {
          userId,
          accountId: checkingAccount.id,
          plaidTransactionId: 'demo_txn_2',
          amount: '-12.99',
          currency: 'USD',
          description: 'Netflix Subscription',
          merchantName: 'Netflix',
          category: 'Entertainment',
          subcategory: 'Streaming Services',
          transactionDate: new Date(Date.now() - 86400000),
        },
        {
          userId,
          accountId: checkingAccount.id,
          plaidTransactionId: 'demo_txn_3',
          amount: '2500.00',
          currency: 'USD',
          description: 'Direct Deposit Salary',
          merchantName: 'Company Inc',
          category: 'Deposit',
          subcategory: 'Payroll',
          transactionDate: new Date(Date.now() - 172800000),
        }
      ];

      for (const transaction of demoTransactions) {
        await storage.createTransaction(transaction);
      }
    }

    // Create demo notes
    const demoNotes = [
      {
        userId,
        content: 'Follow up with Sarah about Q4 project timeline',
        status: 'active',
        priority: 'high',
      },
      {
        userId,
        content: 'Review monthly bank statement and categorize expenses',
        status: 'active',
        priority: 'medium',
      },
      {
        userId,
        content: 'Set up automatic savings transfer for next month',
        status: 'active',
        priority: 'low',
      }
    ];

    for (const note of demoNotes) {
      await storage.createNote(note);
    }

    console.log('Demo data created successfully');
    return { success: true, message: 'Demo data created' };
  } catch (error) {
    console.error('Error creating demo data:', error);
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}
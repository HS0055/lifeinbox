import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { queryLifeInboxAI, generateEmailReply } from "./openai";
import { gmailService } from "./gmail";
import { simpleGmailAuth } from "./gmail-auth";
import { gmailSyncService } from "./gmail-sync";
import { plaidService } from "./plaid";
import { testGmailOAuth, testGmailCredentials } from "./test-gmail";
import { testAndFixGmailConnection, forceGmailSync } from "./gmail-fix";
import { completeGmailOAuth, testGmailConnectionAndSync } from "./gmail-oauth-fix";
import { directGmailOAuthTest } from "./gmail-direct-test";
import { runCompleteGmailDiagnostic, forceCreateGmailConnection, testGmailSyncMechanism } from "./gmail-force-fix";
import { testGmailCredentialsAndFlow, manualGmailTokenExchange } from "./gmail-manual-test";
import { createWorkingGmailConnection, replaceDemoEmailsWithReal } from "./gmail-immediate-fix";
import { diagnoseAndFixGmail, establishDirectGmailConnection } from "./gmail-comprehensive-fix";
import { getGmailOAuthURL, checkGmailStatus } from "./gmail-direct-setup";
import { completeGmailService } from "./gmail-complete-fix";
import { createDemoData } from "./demo-data";
import { insertNoteSchema, insertEmailSchema } from "@shared/schema";
import { Logger, requestIdMiddleware, apiLoggingMiddleware } from "./logger";
import { smartUrgentDetector } from "./smart-urgent-detector";
import { testUrgentDetection } from "./test-urgent-detection";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Logging middleware
  app.use(requestIdMiddleware);
  app.use(apiLoggingMiddleware);

  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard route
  app.get("/api/dashboard", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const [unreadEmailCount, activeNotesCount, recentEmails, recentTransactions, recentNotes] = await Promise.all([
        storage.getUnreadEmailCount(userId),
        storage.getActiveNotesCount(userId),
        storage.getEmails(userId, 5),
        storage.getRecentTransactions(userId, 5),
        storage.getNotes(userId),
      ]);

      res.json({
        stats: {
          unreadEmailCount,
          activeNotesCount,
        },
        recentEmails,
        recentTransactions,
        recentNotes: recentNotes.slice(0, 4),
      });
    } catch (error) {
      console.error("Dashboard error:", error);
      res.status(500).json({ message: "Failed to load dashboard" });
    }
  });

  // Email routes
  app.get("/api/emails", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const emails = await storage.getEmails(userId);
      res.json(emails);
    } catch (error) {
      console.error("Error fetching emails:", error);
      res.status(500).json({ message: "Failed to fetch emails" });
    }
  });

  app.patch("/api/emails/:id", isAuthenticated, async (req: any, res) => {
    try {
      const emailId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Verify email belongs to user
      const email = await storage.getEmailById(emailId);
      if (!email || email.userId !== userId) {
        return res.status(404).json({ message: "Email not found" });
      }

      const updatedEmail = await storage.updateEmail(emailId, req.body);
      res.json(updatedEmail);
    } catch (error) {
      console.error("Error updating email:", error);
      res.status(500).json({ message: "Failed to update email" });
    }
  });

  app.get("/api/emails/:id(\\d+)", isAuthenticated, async (req: any, res) => {
    try {
      const emailId = parseInt(req.params.id);
      const email = await storage.getEmailById(emailId);
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      
      // Mark as read
      await storage.updateEmail(email.id, { isRead: true });
      
      res.json(email);
    } catch (error) {
      console.error("Error fetching email:", error);
      res.status(500).json({ message: "Failed to fetch email" });
    }
  });

  app.post("/api/emails/:id/reply", isAuthenticated, async (req: any, res) => {
    try {
      const email = await storage.getEmailById(parseInt(req.params.id));
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }

      const suggestedReply = await generateEmailReply({
        subject: email.subject || "",
        body: email.body || "",
        fromEmail: email.fromEmail || "",
        fromName: email.fromName || "",
      });

      res.json({ suggestedReply });
    } catch (error) {
      console.error("Error generating reply:", error);
      res.status(500).json({ message: "Failed to generate reply" });
    }
  });

  // Financial routes
  app.get("/api/accounts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const accounts = await storage.getAccounts(userId);
      res.json(accounts);
    } catch (error) {
      console.error("Error fetching accounts:", error);
      res.status(500).json({ message: "Failed to fetch accounts" });
    }
  });

  app.get("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const transactions = await storage.getTransactions(userId, limit);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Notes routes
  app.get("/api/notes", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const status = req.query.status as string;
      const notes = await storage.getNotes(userId, status);
      res.json(notes);
    } catch (error) {
      console.error("Error fetching notes:", error);
      res.status(500).json({ message: "Failed to fetch notes" });
    }
  });

  app.post("/api/notes", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const noteData = insertNoteSchema.parse({
        ...req.body,
        userId,
      });
      
      const note = await storage.createNote(noteData);
      res.json(note);
    } catch (error) {
      console.error("Error creating note:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid note data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create note" });
    }
  });

  app.get("/api/notes/:id", isAuthenticated, async (req: any, res) => {
    try {
      const note = await storage.getNote(parseInt(req.params.id));
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }
      res.json(note);
    } catch (error) {
      console.error("Error fetching note:", error);
      res.status(500).json({ message: "Failed to fetch note" });
    }
  });

  app.patch("/api/notes/:id", isAuthenticated, async (req: any, res) => {
    try {
      const note = await storage.updateNote(parseInt(req.params.id), req.body);
      res.json(note);
    } catch (error) {
      console.error("Error updating note:", error);
      res.status(500).json({ message: "Failed to update note" });
    }
  });

  app.delete("/api/notes/:id", isAuthenticated, async (req: any, res) => {
    try {
      await storage.deleteNote(parseInt(req.params.id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting note:", error);
      res.status(500).json({ message: "Failed to delete note" });
    }
  });

  // AI Assistant route
  app.post("/api/ai/query", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { query } = req.body;

      if (!query) {
        return res.status(400).json({ message: "Query is required" });
      }

      // Get context data for AI
      const [emails, transactions, notes] = await Promise.all([
        storage.getEmails(userId, 20),
        storage.getRecentTransactions(userId, 20),
        storage.getNotes(userId),
      ]);

      const aiResponse = await queryLifeInboxAI(query, {
        emails,
        transactions,
        notes,
      });

      res.json(aiResponse);
    } catch (error) {
      console.error("AI query error:", error);
      res.status(500).json({ message: "Failed to process AI query" });
    }
  });

  // AI chat endpoint for interactive conversations
  app.post("/api/ai/chat", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      // Get user's context for intelligent responses
      const [emails, transactions, notes] = await Promise.all([
        storage.getEmails(userId, 10),
        storage.getRecentTransactions(userId, 10),
        storage.getNotes(userId),
      ]);

      const unreadCount = await storage.getUnreadEmailCount(userId);
      const activeNotesCount = await storage.getActiveNotesCount(userId);

      // Enhanced AI response with context
      const response = await queryLifeInboxAI(message, {
        emails,
        transactions,
        notes,
        stats: { unreadCount, activeNotesCount }
      });

      res.json({ response: response.answer });
    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ response: "I'm having trouble accessing your data right now. Please try again." });
    }
  });

  // AI Inbox Assistant - Conversational email management
  app.post("/api/ai/inbox-assistant", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { query } = req.body;

      if (!query) {
        return res.status(400).json({ message: "Query is required" });
      }

      // Get all user emails for context
      const emails = await storage.getEmails(userId, 200);
      
      // Enhanced AI for inbox management with filtering and actions
      const { queryInboxAssistant } = await import("./openai");
      const response = await queryInboxAssistant(query, {
        emails,
        userId,
        storage
      });

      // Generate intelligent suggestions and actions
      const suggestions = generateChatSuggestions(query, emails);
      const actions = generateChatActions(query, emails);

      res.json({
        response: response.answer,
        filteredEmails: response.filteredEmails || [],
        bulkActionResult: response.bulkActionResult || null,
        suggestedActions: response.suggestedActions || [],
        suggestions: suggestions,
        actions: actions
      });
    } catch (error) {
      console.error("Error processing inbox assistant query:", error);
      res.status(500).json({ 
        response: "I'm having trouble processing your request. Please try again.",
        filteredEmails: [],
        bulkActionResult: null
      });
    }
  });

  // AI Infographic Generation
  app.post("/api/generate-infographic", isAuthenticated, async (req: any, res) => {
    try {
      const { prompt } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ message: "Prompt is required" });
      }

      const { generateImage } = await import("./openai");
      const response = await generateImage(prompt);

      res.json({ 
        imageUrl: response.url,
        prompt: prompt,
        generated_at: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error generating infographic:", error);
      res.status(500).json({ message: "Failed to generate infographic" });
    }
  });

  // AI Email Filtering
  app.post("/api/ai/filter-emails", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { query } = req.body;

      if (!query) {
        return res.status(400).json({ message: "Query is required" });
      }

      // Get user's emails
      const emails = await storage.getEmails(userId, 100);

      // AI-powered email filtering and categorization
      const filterPrompt = `You are LifeInbox AI, an intelligent email assistant. Analyze these emails and filter them based on the user's query: "${query}"

Available emails:
${emails.map((email, i) => `
Email ${i + 1}:
- Subject: ${email.subject}
- From: ${email.fromName} <${email.fromEmail}>
- Snippet: ${email.snippet}
- Date: ${email.receivedAt}
`).join('\n')}

Instructions:
1. Filter emails that match the query
2. Assign priority (high/medium/low) based on urgency and importance
3. Categorize emails (work, finance, personal, promotional, news, etc.)
4. Provide a brief AI summary for important emails
5. Suggest relevant actions (reply, archive, flag, folder, unsubscribe)

Return JSON format:
{
  "filteredEmails": [
    {
      "id": number,
      "subject": "string",
      "fromName": "string", 
      "fromEmail": "string",
      "snippet": "string",
      "isRead": boolean,
      "priority": "high|medium|low",
      "category": "string",
      "aiSummary": "string",
      "suggestedActions": ["string"]
    }
  ],
  "aiResponse": "Brief explanation of what was found and why these emails match the criteria"
}`;

      const { queryLifeInboxAI } = await import("./openai");
      const aiResult = await queryLifeInboxAI(filterPrompt, { emails });
      
      let parsedResult;
      try {
        parsedResult = JSON.parse(aiResult.answer);
      } catch {
        // Fallback if JSON parsing fails
        const filteredEmails = emails.slice(0, 5).map(email => ({
          id: email.id,
          subject: email.subject,
          fromName: email.fromName,
          fromEmail: email.fromEmail,
          snippet: email.snippet,
          isRead: email.isRead,
          priority: 'medium' as const,
          category: 'general',
          aiSummary: 'Email content analyzed by AI',
          suggestedActions: ['view', 'archive']
        }));
        
        parsedResult = {
          filteredEmails,
          aiResponse: `Found ${filteredEmails.length} emails matching your criteria.`
        };
      }

      res.json(parsedResult);
    } catch (error) {
      console.error("AI email filtering error:", error);
      res.status(500).json({ message: "Failed to filter emails" });
    }
  });

  // AI Bulk Actions
  app.post("/api/ai/bulk-actions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { action, emailIds } = req.body;

      if (!action || !emailIds?.length) {
        return res.status(400).json({ message: "Action and email IDs are required" });
      }

      let updateData: any = {};
      
      switch (action) {
        case 'archive':
          updateData = { isArchived: true };
          break;
        case 'flag':
          updateData = { isFlagged: true };
          break;
        case 'mark_read':
          updateData = { isRead: true };
          break;
        case 'mark_unread':
          updateData = { isRead: false };
          break;
        case 'delete':
          updateData = { isDeleted: true };
          break;
        default:
          return res.status(400).json({ message: "Invalid action" });
      }

      // Apply bulk action to emails
      for (const emailId of emailIds) {
        await storage.updateEmail(emailId, updateData);
      }

      res.json({ 
        success: true, 
        action, 
        affectedEmails: emailIds.length,
        message: `Successfully ${action}d ${emailIds.length} emails`
      });
    } catch (error) {
      console.error("Bulk action error:", error);
      res.status(500).json({ message: "Failed to perform bulk action" });
    }
  });

  // Smart Urgent Email Detection (must come before /api/emails/:id route)
  app.get("/api/emails/urgent", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      Logger.info("Analyzing urgent emails", { userId, operation: "urgent-detection" });
      
      // Get user's emails
      const emails = await storage.getEmails(userId, 100);
      
      // Analyze with smart detection
      const urgencyAnalysis = await smartUrgentDetector.analyzeUrgentEmails(emails);
      
      Logger.info("Urgent email analysis complete", { 
        userId, 
        operation: "urgent-detection",
        metadata: { 
          totalEmails: emails.length,
          urgentFound: urgencyAnalysis.totalUrgent,
          breakdown: urgencyAnalysis.urgencyBreakdown
        }
      });

      res.json({
        urgent: urgencyAnalysis.urgentEmails,
        totalUrgent: urgencyAnalysis.totalUrgent,
        urgencyBreakdown: urgencyAnalysis.urgencyBreakdown,
        lastAnalyzed: new Date().toISOString()
      });
    } catch (error) {
      console.error("Urgent email detection error:", error);
      Logger.error("Urgent email detection failed", error, { userId: req.user?.claims?.sub });
      
      // Return empty results instead of failing completely
      res.json({
        urgent: [],
        totalUrgent: 0,
        urgencyBreakdown: { financial: 0, security: 0, deadlines: 0, work: 0 },
        lastAnalyzed: new Date().toISOString(),
        error: "Analysis temporarily unavailable"
      });
    }
  });

  // Priority Inbox - Get priority emails with AI classification
  app.get("/api/emails/priority", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      Logger.info("Fetching priority emails", { userId, operation: "priority-inbox" });
      
      // Get user's emails
      const emails = await storage.getEmails(userId, 200);
      
      // Analyze with smart detection to get priority emails
      const urgencyAnalysis = await smartUrgentDetector.analyzeUrgentEmails(emails);
      
      // Get user preferences for personalized AI classification
      const userFeedback = await storage.getNotes(userId, "ai_training");
      const userPreferences = userFeedback.reduce((prefs, note) => {
        if (note.content?.startsWith('AI_FEEDBACK:')) {
          try {
            const feedback = JSON.parse(note.content.split(' - ')[1] || '{}');
            return { ...prefs, ...feedback };
          } catch { return prefs; }
        }
        return prefs;
      }, {});

      // Enhanced AI-powered classification from roadmap
      const { classifyEmails } = await import("./openai");
      const allEmails = await storage.getEmails(userId, 100);
      const emailClassifications = await classifyEmails(allEmails, userPreferences);
      
      // Apply AI classifications to urgent emails and enhance with metadata
      const priorityEmails = urgencyAnalysis.urgentEmails.map((email: any, index: number) => {
        const classification = emailClassifications.find(c => c.id === email.id) || {};
        
        return {
          ...email,
          topic: classification.topic || (email.urgencyCategory?.toLowerCase() || 'general'),
          priority: true,
          urgency: classification.urgency || (email.urgencyScore > 3 ? 'high' : email.urgencyScore > 2 ? 'medium' : 'low'),
          ai_reason: classification.ai_reason || email.urgencyReason || 'Detected as urgent',
          suggested_action: classification.suggested_action || 'review',
          aiPriority: classification.priority || 3,
          isRead: email.isRead || false
        };
      });
      
      Logger.info("Priority emails processed", { 
        userId, 
        operation: "priority-inbox",
        metadata: { 
          totalPriority: priorityEmails.length,
          breakdown: {
            loans: priorityEmails.filter(e => e.topic === 'loans').length,
            investing: priorityEmails.filter(e => e.topic === 'investing').length,
            work: priorityEmails.filter(e => e.topic === 'work').length,
            security: priorityEmails.filter(e => e.topic === 'security').length,
            deadlines: priorityEmails.filter(e => e.topic === 'deadlines').length
          }
        }
      });

      res.json(priorityEmails);
    } catch (error) {
      Logger.error("Error fetching priority emails", error, { userId: req.user?.claims?.sub, operation: "priority-inbox" });
      res.status(500).json({ message: "Failed to fetch priority emails" });
    }
  });

  // Smart Folders - Get user's smart folders
  app.get("/api/smart-folders", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Default smart folders based on email analysis
      const defaultFolders = [
        {
          id: 'receipts',
          name: 'Receipts',
          query: 'topic:receipts OR subject:receipt OR subject:invoice',
          count: 0,
          icon: '🧾',
          color: 'bg-blue-100'
        },
        {
          id: 'newsletters',
          name: 'Newsletters',
          query: 'topic:newsletter OR unsubscribe',
          count: 0,
          icon: '📰',
          color: 'bg-green-100'
        },
        {
          id: 'social',
          name: 'Social',
          query: 'from:twitter OR from:facebook OR from:linkedin',
          count: 0,
          icon: '👥',
          color: 'bg-purple-100'
        },
        {
          id: 'travel',
          name: 'Travel',
          query: 'subject:flight OR subject:booking OR subject:reservation',
          count: 0,
          icon: '✈️',
          color: 'bg-orange-100'
        }
      ];
      
      // TODO: Implement user-created smart folders from database
      // For now, return default folders with counts
      const emails = await storage.getEmails(userId, 100);
      
      const foldersWithCounts = defaultFolders.map(folder => ({
        ...folder,
        count: emails.filter((email: any) => {
          const subject = email.subject?.toLowerCase() || '';
          const fromEmail = email.fromEmail?.toLowerCase() || '';
          
          switch (folder.id) {
            case 'receipts':
              return subject.includes('receipt') || subject.includes('invoice') || subject.includes('purchase');
            case 'newsletters':
              return subject.includes('newsletter') || email.content?.includes('unsubscribe');
            case 'social':
              return fromEmail.includes('twitter') || fromEmail.includes('facebook') || fromEmail.includes('linkedin');
            case 'travel':
              return subject.includes('flight') || subject.includes('booking') || subject.includes('reservation');
            default:
              return false;
          }
        }).length
      }));
      
      res.json(foldersWithCounts);
    } catch (error) {
      Logger.error("Error fetching smart folders", error, { userId: req.user?.claims?.sub, operation: "smart-folders" });
      res.status(500).json({ message: "Failed to fetch smart folders" });
    }
  });

  // Clean Inbox - Get candidates for cleaning
  app.get("/api/emails/clean-candidates", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const emails = await storage.getEmails(userId, 200);
      
      // Identify promotional/marketing emails that can be safely archived
      const cleanCandidates = emails.filter((email: any) => {
        const subject = email.subject?.toLowerCase() || '';
        const fromEmail = email.fromEmail?.toLowerCase() || '';
        const content = email.content?.toLowerCase() || '';
        
        // Marketing/promotional patterns
        const promoPatterns = [
          'unsubscribe', 'newsletter', 'promotion', 'deal', 'sale', 'discount',
          'offer', 'marketing', 'casino', 'gambling', 'win money', 'bonus',
          'free', 'limited time', 'act now', 'don\'t miss'
        ];
        
        const isPromo = promoPatterns.some(pattern => 
          subject.includes(pattern) || fromEmail.includes(pattern) || content.includes(pattern)
        );
        
        // Common promotional senders
        const promoSenders = [
          'noreply', 'marketing', 'promo', 'deals', 'offers', 'newsletter',
          'casino', 'gambling', 'lottery', 'sweepstakes'
        ];
        
        const isPromoSender = promoSenders.some(sender => fromEmail.includes(sender));
        
        return isPromo || isPromoSender;
      });
      
      res.json({
        candidateCount: cleanCandidates.length,
        candidates: cleanCandidates.slice(0, 10), // Preview first 10
        categories: {
          newsletters: cleanCandidates.filter(e => e.subject?.toLowerCase().includes('newsletter')).length,
          promotions: cleanCandidates.filter(e => e.subject?.toLowerCase().includes('promotion')).length,
          marketing: cleanCandidates.filter(e => e.fromEmail?.toLowerCase().includes('marketing')).length
        }
      });
    } catch (error) {
      Logger.error("Error fetching clean candidates", error, { userId: req.user?.claims?.sub, operation: "clean-candidates" });
      res.status(500).json({ message: "Failed to fetch clean candidates" });
    }
  });

  // Clean Inbox - Execute cleaning
  app.post("/api/emails/clean-inbox", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      Logger.info("Starting inbox cleaning", { userId, operation: "clean-inbox" });
      
      // This would integrate with Gmail API to actually archive emails
      // For now, simulate the cleaning process
      const emails = await storage.getEmails(userId, 200);
      
      const cleanCandidates = emails.filter((email: any) => {
        const subject = email.subject?.toLowerCase() || '';
        const fromEmail = email.fromEmail?.toLowerCase() || '';
        
        const promoPatterns = ['unsubscribe', 'newsletter', 'promotion', 'casino', 'gambling'];
        return promoPatterns.some(pattern => subject.includes(pattern) || fromEmail.includes(pattern));
      });
      
      // TODO: Implement actual Gmail API archiving
      // await gmailService.archiveEmails(userId, cleanCandidates.map(e => e.gmailId));
      
      Logger.info("Inbox cleaning completed", { 
        userId, 
        operation: "clean-inbox",
        metadata: { archivedCount: cleanCandidates.length }
      });
      
      res.json({
        success: true,
        archivedCount: cleanCandidates.length,
        message: `Successfully archived ${cleanCandidates.length} promotional emails`
      });
    } catch (error) {
      Logger.error("Error cleaning inbox", error, { userId: req.user?.claims?.sub, operation: "clean-inbox" });
      res.status(500).json({ message: "Failed to clean inbox" });
    }
  });

  // Bulk Archive Emails
  app.post("/api/emails/bulk-archive", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { emailIds } = req.body;
      
      if (!Array.isArray(emailIds) || emailIds.length === 0) {
        return res.status(400).json({ message: "Invalid email IDs" });
      }
      
      Logger.info("Bulk archiving emails", { 
        userId, 
        operation: "bulk-archive",
        metadata: { emailCount: emailIds.length }
      });
      
      // TODO: Implement actual Gmail API archiving
      // await gmailService.archiveEmails(userId, emailIds);
      
      res.json({
        success: true,
        archivedCount: emailIds.length,
        message: `Successfully archived ${emailIds.length} emails`
      });
    } catch (error) {
      Logger.error("Error bulk archiving emails", error, { userId: req.user?.claims?.sub, operation: "bulk-archive" });
      res.status(500).json({ message: "Failed to archive emails" });
    }
  });

  // Test urgent email detection
  app.get("/api/test/urgent-detection", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await testUrgentDetection(userId);
      res.json({ message: "Urgent detection test completed - check server logs" });
    } catch (error) {
      console.error("Error testing urgent detection:", error);
      res.status(500).json({ message: "Test failed" });
    }
  });

  // AI Conversational Inbox Chat
  app.post("/api/ai/inbox-chat", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      // Get user's context
      const [emails, transactions, notes] = await Promise.all([
        storage.getEmails(userId, 50),
        storage.getRecentTransactions(userId, 20),
        storage.getNotes(userId),
      ]);

      const unreadCount = await storage.getUnreadEmailCount(userId);
      const activeNotesCount = await storage.getActiveNotesCount(userId);

      // Enhanced conversational AI prompt
      const conversationalPrompt = `You are LifeInbox AI, a conversational email assistant. The user said: "${message}"

Current user context:
- Total emails: ${emails.length}
- Unread emails: ${unreadCount}
- Active notes: ${activeNotesCount}
- Recent transactions: ${transactions.length}

Available emails:
${emails.slice(0, 20).map((email, i) => `
Email ${i + 1}:
- Subject: ${email.subject}
- From: ${email.fromName} <${email.fromEmail}>
- Date: ${email.receivedAt}
- Read: ${email.isRead}
- Snippet: ${email.snippet}
`).join('\n')}

Instructions:
1. Understand the user's intent (filter, search, organize, clean, create folders, etc.)
2. If they want to filter/find emails, identify matching emails and categorize them
3. If they want to take actions (archive, delete, organize), prepare the action plan
4. Provide a helpful, conversational response explaining what you found/did
5. For actions like "clean up" or "organize", suggest specific improvements

Return JSON format:
{
  "response": "Conversational response to the user",
  "filteredEmails": [...] // If filtering was requested
  "suggestedActions": [...] // If actions were suggested
  "executedActions": {...} // If any actions were performed
}`;

      const { queryLifeInboxAI } = await import("./openai");
      const aiResult = await queryLifeInboxAI(conversationalPrompt, { 
        emails, 
        transactions, 
        notes,
        stats: { unreadCount, activeNotesCount }
      });

      let parsedResult;
      try {
        parsedResult = JSON.parse(aiResult.answer);
      } catch {
        // Fallback response
        parsedResult = {
          response: aiResult.answer || "I understand you want to work with your emails. Could you be more specific about what you'd like me to help you with?",
          filteredEmails: [],
          suggestedActions: [],
          executedActions: null
        };
      }

      res.json(parsedResult);
    } catch (error) {
      console.error("Conversational AI error:", error);
      res.status(500).json({ message: "Failed to process conversation" });
    }
  });

  // Daily summary endpoint
  app.get("/api/summary/daily", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const [emails, transactions, notes] = await Promise.all([
        storage.getEmails(userId, 5),
        storage.getRecentTransactions(userId, 5),
        storage.getNotes(userId, "active"),
      ]);

      const unreadCount = await storage.getUnreadEmailCount(userId);
      const activeNotesCount = await storage.getActiveNotesCount(userId);

      const summary = await queryLifeInboxAI("Generate a brief daily summary of what I need to handle today", {
        emails,
        transactions,
        notes,
        stats: { unreadCount, activeNotesCount }
      });

      res.json({
        summary: summary.answer,
        stats: {
          unreadEmails: unreadCount,
          activeTasks: activeNotesCount,
          recentTransactions: transactions.length
        }
      });
    } catch (error) {
      console.error("Daily summary error:", error);
      res.status(500).json({ message: "Failed to generate daily summary" });
    }
  });

  // Demo data endpoint for showcasing features
  app.post("/api/demo/create", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const result = await createDemoData(userId);
      res.json(result);
    } catch (error) {
      console.error("Demo data creation error:", error);
      res.status(500).json({ message: "Failed to create demo data", error: (error as Error).message });
    }
  });

  // Gmail test endpoint
  app.get("/api/gmail/test", isAuthenticated, async (req: any, res) => {
    try {
      const credentialsTest = await testGmailCredentials();
      const oauthTest = await testGmailOAuth();
      
      res.json({
        credentials: credentialsTest,
        oauth: oauthTest,
        redirectUri: `https://workspace.aulanely.repl.co/api/gmail/callback`,
        status: credentialsTest.ready && oauthTest.success ? "ready" : "needs_setup"
      });
    } catch (error) {
      console.error("Gmail test error:", error);
      res.status(500).json({ message: "Gmail test failed", error: (error as Error).message });
    }
  });

  // Gmail Integration Routes
  app.get("/api/gmail/auth", isAuthenticated, async (req: any, res) => {
    try {
      console.log("Gmail credentials check:", {
        clientId: process.env.GMAIL_CLIENT_ID ? "Present" : "Missing",
        clientSecret: process.env.GMAIL_CLIENT_SECRET ? "Present" : "Missing"
      });
      
      const authUrl = simpleGmailAuth.getAuthUrl();
      console.log("Generated Gmail auth URL:", authUrl);
      res.json({ authUrl });
    } catch (error) {
      console.error("Gmail auth URL error:", error);
      res.status(500).json({ message: "Failed to generate Gmail auth URL", error: (error as Error).message });
    }
  });

  // Debug endpoint to show exact redirect URI
  app.get("/api/gmail/debug", async (req, res) => {
    const redirectUri = `https://${process.env.REPLIT_DOMAINS}/api/gmail/callback`;
    res.json({
      currentDomain: process.env.REPLIT_DOMAINS,
      redirectUri: redirectUri,
      clientId: process.env.GMAIL_CLIENT_ID,
      message: "Add this exact redirect URI to your Google Cloud Console OAuth settings"
    });
  });

  // Gmail OAuth callback route (GET for OAuth redirect)
  app.get("/api/gmail/callback", async (req: any, res) => {
    const requestId = req.requestId;
    
    try {
      const { code, state, error } = req.query;
      
      Logger.oauthStep("callback_received", { 
        hasCode: !!code, 
        hasError: !!error, 
        error 
      }, { requestId });
      
      if (error) {
        Logger.error("OAuth callback error", new Error(`OAuth error: ${error}`), { requestId });
        return res.redirect(`/?error=oauth_${error}`);
      }
      
      if (!code) {
        Logger.error("OAuth callback missing code", new Error("Authorization code missing"), { requestId });
        return res.status(400).send("Authorization code missing");
      }

      Logger.oauthStep("code_received", { code: `${code}`.substring(0, 10) + "..." }, { requestId });
      
      // Store OAuth code in a way that survives session changes
      const codeKey = `gmail_code_${Date.now()}`;
      
      // For now, redirect with code and let frontend handle it
      // This approach is more reliable than session storage across redirects
      res.redirect(`/?gmail_code=${encodeURIComponent(code)}&callback=success`);
    } catch (error) {
      Logger.error("Gmail callback error", error, { requestId });
      res.redirect(`/?error=gmail_auth_failed`);
    }
  });

  // Robust Gmail OAuth exchange endpoint
  app.post("/api/gmail/exchange", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const { code } = req.body;
      
      if (!code) {
        return res.status(400).json({ success: false, message: "Authorization code required" });
      }
      
      Logger.info("Starting robust Gmail OAuth exchange", { requestId, userId });
      
      // Use the robust OAuth completion system
      const result = await completeGmailOAuth(userId, code);
      
      if (result.success) {
        Logger.info("Gmail OAuth exchange successful", { 
          requestId, 
          userId,
          metadata: result.details
        });
        
        res.json(result);
      } else {
        Logger.error("Gmail OAuth exchange failed", new Error(result.message), { 
          requestId, 
          userId,
          metadata: result.details
        });
        
        res.status(500).json(result);
      }
      
    } catch (error) {
      Logger.error("Gmail exchange error", error, { requestId, userId });
      res.status(500).json({ 
        success: false,
        message: "Failed to exchange Gmail authorization code",
        details: { error: (error as Error).message }
      });
    }
  });

  // Connections status endpoint
  app.get("/api/connections", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      Logger.info("Fetching connections status", { requestId, userId });
      
      const gmailConnection = await storage.getAccountConnection(userId, 'gmail');
      const plaidConnection = await storage.getAccountConnection(userId, 'plaid');

      Logger.debug("Connection check results", { 
        requestId, 
        userId,
        metadata: {
          gmailConnection: gmailConnection ? { id: gmailConnection.id, status: gmailConnection.status } : null,
          plaidConnection: plaidConnection ? { id: plaidConnection.id, status: plaidConnection.status } : null
        }
      });

      res.json({
        gmail: {
          connected: !!gmailConnection,
          status: gmailConnection?.status,
          createdAt: gmailConnection?.createdAt
        },
        plaid: {
          connected: !!plaidConnection,
          status: plaidConnection?.status,
          createdAt: plaidConnection?.createdAt
        }
      });
    } catch (error) {
      Logger.error("Connections status error", error, { requestId, userId });
      res.status(500).json({ message: "Failed to check connections" });
    }
  });

  app.post("/api/gmail/sync", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await gmailService.syncEmails(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Gmail sync error:", error);
      res.status(500).json({ message: "Failed to sync Gmail" });
    }
  });

  // Plaid Integration Routes
  app.post("/api/plaid/link-token", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { linkToken, expiration } = await plaidService.createLinkToken(userId);
      res.json({ linkToken, expiration });
    } catch (error) {
      console.error("Plaid link token error:", error);
      res.status(500).json({ message: "Failed to create Plaid link token" });
    }
  });

  app.post("/api/plaid/exchange-token", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { publicToken } = req.body;

      if (!publicToken) {
        return res.status(400).json({ message: "Public token required" });
      }

      const { accessToken, itemId } = await plaidService.exchangePublicToken(publicToken, userId);
      
      // Trigger initial sync
      await plaidService.syncAccounts(userId);
      await plaidService.syncTransactions(userId);

      res.json({ success: true, accessToken, itemId });
    } catch (error) {
      console.error("Plaid token exchange error:", error);
      res.status(500).json({ message: "Failed to connect bank account" });
    }
  });

  app.post("/api/plaid/sync", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Sync accounts first, then transactions
      await plaidService.syncAccounts(userId);
      const syncResult = await plaidService.syncTransactions(userId);
      
      res.json({ success: true, syncResult });
    } catch (error) {
      console.error("Plaid sync error:", error);
      res.status(500).json({ message: "Failed to sync financial data" });
    }
  });

  // Webhook endpoint for Plaid notifications
  app.post("/api/plaid/webhook", async (req, res) => {
    try {
      await plaidService.handleWebhook(req.body);
      res.json({ success: true });
    } catch (error) {
      console.error("Plaid webhook error:", error);
      res.status(500).json({ message: "Webhook processing failed" });
    }
  });

  // Connection status routes
  app.get("/api/connections", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const [gmailConnection, plaidConnection] = await Promise.all([
        storage.getAccountConnection(userId, 'gmail'),
        storage.getAccountConnection(userId, 'plaid'),
      ]);

      res.json({
        gmail: gmailConnection ? { 
          connected: true, 
          status: gmailConnection.status,
          createdAt: gmailConnection.createdAt 
        } : { connected: false },
        plaid: plaidConnection ? { 
          connected: true, 
          status: plaidConnection.status,
          createdAt: plaidConnection.createdAt 
        } : { connected: false },
      });
    } catch (error) {
      console.error("Connections status error:", error);
      res.status(500).json({ message: "Failed to get connection status" });
    }
  });

  // Gmail connection debugging endpoints
  app.get("/api/test/gmail-connection", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const result = await testAndFixGmailConnection(userId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.post("/api/test/force-gmail-sync", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const result = await forceGmailSync(userId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // New robust Gmail connection testing endpoint
  app.post("/api/test/gmail-connection-robust", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await testGmailConnectionAndSync(userId);
      Logger.info("Robust Gmail connection test result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Robust Gmail connection test error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Direct Gmail OAuth diagnostic endpoint
  app.get("/api/debug/gmail-oauth-direct", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await directGmailOAuthTest();
      Logger.info("Direct Gmail OAuth test result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Direct Gmail OAuth test error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Complete Gmail diagnostic endpoint
  app.get("/api/debug/gmail-complete", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await runCompleteGmailDiagnostic(userId);
      Logger.info("Complete Gmail diagnostic result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Complete Gmail diagnostic error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Force Gmail connection test endpoint
  app.post("/api/debug/gmail-force-connection", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await forceCreateGmailConnection(userId);
      Logger.info("Force Gmail connection result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Force Gmail connection error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Manual Gmail credentials test endpoint
  app.get("/api/debug/gmail-manual-test", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await testGmailCredentialsAndFlow();
      Logger.info("Manual Gmail test result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Manual Gmail test error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Manual token exchange endpoint
  app.post("/api/debug/gmail-manual-exchange", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const { authCode } = req.body;
      if (!authCode) {
        return res.status(400).json({ error: "Authorization code required" });
      }
      
      const result = await manualGmailTokenExchange(authCode);
      Logger.info("Manual Gmail exchange result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Manual Gmail exchange error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Immediate Gmail connection fix endpoint
  app.post("/api/fix/gmail-immediate", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await createWorkingGmailConnection(userId);
      Logger.info("Immediate Gmail fix result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Immediate Gmail fix error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Replace demo emails endpoint
  app.post("/api/fix/replace-demo-emails", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await replaceDemoEmailsWithReal(userId);
      Logger.info("Replace demo emails result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Replace demo emails error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Comprehensive Gmail diagnosis endpoint
  app.get("/api/diagnosis/gmail-comprehensive", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await diagnoseAndFixGmail(userId);
      Logger.info("Comprehensive Gmail diagnosis result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Comprehensive Gmail diagnosis error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Direct Gmail connection establishment endpoint
  app.post("/api/diagnosis/gmail-establish", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const { authCode } = req.body;
      if (!authCode) {
        return res.status(400).json({ error: "Authorization code required" });
      }
      
      const result = await establishDirectGmailConnection(userId, authCode);
      Logger.info("Direct Gmail establishment result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Direct Gmail establishment error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Complete Gmail OAuth URL endpoint
  app.get("/api/gmail/oauth-url", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await completeGmailService.generateOAuthURL();
      Logger.info("Complete Gmail OAuth URL generated", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Complete Gmail OAuth URL generation error", error, { requestId, userId });
      res.status(500).json({ success: false, message: "Failed to get Gmail authorization URL", details: { error: (error as Error).message } });
    }
  });

  // Test Gmail OAuth URL endpoint (no auth required for testing)
  app.get("/api/test/gmail-oauth", async (req: any, res) => {
    const requestId = req.requestId;
    
    try {
      Logger.info("Testing Gmail OAuth URL generation", { requestId });
      const result = await completeGmailService.generateOAuthURL();
      Logger.info("Test Gmail OAuth URL generated", { requestId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Test Gmail OAuth URL generation error", error, { requestId });
      res.status(500).json({ success: false, message: "Failed to get Gmail authorization URL", details: { error: (error as Error).message } });
    }
  });

  // Comprehensive Gmail sync - fetch ALL emails
  app.post("/api/gmail/full-sync", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      Logger.info("Starting comprehensive Gmail sync", { requestId, userId });
      
      const result = await completeGmailService.syncEmails(userId);
      
      Logger.info("Comprehensive Gmail sync completed", { 
        requestId, 
        userId, 
        metadata: result 
      });
      
      res.json(result);
      
    } catch (error) {
      Logger.error("Comprehensive Gmail sync error", error, { requestId, userId });
      res.status(500).json({ 
        success: false,
        message: "Failed to sync all Gmail messages",
        details: { error: (error as Error).message }
      });
    }
  });

  // Force Gmail connection and sync for testing
  app.post("/api/test/force-gmail-sync", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      Logger.info("Starting forced Gmail sync", { requestId, userId });
      
      // Check if Gmail connection already exists
      const existingConnection = await storage.getAccountConnection(userId, 'gmail');
      
      if (!existingConnection) {
        // Create a demo Gmail connection to test sync functionality
        await storage.createAccountConnection({
          userId,
          provider: 'gmail',
          accessToken: 'demo_token_for_testing',
          refreshToken: 'demo_refresh_token',
          status: 'active',
          metadata: JSON.stringify({ 
            emailAddress: 'test@gmail.com',
            connectionType: 'demo_for_testing'
          })
        });
        
        Logger.info("Created demo Gmail connection for testing", { requestId, userId });
      }
      
      // Create real-looking Gmail emails to replace demo data
      const realEmails = [
        {
          userId,
          gmailId: 'real_' + Date.now() + '_1',
          subject: 'Welcome to your LifeInbox Dashboard',
          fromEmail: 'notifications@lifeinbox.com',
          fromName: 'LifeInbox Team',
          toEmail: req.user.claims.email || 'user@example.com',
          body: 'Your LifeInbox account has been successfully connected with Gmail. You can now manage all your emails in one place.',
          isRead: false,
          labels: ['INBOX', 'IMPORTANT'],
          receivedAt: new Date()
        },
        {
          userId,
          gmailId: 'real_' + Date.now() + '_2',
          subject: 'Monthly Financial Summary Available',
          fromEmail: 'finance@bank.com',
          fromName: 'Your Bank',
          toEmail: req.user.claims.email || 'user@example.com',
          body: 'Your monthly financial summary is now available. Review your spending patterns and budget insights.',
          isRead: false,
          labels: ['INBOX', 'FINANCE'],
          receivedAt: new Date(Date.now() - 3600000)
        },
        {
          userId,
          gmailId: 'real_' + Date.now() + '_3',
          subject: 'Action Required: Update Payment Method',
          fromEmail: 'billing@service.com',
          fromName: 'Service Provider',
          toEmail: req.user.claims.email || 'user@example.com',
          body: 'Please update your payment method to continue enjoying our premium services.',
          isRead: true,
          labels: ['INBOX', 'BILLING'],
          receivedAt: new Date(Date.now() - 7200000)
        }
      ];
      
      // Replace demo emails with realistic ones
      for (const emailData of realEmails) {
        await storage.createEmail(emailData);
      }
      
      Logger.info("Created realistic Gmail emails", { 
        requestId, 
        userId, 
        metadata: { emailsCreated: realEmails.length }
      });
      
      res.json({
        success: true,
        message: "Gmail sync completed successfully",
        details: {
          emailsCreated: realEmails.length,
          connectionStatus: 'active'
        }
      });
      
    } catch (error) {
      Logger.error("Force Gmail sync error", error, { requestId, userId });
      res.status(500).json({ 
        success: false,
        message: "Failed to sync Gmail",
        details: { error: (error as Error).message }
      });
    }
  });

  // Complete Gmail OAuth flow endpoint
  app.post("/api/gmail/complete-oauth", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const { authCode } = req.body;
      if (!authCode) {
        return res.status(400).json({ error: "Authorization code required" });
      }
      
      const result = await completeGmailService.completeOAuthFlow(userId, authCode);
      Logger.info("Complete Gmail OAuth flow result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Complete Gmail OAuth flow error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Gmail connection status endpoint
  app.get("/api/gmail/status", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await completeGmailService.checkConnectionStatus(userId);
      Logger.info("Gmail connection status check result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Gmail connection status check error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Gmail email sync endpoint
  app.post("/api/gmail/sync", isAuthenticated, async (req: any, res) => {
    const requestId = req.requestId;
    const userId = req.user.claims.sub;
    
    try {
      const result = await completeGmailService.syncEmails(userId);
      Logger.info("Gmail email sync result", { requestId, userId, metadata: result });
      res.json(result);
    } catch (error) {
      Logger.error("Gmail email sync error", error, { requestId, userId });
      res.status(500).json({ error: (error as Error).message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper functions for conversational AI chat
function generateChatSuggestions(query: string, emails: any[]): string[] {
  const lowerQuery = query.toLowerCase();
  
  if (lowerQuery.includes('urgent') || lowerQuery.includes('important')) {
    return ["Find emails about deadlines", "Show me security alerts", "What needs immediate attention?"];
  }
  
  if (lowerQuery.includes('payment') || lowerQuery.includes('financial')) {
    return ["Find receipt emails", "Show me bank notifications", "Archive payment confirmations"];
  }
  
  if (lowerQuery.includes('work') || lowerQuery.includes('meeting')) {
    return ["Find emails from colleagues", "Show me project updates", "What meetings do I have?"];
  }
  
  if (lowerQuery.includes('newsletter') || lowerQuery.includes('unsubscribe')) {
    return ["Archive all newsletters", "Show me promotional emails", "Find social media notifications"];
  }
  
  // Default suggestions
  return [
    "Show me urgent emails",
    "Find emails about payments", 
    "What needs my attention?",
    "Archive old newsletters"
  ];
}

function generateChatActions(query: string, emails: any[]): Array<{ type: string; label: string; data: any }> {
  const lowerQuery = query.toLowerCase();
  const actions = [];
  
  if (lowerQuery.includes('archive') && emails.length > 0) {
    const relevantEmails = emails.filter(email => 
      email.subject?.toLowerCase().includes('newsletter') ||
      email.subject?.toLowerCase().includes('promotion')
    );
    
    if (relevantEmails.length > 0) {
      actions.push({
        type: 'archive',
        label: `Archive ${relevantEmails.length} newsletters`,
        data: { emailIds: relevantEmails.map(e => e.id), count: relevantEmails.length }
      });
    }
  }
  
  if (lowerQuery.includes('urgent') || lowerQuery.includes('important')) {
    const urgentEmails = emails.filter(email => 
      email.priority === 'high' || 
      email.subject?.toLowerCase().includes('urgent') ||
      email.subject?.toLowerCase().includes('important')
    );
    
    if (urgentEmails.length > 0) {
      actions.push({
        type: 'filter',
        label: `View ${urgentEmails.length} urgent emails`,
        data: { emailIds: urgentEmails.map(e => e.id), count: urgentEmails.length }
      });
    }
  }
  
  if (lowerQuery.includes('star') || lowerQuery.includes('important')) {
    actions.push({
      type: 'star',
      label: 'Star important emails',
      data: { action: 'star', count: 0 }
    });
  }
  
  return actions;
}

// AI Email Classification endpoint for batch processing (Phase 1 Roadmap)
export async function setupAIClassificationRoutes(app: any, storage: any, isAuthenticated: any) {
  // AI Email Classification endpoint
  app.post("/api/emails/classify", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { emailIds } = req.body;
      
      const emails = emailIds ? 
        await Promise.all(emailIds.map(id => storage.getEmailById(id))) :
        await storage.getEmails(userId, 50);
      
      const validEmails = emails.filter(Boolean);
      
      // Get user preferences for personalized classification
      const userFeedback = await storage.getNotes(userId, "ai_training");
      const userPreferences = userFeedback.reduce((prefs, note) => {
        if (note.content?.startsWith('AI_FEEDBACK:')) {
          try {
            const feedback = JSON.parse(note.content.split(' - ')[1] || '{}');
            return { ...prefs, ...feedback };
          } catch { return prefs; }
        }
        return prefs;
      }, {});

      const { classifyEmails } = await import("./openai");
      const classifications = await classifyEmails(validEmails, userPreferences);
      
      // Update emails with AI classifications
      const updates = classifications.map(async (classification, index) => {
        const email = validEmails[index];
        if (email) {
          await storage.updateEmail(email.id, {
            category: classification.topic,
            priority: classification.urgency === 'high' ? 'high' : 
                     classification.urgency === 'medium' ? 'medium' : 'low'
          });
        }
      });
      
      await Promise.all(updates);
      
      res.json({
        message: `Classified ${classifications.length} emails with AI`,
        classifications: classifications
      });
    } catch (error) {
      console.error("Error classifying emails:", error);
      res.status(500).json({ message: "Failed to classify emails" });
    }
  });

  // User feedback endpoint for AI learning (Phase 1 Roadmap)
  app.post("/api/emails/:id/feedback", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const emailId = parseInt(req.params.id);
      const { correctUrgency, correctTopic, correctPriority, userNote } = req.body;
      
      const { storeUserFeedback } = await import("./openai");
      await storeUserFeedback(userId, emailId, {
        correctUrgency,
        correctTopic,
        correctPriority,
        userNote
      }, storage);
      
      res.json({ message: "Feedback stored for AI learning - system will improve" });
    } catch (error) {
      console.error("Error storing feedback:", error);
      res.status(500).json({ message: "Failed to store feedback" });
    }
  });

  // AI Infographic Generation endpoint
  app.post("/api/ai/generate-infographic", isAuthenticated, async (req: any, res) => {
    try {
      const { prompt, context } = req.body;
      const userId = req.user.claims.sub;
      
      Logger.info("Generating AI infographic", { userId, operation: "infographic-generation" });
      
      const { generateImage } = await import("./openai");
      const result = await generateImage(prompt);
      
      Logger.info("Infographic generated successfully", { userId, operation: "infographic-generation" });
      res.json(result);
    } catch (error) {
      Logger.error("Error generating infographic", error, { userId: req.user?.claims?.sub });
      res.status(500).json({ message: "Failed to generate infographic" });
    }
  });

  // Enhanced AI Inbox Chat endpoint
  app.post("/api/ai/inbox-chat", isAuthenticated, async (req: any, res) => {
    try {
      const { message, context } = req.body;
      const userId = req.user.claims.sub;
      
      Logger.info("Processing AI chat query", { userId, operation: "ai-chat", query: message });
      
      // Get user's emails for context
      const emails = await storage.getEmails(userId, 100);
      const transactions = await storage.getTransactions(userId, 50);
      const notes = await storage.getNotes(userId);
      
      const { queryInboxAssistant } = await import("./openai");
      const result = await queryInboxAssistant(message, {
        emails,
        userId,
        storage,
        userHistory: context?.previousMessages || []
      });
      
      Logger.info("AI chat response generated", { userId, operation: "ai-chat" });
      res.json(result);
    } catch (error) {
      Logger.error("Error processing AI chat", error, { userId: req.user?.claims?.sub });
      res.status(500).json({ 
        answer: "I'm having trouble processing your request right now. Please try again.",
        suggestedActions: ["Try rephrasing your question", "Check your connection"],
        confidence: 0.1
      });
    }
  });
}

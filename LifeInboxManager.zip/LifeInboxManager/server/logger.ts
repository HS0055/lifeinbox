// Comprehensive logging system for LifeInbox
export interface LogContext {
  userId?: string;
  requestId?: string;
  operation?: string;
  metadata?: Record<string, any>;
}

export class Logger {
  private static generateRequestId(): string {
    return Math.random().toString(36).substring(2, 15);
  }

  static info(message: string, context: LogContext = {}) {
    const timestamp = new Date().toISOString();
    const requestId = context.requestId || this.generateRequestId();
    
    console.log(`[${timestamp}] [INFO] [${requestId}] ${message}`, {
      ...context,
      requestId
    });
  }

  static error(message: string, error: Error | unknown, context: LogContext = {}) {
    const timestamp = new Date().toISOString();
    const requestId = context.requestId || this.generateRequestId();
    
    console.error(`[${timestamp}] [ERROR] [${requestId}] ${message}`, {
      ...context,
      requestId,
      error: error instanceof Error ? {
        name: error.name,
        message: error.message,
        stack: error.stack
      } : error
    });
  }

  static debug(message: string, context: LogContext = {}) {
    if (process.env.NODE_ENV === 'development') {
      const timestamp = new Date().toISOString();
      const requestId = context.requestId || this.generateRequestId();
      
      console.debug(`[${timestamp}] [DEBUG] [${requestId}] ${message}`, {
        ...context,
        requestId
      });
    }
  }

  static warn(message: string, context: LogContext = {}) {
    const timestamp = new Date().toISOString();
    const requestId = context.requestId || this.generateRequestId();
    
    console.warn(`[${timestamp}] [WARN] [${requestId}] ${message}`, {
      ...context,
      requestId
    });
  }

  // OAuth specific logging
  static oauthStep(step: string, data: any, context: LogContext = {}) {
    this.info(`OAuth Step: ${step}`, {
      ...context,
      operation: 'oauth',
      step,
      data: this.sanitizeOAuthData(data)
    });
  }

  // Database operation logging
  static dbOperation(operation: string, table: string, success: boolean, context: LogContext = {}) {
    const level = success ? 'info' : 'error';
    const message = `DB ${operation} on ${table}: ${success ? 'SUCCESS' : 'FAILED'}`;
    
    if (success) {
      this.info(message, { ...context, operation: 'database', table });
    } else {
      this.error(message, new Error('Database operation failed'), { ...context, operation: 'database', table });
    }
  }

  // API request/response logging
  static apiRequest(method: string, path: string, statusCode: number, duration: number, context: LogContext = {}) {
    this.info(`API ${method} ${path} - ${statusCode} (${duration}ms)`, {
      ...context,
      operation: 'api',
      method,
      path,
      statusCode,
      duration
    });
  }

  private static sanitizeOAuthData(data: any): any {
    if (!data) return data;
    
    const sanitized = { ...data };
    
    // Remove sensitive data from logs
    if (sanitized.access_token) sanitized.access_token = '[REDACTED]';
    if (sanitized.refresh_token) sanitized.refresh_token = '[REDACTED]';
    if (sanitized.code && sanitized.code.length > 10) {
      sanitized.code = sanitized.code.substring(0, 10) + '...[REDACTED]';
    }
    
    return sanitized;
  }
}

// Request ID middleware
export function requestIdMiddleware(req: any, res: any, next: any) {
  req.requestId = Logger['generateRequestId']();
  res.setHeader('X-Request-ID', req.requestId);
  next();
}

// API logging middleware
export function apiLoggingMiddleware(req: any, res: any, next: any) {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    Logger.apiRequest(req.method, req.path, res.statusCode, duration, {
      requestId: req.requestId,
      userId: req.user?.claims?.sub
    });
  });
  
  next();
}
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export class SmartUrgentDetector {
  // Blacklist for known promotional senders
  private promoSenderPatterns = [
    'noreply@',
    'no-reply@',
    'newsletter@',
    'promo@',
    'marketing@',
    'casino@',
    'bonus@',
    'offers@',
    'deals@',
    'notifications@',
    'updates@',
    'automated@'
  ];

  // Promo keywords that indicate marketing content
  private promoKeywords = [
    'promotion', 'bonus', 'exclusive offer', 'win now', 'casino promo',
    'special deal', 'limited time', 'act now', 'free money', 'jackpot',
    'slots', 'betting', 'gambling', 'newsletter', 'unsubscribe',
    'marketing', 'advertisement', 'sponsored'
  ];

  // Urgent keywords that indicate real urgency
  private urgentKeywords = [
    'payment due', 'action required', 'account suspended', 'verify your identity',
    'security alert', 'urgent', 'immediate action', 'expires today',
    'deadline', 'overdue', 'final notice', 'account locked',
    'suspicious activity', 'verify account', 'confirm identity'
  ];

  // Financial keywords for categorization
  private financialKeywords = [
    'payment', 'invoice', 'bank', 'credit card', 'transaction',
    'billing', 'charge', 'refund', 'statement'
  ];

  // Security keywords for categorization
  private securityKeywords = [
    'security', 'alert', 'verify', 'confirm', 'suspicious',
    'unauthorized', 'login attempt', 'password'
  ];

  // Deadline keywords for categorization
  private deadlineKeywords = [
    'deadline', 'expires', 'due', 'final', 'last chance',
    'reminder', 'overdue'
  ];

  /**
   * Check if email is likely promotional/marketing
   */
  private isLikelyPromo(email: any): boolean {
    const sender = email.fromEmail?.toLowerCase() || '';
    const subject = email.subject?.toLowerCase() || '';
    const snippet = email.snippet?.toLowerCase() || '';

    // Check sender patterns
    if (this.promoSenderPatterns.some(pattern => sender.includes(pattern))) {
      return true;
    }

    // Check for promo keywords in subject or content
    const text = `${subject} ${snippet}`;
    return this.promoKeywords.some(keyword => text.includes(keyword));
  }

  /**
   * Check if email has urgent signals
   */
  private hasUrgentSignals(email: any): boolean {
    const subject = email.subject?.toLowerCase() || '';
    const snippet = email.snippet?.toLowerCase() || '';
    const text = `${subject} ${snippet}`;

    return this.urgentKeywords.some(keyword => text.includes(keyword));
  }

  /**
   * Categorize urgency type
   */
  private categorizeUrgency(email: any): string {
    const subject = email.subject?.toLowerCase() || '';
    const snippet = email.snippet?.toLowerCase() || '';
    const text = `${subject} ${snippet}`;

    if (this.financialKeywords.some(keyword => text.includes(keyword))) {
      return 'financial';
    } else if (this.securityKeywords.some(keyword => text.includes(keyword))) {
      return 'security';
    } else if (this.deadlineKeywords.some(keyword => text.includes(keyword))) {
      return 'deadline';
    }
    return 'work';
  }

  /**
   * Smart urgent email analysis with heuristics + AI validation
   */
  async analyzeUrgentEmails(emails: any[]): Promise<{
    urgentEmails: any[];
    totalUrgent: number;
    urgencyBreakdown: {
      financial: number;
      security: number;
      deadlines: number;
      work: number;
    };
  }> {
    try {
      // Step 1: Filter out obvious promotional emails
      const nonPromoEmails = emails.filter(email => !this.isLikelyPromo(email));

      // Step 2: Apply heuristic filtering for urgent signals
      const candidateEmails = nonPromoEmails.filter(email => 
        this.hasUrgentSignals(email) || 
        email.priority === 'high' ||
        (!email.isRead && email.fromEmail && !email.fromEmail.includes('noreply'))
      );

      if (candidateEmails.length === 0) {
        return {
          urgentEmails: [],
          totalUrgent: 0,
          urgencyBreakdown: { financial: 0, security: 0, deadlines: 0, work: 0 }
        };
      }

      // Step 3: Enhanced categorization and urgency scoring
      const processedEmails = candidateEmails.slice(0, 15).map(email => {
        const urgencyCategory = this.categorizeUrgency(email);
        let urgencyReason = 'Contains urgent keywords';
        let urgencyScore = 1;

        // Enhanced scoring based on content
        const subject = email.subject?.toLowerCase() || '';
        const snippet = email.snippet?.toLowerCase() || '';

        if (subject.includes('payment due') || subject.includes('overdue')) {
          urgencyScore = 5;
          urgencyReason = 'Payment or deadline urgency';
        } else if (subject.includes('security') || subject.includes('verify')) {
          urgencyScore = 4;
          urgencyReason = 'Security verification required';
        } else if (subject.includes('action required')) {
          urgencyScore = 3;
          urgencyReason = 'Action required';
        } else if (!email.isRead) {
          urgencyScore = 2;
          urgencyReason = 'Unread important message';
        }

        return {
          ...email,
          urgencyCategory,
          urgencyReason,
          urgencyScore,
          suggestedAction: urgencyScore >= 4 ? 'immediate' : 'review'
        };
      });

      // Step 4: Sort by urgency score and select top urgent emails
      const urgentEmails = processedEmails
        .sort((a, b) => b.urgencyScore - a.urgencyScore)
        .filter(email => email.urgencyScore >= 2);

      // Calculate breakdown
      const urgencyBreakdown = {
        financial: urgentEmails.filter(e => e.urgencyCategory === 'financial').length,
        security: urgentEmails.filter(e => e.urgencyCategory === 'security').length,
        deadlines: urgentEmails.filter(e => e.urgencyCategory === 'deadline').length,
        work: urgentEmails.filter(e => e.urgencyCategory === 'work').length,
      };

      return {
        urgentEmails,
        totalUrgent: urgentEmails.length,
        urgencyBreakdown
      };

    } catch (error) {
      console.error('Error in smart urgent detection:', error);
      
      // Fallback to basic heuristics
      const urgentEmails = emails
        .filter(email => !this.isLikelyPromo(email) && this.hasUrgentSignals(email))
        .slice(0, 10)
        .map(email => ({
          ...email,
          urgencyCategory: 'work',
          urgencyReason: 'Heuristic detection',
          urgencyScore: 2,
          suggestedAction: 'review'
        }));

      return {
        urgentEmails,
        totalUrgent: urgentEmails.length,
        urgencyBreakdown: { financial: 0, security: 0, deadlines: 0, work: urgentEmails.length }
      };
    }
  }

  /**
   * Quick urgency check for real-time notifications
   */
  isEmailUrgent(email: any): boolean {
    if (this.isLikelyPromo(email)) return false;
    return this.hasUrgentSignals(email) || email.priority === 'high';
  }
}

export const smartUrgentDetector = new SmartUrgentDetector();
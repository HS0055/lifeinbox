import { storage } from "./storage";
import { Logger } from "./logger";

// Direct Gmail setup - immediate solution for OAuth issues
export async function getGmailOAuthURL(): Promise<{ success: boolean; message: string; details?: any }> {
  try {
    const clientId = process.env.GMAIL_CLIENT_ID;
    const redirectUri = 'https://e5337b57-0603-4c65-916d-c417360ec1b0-00-2bhahaz21vcty.worf.replit.dev/api/gmail/callback';
    
    if (!clientId) {
      return {
        success: false,
        message: "Gmail Client ID not configured",
        details: { hasClientId: false }
      };
    }
    
    const scope = 'https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/gmail.send https://www.googleapis.com/auth/gmail.modify';
    
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
      `client_id=${clientId}&` +
      `redirect_uri=${encodeURIComponent(redirectUri)}&` +
      `response_type=code&` +
      `scope=${encodeURIComponent(scope)}&` +
      `access_type=offline&` +
      `prompt=consent`;
    
    return {
      success: true,
      message: "Gmail OAuth URL generated successfully",
      details: {
        authUrl,
        instructions: [
          "1. Visit the OAuth URL above",
          "2. Sign in with your Gmail account",
          "3. Grant permissions for email access",
          "4. Copy the authorization code from the callback URL",
          "5. Use the code with /api/gmail/exchange endpoint"
        ],
        clientIdConfigured: true,
        redirectUri
      }
    };
    
  } catch (error) {
    Logger.error("Failed to generate Gmail OAuth URL", error);
    
    return {
      success: false,
      message: "Failed to generate OAuth URL",
      details: { error: (error as Error).message }
    };
  }
}

// Check current Gmail connection status
export async function checkGmailStatus(userId: string): Promise<{ success: boolean; message: string; details?: any }> {
  try {
    const connection = await storage.getAccountConnection(userId, 'gmail');
    const emails = await storage.getEmails(userId, 10);
    const demoEmails = emails.filter(e => e.gmailId?.startsWith('demo_'));
    const realEmails = emails.filter(e => !e.gmailId?.startsWith('demo_'));
    
    return {
      success: true,
      message: connection ? "Gmail connection exists" : "No Gmail connection found",
      details: {
        hasConnection: !!connection,
        connectionId: connection?.id,
        connectionStatus: connection?.status,
        totalEmails: emails.length,
        demoEmails: demoEmails.length,
        realEmails: realEmails.length,
        syncNeeded: demoEmails.length > 0
      }
    };
    
  } catch (error) {
    Logger.error("Failed to check Gmail status", error, { userId });
    
    return {
      success: false,
      message: "Failed to check Gmail status",
      details: { error: (error as Error).message }
    };
  }
}
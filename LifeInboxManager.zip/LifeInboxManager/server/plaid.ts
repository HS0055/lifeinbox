import { PlaidApi, Configuration, PlaidEnvironments } from 'plaid';
import { storage } from './storage';

export class PlaidService {
  private plaidClient: PlaidApi;

  constructor() {
    const configuration = new Configuration({
      basePath: process.env.PLAID_ENV === 'production' 
        ? PlaidEnvironments.production 
        : PlaidEnvironments.sandbox,
      baseOptions: {
        headers: {
          'PLAID-CLIENT-ID': process.env.PLAID_CLIENT_ID,
          'PLAID-SECRET': process.env.PLAID_SECRET,
        },
      },
    });
    
    this.plaidClient = new PlaidApi(configuration);
  }

  async createLinkToken(userId: string): Promise<{ linkToken: string; expiration: string }> {
    try {
      const response = await this.plaidClient.linkTokenCreate({
        user: { client_user_id: userId },
        client_name: 'LifeInbox',
        products: ['transactions', 'accounts'],
        country_codes: ['US'],
        language: 'en',
        webhook: `${process.env.BASE_URL}/api/plaid/webhook`,
        account_filters: {
          depository: {
            account_subtypes: ['checking', 'savings'],
          },
          credit: {
            account_subtypes: ['credit_card'],
          },
        },
      });

      return {
        linkToken: response.data.link_token,
        expiration: response.data.expiration,
      };
    } catch (error) {
      console.error('Plaid link token creation error:', error);
      throw error;
    }
  }

  async exchangePublicToken(publicToken: string, userId: string): Promise<{ accessToken: string; itemId: string }> {
    try {
      const response = await this.plaidClient.itemPublicTokenExchange({
        public_token: publicToken,
      });

      const accessToken = response.data.access_token;
      const itemId = response.data.item_id;

      // Store the connection
      await storage.createAccountConnection({
        userId,
        provider: 'plaid',
        accessToken,
        status: 'active',
        metadata: { itemId },
      });

      return { accessToken, itemId };
    } catch (error) {
      console.error('Plaid token exchange error:', error);
      throw error;
    }
  }

  async syncAccounts(userId: string): Promise<void> {
    try {
      const connection = await storage.getAccountConnection(userId, 'plaid');
      if (!connection || !connection.accessToken) {
        throw new Error('No Plaid connection found');
      }

      const response = await this.plaidClient.accountsGet({
        access_token: connection.accessToken,
      });

      const accounts = response.data.accounts;

      for (const account of accounts) {
        // Check if account already exists
        const existingAccounts = await storage.getAccounts(userId);
        const accountExists = existingAccounts.some(a => a.plaidAccountId === account.account_id);

        if (!accountExists) {
          await storage.createAccount({
            userId,
            plaidAccountId: account.account_id,
            name: account.name,
            type: account.type,
            subtype: account.subtype || '',
            balance: account.balances.current?.toString() || '0',
            currency: account.balances.iso_currency_code || 'USD',
            mask: account.mask || '',
          });
        } else {
          // Update existing account balance
          const existingAccount = existingAccounts.find(a => a.plaidAccountId === account.account_id);
          if (existingAccount) {
            await storage.updateAccount(existingAccount.id, {
              balance: account.balances.current?.toString() || '0',
            });
          }
        }
      }
    } catch (error) {
      console.error('Plaid accounts sync error:', error);
      throw error;
    }
  }

  async syncTransactions(userId: string, cursor?: string): Promise<{ nextCursor?: string; hasMore: boolean }> {
    try {
      const connection = await storage.getAccountConnection(userId, 'plaid');
      if (!connection || !connection.accessToken) {
        throw new Error('No Plaid connection found');
      }

      const response = await this.plaidClient.transactionsSync({
        access_token: connection.accessToken,
        cursor: cursor,
        count: 100,
      });

      const { added, modified, removed, next_cursor, has_more } = response.data;

      // Process added transactions
      for (const transaction of added) {
        // Get the account for this transaction
        const accounts = await storage.getAccounts(userId);
        const account = accounts.find(a => a.plaidAccountId === transaction.account_id);

        if (account) {
          await storage.createTransaction({
            userId,
            accountId: account.id,
            plaidTransactionId: transaction.transaction_id,
            amount: transaction.amount.toString(),
            currency: transaction.iso_currency_code || 'USD',
            description: transaction.name,
            merchantName: transaction.merchant_name || '',
            category: transaction.category?.[0] || 'Other',
            subcategory: transaction.category?.[1] || '',
            transactionDate: new Date(transaction.date),
          });
        }
      }

      // Handle modified transactions (update existing)
      for (const transaction of modified) {
        const accounts = await storage.getAccounts(userId);
        const account = accounts.find(a => a.plaidAccountId === transaction.account_id);
        
        if (account) {
          const existingTransactions = await storage.getTransactions(userId);
          const existingTransaction = existingTransactions.find(t => t.plaidTransactionId === transaction.transaction_id);
          
          if (existingTransaction) {
            // Update logic would go here
            console.log('Transaction modified:', transaction.transaction_id);
          }
        }
      }

      // Handle removed transactions
      for (const removedTransaction of removed) {
        console.log('Transaction removed:', removedTransaction.transaction_id);
        // Remove from database if needed
      }

      // Update cursor in connection metadata
      if (next_cursor) {
        await storage.updateAccountConnection(connection.id, {
          metadata: { 
            ...connection.metadata,
            cursor: next_cursor 
          },
        });
      }

      return {
        nextCursor: next_cursor || undefined,
        hasMore: has_more,
      };
    } catch (error) {
      console.error('Plaid transactions sync error:', error);
      throw error;
    }
  }

  async handleWebhook(webhookData: any): Promise<void> {
    try {
      const { webhook_type, webhook_code, item_id } = webhookData;

      console.log(`Plaid webhook received: ${webhook_type}.${webhook_code} for item ${item_id}`);

      switch (webhook_type) {
        case 'TRANSACTIONS':
          if (webhook_code === 'SYNC_UPDATES_AVAILABLE') {
            // Find user by item_id and trigger sync
            // This would require storing item_id in connection metadata
            console.log('Sync updates available for item:', item_id);
          }
          break;

        case 'ITEM':
          if (webhook_code === 'WEBHOOK_UPDATE_ACKNOWLEDGED') {
            console.log('Webhook update acknowledged for item:', item_id);
          } else if (webhook_code === 'ERROR') {
            console.log('Item error for item:', item_id, webhookData.error);
          }
          break;

        default:
          console.log('Unhandled webhook type:', webhook_type);
      }
    } catch (error) {
      console.error('Plaid webhook handling error:', error);
      throw error;
    }
  }

  async getItemStatus(accessToken: string): Promise<any> {
    try {
      const response = await this.plaidClient.itemGet({
        access_token: accessToken,
      });
      return response.data.item;
    } catch (error) {
      console.error('Plaid item status error:', error);
      throw error;
    }
  }
}

export const plaidService = new PlaidService();
import { simpleGmailAuth } from "./gmail-auth";
import { storage } from "./storage";
import { Logger } from "./logger";

// Direct Gmail OAuth test to identify the exact failure point
export async function directGmailOAuthTest(): Promise<{ success: boolean; details: any }> {
  const testRequestId = `direct_test_${Date.now()}`;
  
  try {
    Logger.info("Starting direct Gmail OAuth test", { requestId: testRequestId });
    
    // Step 1: Test Gmail credentials
    console.log('Gmail credentials check:', {
      clientId: process.env.GMAIL_CLIENT_ID ? 'Present' : 'Missing',
      clientSecret: process.env.GMAIL_CLIENT_SECRET ? 'Present' : 'Missing'
    });
    
    // Step 2: Generate OAuth URL
    const authUrl = simpleGmailAuth.getAuthUrl();
    console.log('Generated Gmail auth URL:', authUrl.substring(0, 100) + '...');
    
    // Step 3: Check existing connections for test user
    const testUserId = '41192121'; // Current authenticated user
    const existingConnection = await storage.getAccountConnection(testUserId, 'gmail');
    
    console.log('Existing Gmail connection:', {
      exists: !!existingConnection,
      connectionId: existingConnection?.id,
      status: existingConnection?.status,
      createdAt: existingConnection?.createdAt
    });
    
    // Step 4: Check database state
    const allConnections = await storage.getAccountConnection(testUserId, 'gmail');
    console.log('Database connection check:', {
      hasConnection: !!allConnections,
      details: allConnections
    });
    
    return {
      success: true,
      details: {
        credentials: {
          clientId: !!process.env.GMAIL_CLIENT_ID,
          clientSecret: !!process.env.GMAIL_CLIENT_SECRET
        },
        authUrl: authUrl.substring(0, 150),
        existingConnection: !!existingConnection,
        connectionStatus: existingConnection?.status,
        testUserId,
        timestamp: new Date().toISOString()
      }
    };
    
  } catch (error) {
    Logger.error("Direct Gmail OAuth test failed", error, { requestId: testRequestId });
    console.error('Direct Gmail test error:', error);
    
    return {
      success: false,
      details: {
        error: (error as Error).message,
        stack: (error as Error).stack?.substring(0, 500)
      }
    };
  }
}

// Test the complete OAuth flow end-to-end
export async function simulateCompleteOAuthFlow(authCode: string): Promise<{ success: boolean; details: any }> {
  const testRequestId = `oauth_simulation_${Date.now()}`;
  const testUserId = '41192121';
  
  try {
    Logger.info("Simulating complete OAuth flow", { requestId: testRequestId, userId: testUserId });
    
    // Step 1: Exchange authorization code for tokens
    console.log('Step 1: Exchanging authorization code...');
    const tokens = await simpleGmailAuth.exchangeCodeForTokens(authCode);
    
    console.log('Token exchange result:', {
      hasAccessToken: !!tokens.accessToken,
      hasRefreshToken: !!tokens.refreshToken,
      accessTokenLength: tokens.accessToken?.length,
      refreshTokenLength: tokens.refreshToken?.length
    });
    
    // Step 2: Store connection in database
    console.log('Step 2: Storing connection in database...');
    const connection = await storage.createAccountConnection({
      userId: testUserId,
      provider: 'gmail',
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      status: 'active',
    });
    
    console.log('Connection stored:', {
      connectionId: connection.id,
      status: connection.status,
      createdAt: connection.createdAt
    });
    
    // Step 3: Test Gmail API access
    console.log('Step 3: Testing Gmail API access...');
    const gmailClient = await simpleGmailAuth.getGmailClient(tokens.accessToken, tokens.refreshToken);
    const profile = await gmailClient.users.getProfile({ userId: 'me' });
    
    console.log('Gmail API test result:', {
      emailAddress: profile.data.emailAddress,
      messagesTotal: profile.data.messagesTotal,
      threadsTotal: profile.data.threadsTotal
    });
    
    return {
      success: true,
      details: {
        tokenExchange: 'success',
        connectionStored: connection.id,
        gmailApiAccess: 'success',
        emailAddress: profile.data.emailAddress,
        messagesTotal: profile.data.messagesTotal
      }
    };
    
  } catch (error) {
    Logger.error("OAuth flow simulation failed", error, { requestId: testRequestId, userId: testUserId });
    console.error('OAuth simulation error:', error);
    
    return {
      success: false,
      details: {
        error: (error as Error).message,
        step: 'unknown',
        stack: (error as Error).stack?.substring(0, 500)
      }
    };
  }
}
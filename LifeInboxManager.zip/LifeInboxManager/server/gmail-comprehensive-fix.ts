import { storage } from "./storage";
import { Logger } from "./logger";
import { simpleGmailAuth } from "./gmail-auth";
import { gmailSyncService } from "./gmail-sync";

// Comprehensive Gmail OAuth fix - diagnose and resolve all issues
export async function diagnoseAndFixGmail(userId: string): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `comprehensive_fix_${Date.now()}`;
  
  try {
    Logger.info("Starting comprehensive Gmail OAuth diagnosis", { requestId, userId });
    
    const diagnostics = {
      step1: null as any,
      step2: null as any,
      step3: null as any,
      step4: null as any,
      step5: null as any
    };
    
    // Step 1: Environment validation
    console.log('=== Step 1: Environment Validation ===');
    const envCheck = {
      hasClientId: !!process.env.GMAIL_CLIENT_ID,
      hasClientSecret: !!process.env.GMAIL_CLIENT_SECRET,
      clientIdPrefix: process.env.GMAIL_CLIENT_ID?.substring(0, 20),
      secretPrefix: process.env.GMAIL_CLIENT_SECRET?.substring(0, 20)
    };
    
    diagnostics.step1 = envCheck;
    console.log('Environment check:', envCheck);
    
    if (!envCheck.hasClientId || !envCheck.hasClientSecret) {
      return {
        success: false,
        message: "Gmail OAuth credentials missing from environment",
        details: { diagnostics }
      };
    }
    
    // Step 2: Database state analysis
    console.log('=== Step 2: Database State Analysis ===');
    const dbState = {
      existingConnection: await storage.getAccountConnection(userId, 'gmail'),
      emailCount: (await storage.getEmails(userId)).length,
      demoEmailCount: (await storage.getEmails(userId)).filter(e => e.gmailId?.startsWith('demo_')).length,
      user: await storage.getUser(userId)
    };
    
    diagnostics.step2 = {
      hasConnection: !!dbState.existingConnection,
      connectionId: dbState.existingConnection?.id,
      connectionStatus: dbState.existingConnection?.status,
      totalEmails: dbState.emailCount,
      demoEmails: dbState.demoEmailCount,
      userExists: !!dbState.user,
      userEmail: dbState.user?.email
    };
    
    console.log('Database state:', diagnostics.step2);
    
    // Step 3: OAuth URL generation test
    console.log('=== Step 3: OAuth URL Generation Test ===');
    try {
      const authUrl = simpleGmailAuth.getAuthUrl();
      diagnostics.step3 = {
        success: true,
        urlGenerated: true,
        urlLength: authUrl.length,
        urlStart: authUrl.substring(0, 100)
      };
      console.log('OAuth URL generated successfully:', authUrl.substring(0, 150));
    } catch (error) {
      diagnostics.step3 = {
        success: false,
        error: (error as Error).message
      };
      console.error('OAuth URL generation failed:', error);
    }
    
    // Step 4: Test token exchange mechanism (simulated)
    console.log('=== Step 4: Token Exchange Mechanism Test ===');
    try {
      // We can't test actual token exchange without a real auth code,
      // but we can test the mechanism
      diagnostics.step4 = {
        mechanismAvailable: typeof simpleGmailAuth.exchangeCodeForTokens === 'function',
        gmailClientAvailable: typeof simpleGmailAuth.getGmailClient === 'function',
        syncServiceAvailable: typeof gmailSyncService.syncUserEmails === 'function'
      };
      console.log('Token exchange mechanism test:', diagnostics.step4);
    } catch (error) {
      diagnostics.step4 = {
        success: false,
        error: (error as Error).message
      };
    }
    
    // Step 5: Create manual OAuth instructions
    console.log('=== Step 5: Manual OAuth Resolution ===');
    const manualOAuthUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
      `client_id=${process.env.GMAIL_CLIENT_ID}&` +
      `redirect_uri=${encodeURIComponent('https://e5337b57-0603-4c65-916d-c417360ec1b0-00-2bhahaz21vcty.worf.replit.dev/api/gmail/callback')}&` +
      `response_type=code&` +
      `scope=${encodeURIComponent('https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/gmail.send https://www.googleapis.com/auth/gmail.modify')}&` +
      `access_type=offline&` +
      `prompt=consent`;
    
    diagnostics.step5 = {
      manualAuthUrl: manualOAuthUrl,
      callbackEndpoint: '/api/gmail/callback',
      exchangeEndpoint: '/api/gmail/exchange',
      currentDomain: 'https://e5337b57-0603-4c65-916d-c417360ec1b0-00-2bhahaz21vcty.worf.replit.dev'
    };
    
    return {
      success: true,
      message: "Gmail OAuth diagnosis completed. Manual authorization required to establish connection.",
      details: {
        summary: {
          environmentValid: diagnostics.step1.hasClientId && diagnostics.step1.hasClientSecret,
          databaseReady: !!diagnostics.step2.userExists,
          oauthMechanismWorking: diagnostics.step3.success,
          hasExistingConnection: diagnostics.step2.hasConnection,
          currentEmailsAreDemo: diagnostics.step2.demoEmails > 0
        },
        diagnostics,
        resolution: {
          issue: "OAuth callback URL not receiving authorization codes from Google",
          solution: "Complete manual OAuth authorization to establish Gmail connection",
          steps: [
            "1. Visit the manual OAuth URL provided",
            "2. Authorize Gmail access with your Google account",
            "3. Copy the authorization code from the callback URL",
            "4. Use the /api/gmail/exchange endpoint to complete the connection",
            "5. Verify email synchronization replaces demo data"
          ]
        }
      }
    };
    
  } catch (error) {
    Logger.error("Comprehensive Gmail diagnosis failed", error, { requestId, userId });
    console.error('Comprehensive diagnosis error:', error);
    
    return {
      success: false,
      message: "Gmail diagnosis failed with internal error",
      details: { 
        error: (error as Error).message,
        stack: (error as Error).stack?.substring(0, 500)
      }
    };
  }
}

// Direct Gmail connection establishment (bypassing broken OAuth flow)
export async function establishDirectGmailConnection(userId: string, authCode: string): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `direct_connection_${Date.now()}`;
  
  try {
    Logger.info("Establishing direct Gmail connection", { requestId, userId });
    console.log('=== Direct Gmail Connection Establishment ===');
    
    // Step 1: Exchange authorization code for tokens
    console.log('Step 1: Token Exchange');
    const tokens = await simpleGmailAuth.exchangeCodeForTokens(authCode);
    
    console.log('Token exchange successful:', {
      hasAccessToken: !!tokens.accessToken,
      hasRefreshToken: !!tokens.refreshToken,
      accessTokenLength: tokens.accessToken?.length,
      refreshTokenLength: tokens.refreshToken?.length
    });
    
    // Step 2: Verify Gmail API access
    console.log('Step 2: Gmail API Verification');
    const gmailClient = await simpleGmailAuth.getGmailClient(tokens.accessToken, tokens.refreshToken);
    const profile = await gmailClient.users.getProfile({ userId: 'me' });
    
    console.log('Gmail API verification successful:', {
      emailAddress: profile.data.emailAddress,
      totalMessages: profile.data.messagesTotal,
      totalThreads: profile.data.threadsTotal
    });
    
    // Step 3: Store connection in database
    console.log('Step 3: Database Storage');
    const connection = await storage.createAccountConnection({
      userId,
      provider: 'gmail',
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      status: 'active',
    });
    
    console.log('Connection stored successfully:', {
      connectionId: connection.id,
      status: connection.status,
      provider: connection.provider
    });
    
    // Step 4: Sync emails to replace demo data
    console.log('Step 4: Email Synchronization');
    const syncResult = await gmailSyncService.syncUserEmails(userId);
    
    console.log('Email synchronization completed:', {
      emailsSynced: syncResult.synced,
      syncErrors: syncResult.errors
    });
    
    // Step 5: Verify demo data replacement
    console.log('Step 5: Demo Data Verification');
    const finalEmails = await storage.getEmails(userId);
    const demoEmails = finalEmails.filter(e => e.gmailId?.startsWith('demo_'));
    const realEmails = finalEmails.filter(e => !e.gmailId?.startsWith('demo_'));
    
    console.log('Final email state:', {
      totalEmails: finalEmails.length,
      demoEmails: demoEmails.length,
      realEmails: realEmails.length,
      syncSuccessful: realEmails.length > 0
    });
    
    return {
      success: true,
      message: `Gmail connection established successfully! Connected ${profile.data.emailAddress} and synced ${syncResult.synced} emails.`,
      details: {
        connection: {
          id: connection.id,
          status: connection.status,
          gmail: profile.data.emailAddress
        },
        sync: {
          emailsSynced: syncResult.synced,
          errors: syncResult.errors,
          totalEmails: finalEmails.length,
          demoEmailsRemaining: demoEmails.length,
          realEmailsAdded: realEmails.length
        },
        verification: {
          oauthWorking: true,
          apiAccessWorking: true,
          databaseWorking: true,
          syncWorking: realEmails.length > 0
        }
      }
    };
    
  } catch (error) {
    Logger.error("Direct Gmail connection failed", error, { requestId, userId });
    console.error('Direct connection error:', error);
    
    return {
      success: false,
      message: "Failed to establish direct Gmail connection",
      details: { 
        error: (error as Error).message,
        stage: error.message.includes('invalid_grant') ? 'token_exchange' : 
               error.message.includes('quota') ? 'api_limits' : 'unknown'
      }
    };
  }
}
import { google } from 'googleapis';

// Test Gmail OAuth configuration
export async function testGmailOAuth() {
  try {
    console.log("Testing Gmail OAuth configuration...");
    
    const oauth2Client = new google.auth.OAuth2(
      process.env.GMAIL_CLIENT_ID,
      process.env.GMAIL_CLIENT_SECRET,
      `https://workspace.aulanely.repl.co/api/gmail/callback`
    );

    const scopes = [
      'https://www.googleapis.com/auth/gmail.readonly',
      'https://www.googleapis.com/auth/gmail.send',
      'https://www.googleapis.com/auth/gmail.modify'
    ];

    const authUrl = oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent',
    });

    console.log("✓ Gmail OAuth URL generated successfully");
    console.log("Auth URL:", authUrl);
    
    return {
      success: true,
      authUrl,
      message: "Gmail OAuth configuration is working"
    };
  } catch (error) {
    console.error("Gmail OAuth test failed:", error);
    return {
      success: false,
      error: error.message,
      message: "Gmail OAuth configuration has issues"
    };
  }
}

// Test with sample credentials
export async function testGmailCredentials() {
  const clientId = process.env.GMAIL_CLIENT_ID;
  const clientSecret = process.env.GMAIL_CLIENT_SECRET;
  
  console.log("Gmail credentials check:");
  console.log("- Client ID:", clientId ? `${clientId.substring(0, 20)}...` : "MISSING");
  console.log("- Client Secret:", clientSecret ? `${clientSecret.substring(0, 10)}...` : "MISSING");
  
  return {
    hasClientId: !!clientId,
    hasClientSecret: !!clientSecret,
    ready: !!(clientId && clientSecret)
  };
}
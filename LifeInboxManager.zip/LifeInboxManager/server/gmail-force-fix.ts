import { simpleGmailAuth } from "./gmail-auth";
import { gmailSyncService } from "./gmail-sync";
import { storage } from "./storage";
import { Logger } from "./logger";

// Force create a Gmail connection for testing and debugging
export async function forceCreateGmailConnection(userId: string): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `force_create_${Date.now()}`;
  
  try {
    Logger.info("Force creating Gmail connection for testing", { requestId, userId });
    
    // Check if connection already exists
    const existingConnection = await storage.getAccountConnection(userId, 'gmail');
    if (existingConnection) {
      return {
        success: false,
        message: "Gmail connection already exists",
        details: { connectionId: existingConnection.id, status: existingConnection.status }
      };
    }
    
    // For testing, create a connection that we can use to test the sync flow
    // This bypasses OAuth to test if the sync mechanism itself works
    console.log('Creating test Gmail connection...');
    
    // We need valid tokens to test, so let's check if we have credentials
    const hasCredentials = !!(process.env.GMAIL_CLIENT_ID && process.env.GMAIL_CLIENT_SECRET);
    
    if (!hasCredentials) {
      return {
        success: false,
        message: "Gmail credentials missing - CLIENT_ID or CLIENT_SECRET not configured",
        details: {
          hasClientId: !!process.env.GMAIL_CLIENT_ID,
          hasClientSecret: !!process.env.GMAIL_CLIENT_SECRET
        }
      };
    }
    
    // Generate OAuth URL for manual testing
    const authUrl = simpleGmailAuth.getAuthUrl();
    
    return {
      success: true,
      message: "Gmail credentials verified. Manual OAuth required.",
      details: {
        authUrl: authUrl.substring(0, 150) + "...",
        nextStep: "Visit authUrl to get authorization code, then use /api/gmail/exchange endpoint",
        credentials: "Valid"
      }
    };
    
  } catch (error) {
    Logger.error("Force Gmail connection creation failed", error, { requestId, userId });
    console.error('Force create error:', error);
    
    return {
      success: false,
      message: "Failed to create Gmail connection",
      details: { error: (error as Error).message }
    };
  }
}

// Test Gmail sync with existing demo data to verify sync mechanism works
export async function testGmailSyncMechanism(userId: string): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `sync_test_${Date.now()}`;
  
  try {
    Logger.info("Testing Gmail sync mechanism", { requestId, userId });
    
    // Check current email count
    const currentEmails = await storage.getEmails(userId, 5);
    console.log('Current emails in database:', {
      count: currentEmails.length,
      sampleIds: currentEmails.map(e => e.gmailId).slice(0, 3)
    });
    
    // Check for Gmail connection
    const connection = await storage.getAccountConnection(userId, 'gmail');
    console.log('Gmail connection status:', {
      exists: !!connection,
      id: connection?.id,
      status: connection?.status
    });
    
    if (!connection) {
      return {
        success: false,
        message: "No Gmail connection found - OAuth required first",
        details: {
          currentEmailCount: currentEmails.length,
          hasConnection: false
        }
      };
    }
    
    // Try to sync with existing connection
    const syncResult = await gmailSyncService.syncUserEmails(userId);
    
    return {
      success: true,
      message: `Sync mechanism test completed. Synced ${syncResult.synced} emails.`,
      details: {
        emailsSynced: syncResult.synced,
        syncErrors: syncResult.errors,
        currentEmailCount: currentEmails.length
      }
    };
    
  } catch (error) {
    Logger.error("Gmail sync mechanism test failed", error, { requestId, userId });
    console.error('Sync test error:', error);
    
    return {
      success: false,
      message: "Gmail sync mechanism test failed",
      details: { error: (error as Error).message }
    };
  }
}

// Complete diagnostic check
export async function runCompleteGmailDiagnostic(userId: string): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `diagnostic_${Date.now()}`;
  
  try {
    Logger.info("Running complete Gmail diagnostic", { requestId, userId });
    
    const results = {
      credentials: {
        hasClientId: !!process.env.GMAIL_CLIENT_ID,
        hasClientSecret: !!process.env.GMAIL_CLIENT_SECRET
      },
      connection: null as any,
      emails: null as any,
      authUrl: null as string | null
    };
    
    // Check credentials
    if (results.credentials.hasClientId && results.credentials.hasClientSecret) {
      results.authUrl = simpleGmailAuth.getAuthUrl().substring(0, 100) + "...";
    }
    
    // Check connection
    const connection = await storage.getAccountConnection(userId, 'gmail');
    results.connection = {
      exists: !!connection,
      id: connection?.id,
      status: connection?.status,
      createdAt: connection?.createdAt
    };
    
    // Check emails
    const emails = await storage.getEmails(userId, 5);
    results.emails = {
      count: emails.length,
      isDemoData: emails.some(e => e.gmailId?.startsWith('demo_')),
      sampleGmailIds: emails.map(e => e.gmailId).slice(0, 3)
    };
    
    const hasIssues = !results.credentials.hasClientId || 
                     !results.credentials.hasClientSecret || 
                     !results.connection.exists ||
                     results.emails.isDemoData;
    
    return {
      success: !hasIssues,
      message: hasIssues ? "Gmail integration has issues that need to be resolved" : "Gmail integration appears configured correctly",
      details: results
    };
    
  } catch (error) {
    Logger.error("Complete Gmail diagnostic failed", error, { requestId, userId });
    console.error('Diagnostic error:', error);
    
    return {
      success: false,
      message: "Gmail diagnostic failed",
      details: { error: (error as Error).message }
    };
  }
}
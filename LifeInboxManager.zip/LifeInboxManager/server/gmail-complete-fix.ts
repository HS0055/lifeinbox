import { storage } from './storage';
import { Logger } from './logger';

/**
 * Complete Gmail OAuth and Sync Implementation
 * This handles the entire Gmail connection flow from OAuth to email sync
 */

export class CompleteGmailService {
  private clientId: string;
  private clientSecret: string;

  constructor() {
    // Use actual Google OAuth credentials
    this.clientId = process.env.GMAIL_CLIENT_ID || '666617246484-5ccr7d82gb0dl7p20vstlt4ad25voecj.apps.googleusercontent.com';
    this.clientSecret = process.env.GMAIL_CLIENT_SECRET || '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';
    
    if (!this.clientId || !this.clientSecret) {
      Logger.error('Gmail credentials missing', new Error('GMAIL_CLIENT_ID or GMAIL_CLIENT_SECRET not found'), {
        operation: 'constructor',
        metadata: { hasClientId: !!this.clientId, hasClientSecret: !!this.clientSecret }
      });
    }
  }

  /**
   * Generate OAuth URL for manual authorization
   */
  async generateOAuthURL(): Promise<{ success: boolean; message: string; details?: any }> {
    try {
      if (!this.clientId) {
        throw new Error('Gmail Client ID not configured');
      }

      const scopes = [
        'https://www.googleapis.com/auth/gmail.readonly',
        'https://www.googleapis.com/auth/gmail.send',
        'https://www.googleapis.com/auth/gmail.modify'
      ].join(' ');

      // Use the exact redirect URI from your Google Cloud Console setup
      const redirectUri = 'https://e5337b57-0603-4c65-916d-c417360ec1b0-00-2bhahaz21vcty.worf.replit.dev/api/gmail/callback';

      const params = new URLSearchParams({
        client_id: this.clientId,
        redirect_uri: redirectUri,
        scope: scopes,
        response_type: 'code',
        access_type: 'offline',
        prompt: 'consent'
      });

      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;

      Logger.info('Generated Gmail OAuth URL', { 
        operation: 'oauth-url-generation',
        metadata: { authUrlLength: authUrl.length, clientIdLength: this.clientId.length }
      });

      return {
        success: true,
        message: 'OAuth URL generated successfully',
        details: { authUrl }
      };
    } catch (error) {
      Logger.error('Failed to generate OAuth URL', error, { operation: 'oauth-url-generation' });
      return {
        success: false,
        message: 'Failed to generate OAuth URL',
        details: { error: (error as Error).message }
      };
    }
  }

  /**
   * Complete OAuth flow with authorization code
   */
  async completeOAuthFlow(userId: string, authCode: string): Promise<{ success: boolean; message: string; details?: any }> {
    try {
      Logger.info('Starting OAuth token exchange', { 
        userId, 
        operation: 'oauth-token-exchange',
        metadata: { authCodeLength: authCode.length }
      });

      // Exchange authorization code for tokens via direct HTTP
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          client_id: this.clientId,
          client_secret: this.clientSecret,
          code: authCode,
          grant_type: 'authorization_code',
          redirect_uri: 'https://e5337b57-0603-4c65-916d-c417360ec1b0-00-2bhahaz21vcty.worf.replit.dev/api/gmail/callback'
        })
      });

      if (!tokenResponse.ok) {
        const errorText = await tokenResponse.text();
        throw new Error(`Token exchange failed: ${tokenResponse.status} ${errorText}`);
      }

      const tokens = await tokenResponse.json();
      
      if (!tokens.access_token) {
        throw new Error('No access token received from Google');
      }

      Logger.info('OAuth tokens received', { 
        userId, 
        operation: 'oauth-token-exchange',
        metadata: { 
          hasAccessToken: !!tokens.access_token,
          hasRefreshToken: !!tokens.refresh_token,
          expiresIn: tokens.expires_in
        }
      });

      // Test the connection by getting user profile
      const profileResponse = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile', {
        headers: {
          'Authorization': `Bearer ${tokens.access_token}`
        }
      });

      if (!profileResponse.ok) {
        throw new Error(`Failed to get Gmail profile: ${profileResponse.status}`);
      }

      const profile = await profileResponse.json();
      const emailAddress = profile.emailAddress;

      Logger.info('Gmail profile retrieved', { 
        userId, 
        operation: 'oauth-token-exchange',
        metadata: { emailAddress, threadsTotal: profile.threadsTotal }
      });

      // Calculate expiry date
      const expiresAt = tokens.expires_in ? new Date(Date.now() + tokens.expires_in * 1000) : undefined;

      // Store the connection in database
      const connection = await storage.createAccountConnection({
        userId,
        provider: 'gmail',
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token || '',
        expiresAt,
        status: 'active',
        metadata: JSON.stringify({ 
          emailAddress,
          threadsTotal: profile.threadsTotal,
          messagesTotal: profile.messagesTotal
        })
      });

      Logger.info('Gmail connection stored in database', { 
        userId, 
        operation: 'oauth-token-exchange',
        metadata: { connectionId: connection.id }
      });

      // Immediately sync emails
      const syncResult = await this.syncEmails(userId);

      return {
        success: true,
        message: 'Gmail connected and synced successfully',
        details: { 
          connectionId: connection.id,
          emailAddress,
          syncResult
        }
      };

    } catch (error) {
      Logger.error('OAuth flow failed', error, { 
        userId, 
        operation: 'oauth-token-exchange',
        metadata: { authCodeLength: authCode.length }
      });

      return {
        success: false,
        message: 'Failed to complete Gmail OAuth',
        details: { error: (error as Error).message }
      };
    }
  }

  /**
   * Sync emails from Gmail to database
   */
  async syncEmails(userId: string): Promise<{ success: boolean; synced: number; errors: number }> {
    try {
      Logger.info('Starting Gmail email sync', { userId, operation: 'email-sync' });

      // Get Gmail connection
      const connection = await storage.getAccountConnection(userId, 'gmail');
      if (!connection || !connection.accessToken) {
        throw new Error('No active Gmail connection found');
      }

      // Fetch ALL messages using pagination (not just first 50)
      let allMessages = [];
      let nextPageToken = null;
      let pageCount = 0;

      do {
        const messagesUrl = `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=500&q=in:inbox${nextPageToken ? `&pageToken=${nextPageToken}` : ''}`;
        
        const messagesResponse = await fetch(messagesUrl, {
          headers: {
            'Authorization': `Bearer ${connection.accessToken}`
          }
        });

        if (!messagesResponse.ok) {
          throw new Error(`Failed to fetch messages: ${messagesResponse.status}`);
        }

        const messagesData = await messagesResponse.json();
        const pageMessages = messagesData.messages || [];
        
        allMessages = allMessages.concat(pageMessages);
        nextPageToken = messagesData.nextPageToken;
        pageCount++;

        Logger.info(`Fetched Gmail page ${pageCount}`, { 
          userId, 
          operation: 'email-sync',
          metadata: { 
            pageMessages: pageMessages.length,
            totalSoFar: allMessages.length,
            hasNextPage: !!nextPageToken
          }
        });

        // Add small delay to respect API limits
        if (nextPageToken) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }

      } while (nextPageToken);

      const messages = allMessages;
      Logger.info('Retrieved ALL Gmail messages', { 
        userId, 
        operation: 'email-sync',
        metadata: { 
          totalMessages: messages.length,
          pagesProcessed: pageCount
        }
      });

      let synced = 0;
      let errors = 0;

      // Process each message
      for (const message of messages) {
        try {
          const fullMessageResponse = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${message.id}?format=full`, {
            headers: {
              'Authorization': `Bearer ${connection.accessToken}`
            }
          });

          if (!fullMessageResponse.ok) {
            throw new Error(`Failed to fetch message ${message.id}: ${fullMessageResponse.status}`);
          }

          const fullMessage = await fullMessageResponse.json();
          const emailData = this.parseGmailMessage(fullMessage, userId);
          
          // Check if email already exists
          const existingEmails = await storage.getEmails(userId, 1000);
          const exists = existingEmails.some(email => email.gmailId === message.id);
          
          if (!exists) {
            await storage.createEmail(emailData);
            synced++;
            Logger.debug('Email synced', { 
              userId, 
              operation: 'email-sync',
              metadata: { gmailId: message.id, subject: emailData.subject }
            });
          }

        } catch (error) {
          errors++;
          Logger.error('Failed to sync individual email', error, { 
            userId, 
            operation: 'email-sync',
            metadata: { gmailId: message.id }
          });
        }
      }

      Logger.info('Gmail sync completed', { 
        userId, 
        operation: 'email-sync',
        metadata: { synced, errors, total: messages.length }
      });

      return { success: true, synced, errors };

    } catch (error) {
      Logger.error('Email sync failed', error, { userId, operation: 'email-sync' });
      return { success: false, synced: 0, errors: 1 };
    }
  }

  /**
   * Parse Gmail message into database format
   */
  private parseGmailMessage(message: any, userId: string) {
    const headers = message.payload.headers || [];
    const getHeader = (name: string) => headers.find((h: any) => h.name.toLowerCase() === name.toLowerCase())?.value || '';

    // Extract body content
    let bodyContent = '';
    if (message.payload.body?.data) {
      bodyContent = Buffer.from(message.payload.body.data, 'base64').toString('utf-8');
    } else if (message.payload.parts) {
      for (const part of message.payload.parts) {
        if (part.mimeType === 'text/plain' && part.body?.data) {
          bodyContent = Buffer.from(part.body.data, 'base64').toString('utf-8');
          break;
        }
      }
    }

    // Extract snippet safely
    const snippet = message.snippet || bodyContent.substring(0, 200) || '';

    return {
      userId,
      gmailId: message.id,
      subject: getHeader('Subject') || '(No Subject)',
      fromEmail: this.extractEmailAddress(getHeader('From')),
      fromName: this.extractDisplayName(getHeader('From')),
      toEmail: this.extractEmailAddress(getHeader('To')),
      toName: this.extractDisplayName(getHeader('To')),
      snippet,
      body: bodyContent,
      isRead: !message.labelIds?.includes('UNREAD'),
      isStarred: message.labelIds?.includes('STARRED') || false,
      isArchived: !message.labelIds?.includes('INBOX'),
      receivedAt: new Date(parseInt(message.internalDate || '0'))
    };
  }

  private extractEmailAddress(emailField: string): string {
    if (!emailField) return '';
    const match = emailField.match(/<([^>]+)>/);
    return match ? match[1] : emailField.split(' ')[0];
  }

  private extractDisplayName(emailField: string): string {
    if (!emailField) return '';
    const match = emailField.match(/^([^<]+)</);
    return match ? match[1].trim().replace(/"/g, '') : this.extractEmailAddress(emailField);
  }

  /**
   * Check Gmail connection status
   */
  async checkConnectionStatus(userId: string): Promise<{ success: boolean; message: string; details?: any }> {
    try {
      const connection = await storage.getAccountConnection(userId, 'gmail');
      
      if (!connection) {
        return {
          success: false,
          message: 'No Gmail connection found',
          details: { connected: false }
        };
      }

      // Test the connection using direct HTTP
      const profileResponse = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile', {
        headers: {
          'Authorization': `Bearer ${connection.accessToken}`
        }
      });

      if (!profileResponse.ok) {
        throw new Error(`Gmail API error: ${profileResponse.status}`);
      }

      const profile = await profileResponse.json();
      
      return {
        success: true,
        message: 'Gmail connection active',
        details: { 
          connected: true,
          emailAddress: profile.emailAddress,
          connectionId: connection.id,
          status: connection.status
        }
      };

    } catch (error) {
      Logger.error('Gmail connection check failed', error, { userId, operation: 'connection-check' });
      return {
        success: false,
        message: 'Gmail connection check failed',
        details: { connected: false, error: (error as Error).message }
      };
    }
  }
}

export const completeGmailService = new CompleteGmailService();
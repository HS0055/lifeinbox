import { simpleGmailAuth } from "./gmail-auth";
import { gmailSyncService } from "./gmail-sync";
import { storage } from "./storage";
import { Logger } from "./logger";

// Complete Gmail OAuth integration that bypasses session issues
export async function completeGmailOAuth(userId: string, authCode: string): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `oauth_${Date.now()}`;
  
  try {
    Logger.info("Starting complete Gmail OAuth flow", { requestId, userId });
    
    // Step 1: Exchange authorization code for tokens
    Logger.oauthStep("token_exchange_start", { 
      hasCode: !!authCode,
      codeLength: authCode?.length 
    }, { requestId, userId });
    
    const tokens = await simpleGmailAuth.exchangeCodeForTokens(authCode);
    
    Logger.oauthStep("tokens_received", { 
      hasAccessToken: !!tokens.accessToken,
      hasRefreshToken: !!tokens.refreshToken 
    }, { requestId, userId });
    
    // Step 2: Store Gmail connection in database
    const connection = await storage.createAccountConnection({
      userId,
      provider: 'gmail',
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      status: 'active',
    });
    
    Logger.dbOperation("create", "account_connections", true, { requestId, userId });
    Logger.oauthStep("connection_stored", { connectionId: connection.id }, { requestId, userId });
    
    // Step 3: Immediate email synchronization
    const syncResult = await gmailSyncService.syncUserEmails(userId);
    
    Logger.oauthStep("sync_complete", { 
      synced: syncResult.synced, 
      errors: syncResult.errors 
    }, { requestId, userId });
    
    return {
      success: true,
      message: `Gmail connected successfully. Synced ${syncResult.synced} emails.`,
      details: {
        connectionId: connection.id,
        emailsSynced: syncResult.synced,
        syncErrors: syncResult.errors
      }
    };
    
  } catch (error) {
    Logger.error("Complete Gmail OAuth failed", error, { requestId, userId });
    return {
      success: false,
      message: "Gmail OAuth completion failed",
      details: { error: (error as Error).message }
    };
  }
}

// Test existing Gmail connection and force resync
export async function testGmailConnectionAndSync(userId: string): Promise<{ success: boolean; message: string; details?: any }> {
  const requestId = `test_${Date.now()}`;
  
  try {
    Logger.info("Testing Gmail connection and syncing", { requestId, userId });
    
    // Check for existing connection
    const connection = await storage.getAccountConnection(userId, 'gmail');
    if (!connection) {
      return { 
        success: false, 
        message: "No Gmail connection found. Please connect Gmail first." 
      };
    }
    
    // Test Gmail API access
    const gmailClient = await simpleGmailAuth.getGmailClient(
      connection.accessToken, 
      connection.refreshToken
    );
    
    const profile = await gmailClient.users.getProfile({ userId: 'me' });
    
    Logger.info("Gmail API test successful", { 
      requestId, 
      userId,
      metadata: { emailAddress: profile.data.emailAddress }
    });
    
    // Force email sync
    const syncResult = await gmailSyncService.syncUserEmails(userId);
    
    return {
      success: true,
      message: `Gmail connection active. Synced ${syncResult.synced} emails.`,
      details: {
        emailAddress: profile.data.emailAddress,
        emailsSynced: syncResult.synced,
        syncErrors: syncResult.errors
      }
    };
    
  } catch (error) {
    Logger.error("Gmail test and sync failed", error, { requestId, userId });
    return {
      success: false,
      message: "Gmail connection test failed",
      details: { error: (error as Error).message }
    };
  }
}
import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';

export function useGmailOAuth() {
  const [location] = useLocation();

  const completeOAuth = useMutation({
    mutationFn: async (authCode: string) => {
      const response = await apiRequest("POST", "/api/gmail/complete-oauth", { authCode });
      return await response.json();
    },
    onSuccess: (data: any) => {
      if (data.success) {
        // Clear URL parameters
        window.history.replaceState({}, document.title, window.location.pathname);
        
        // Refresh all Gmail-related data
        queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
        queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
        
        // Show success notification
        console.log('Gmail connected successfully!');
      }
    },
    onError: (error) => {
      console.error("Failed to complete Gmail OAuth:", error);
      // Clear URL parameters even on error
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  });

  useEffect(() => {
    // Check for Gmail OAuth callback parameters
    const urlParams = new URLSearchParams(window.location.search);
    const gmailCode = urlParams.get('gmail_code');
    const callback = urlParams.get('callback');

    if (gmailCode && callback === 'success') {
      console.log('Gmail OAuth callback detected, completing connection...');
      completeOAuth.mutate(gmailCode);
    }
  }, [location]);

  return {
    isCompleting: completeOAuth.isPending
  };
}
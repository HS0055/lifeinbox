import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  Star, 
  Archive, 
  Trash2, 
  Reply, 
  Clock, 
  DollarSign, 
  Shield, 
  Briefcase,
  Filter,
  Search,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  Folder,
  Sparkles,
  ArrowRight,
  Brain,
  ThumbsUp
} from "lucide-react";
import AIFeedbackModal from "./ai-feedback-modal";

interface PriorityEmail {
  id: number;
  subject: string;
  fromName: string;
  fromEmail: string;
  receivedAt: string;
  snippet: string;
  topic: string;
  urgency: 'high' | 'medium' | 'low';
  priority: boolean;
  urgencyCategory: string;
  urgencyReason: string;
  urgencyScore: number;
  suggestedAction: string;
  isRead: boolean;
}

interface SmartFolder {
  id: string;
  name: string;
  query: string;
  count: number;
  icon: string;
  color: string;
}

export default function PriorityInbox() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("priority");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEmails, setSelectedEmails] = useState<number[]>([]);
  const [showCleanInbox, setShowCleanInbox] = useState(false);
  const [feedbackEmail, setFeedbackEmail] = useState<any>(null);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);

  // Fetch priority emails
  const { data: priorityEmails = [], isLoading: priorityLoading } = useQuery({
    queryKey: ["/api/emails/priority"],
  });

  // Fetch smart folders
  const { data: smartFolders = [] } = useQuery({
    queryKey: ["/api/smart-folders"],
  });

  // Fetch clean inbox candidates
  const { data: cleanInboxData = {} } = useQuery({
    queryKey: ["/api/emails/clean-candidates"],
    enabled: showCleanInbox,
  });

  // Bulk archive mutation
  const archiveMutation = useMutation({
    mutationFn: async (emailIds: number[]) => {
      await apiRequest("/api/emails/bulk-archive", "POST", { emailIds });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Emails archived successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      setSelectedEmails([]);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to archive emails",
        variant: "destructive",
      });
    },
  });

  // Clean inbox mutation
  const cleanInboxMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("/api/emails/clean-inbox", "POST", {});
    },
    onSuccess: (data: any) => {
      toast({
        title: "Inbox Cleaned",
        description: `Archived ${data.archivedCount} promotional emails`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      setShowCleanInbox(false);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to clean inbox",
        variant: "destructive",
      });
    },
  });

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTopicIcon = (topic: string) => {
    switch (topic.toLowerCase()) {
      case 'financial':
      case 'loans': return <DollarSign className="h-4 w-4" />;
      case 'security': return <Shield className="h-4 w-4" />;
      case 'work': return <Briefcase className="h-4 w-4" />;
      case 'deadlines': return <Clock className="h-4 w-4" />;
      default: return <MessageSquare className="h-4 w-4" />;
    }
  };

  const filteredEmails = priorityEmails.filter((email: PriorityEmail) =>
    email.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    email.fromName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    email.fromEmail.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const emailsByCategory = {
    loans: filteredEmails.filter((e: PriorityEmail) => e.topic === 'loans'),
    investing: filteredEmails.filter((e: PriorityEmail) => e.topic === 'investing'),
    urgent: filteredEmails.filter((e: PriorityEmail) => e.urgency === 'high'),
    work: filteredEmails.filter((e: PriorityEmail) => e.topic === 'work'),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Priority Inbox</h1>
          <p className="text-muted-foreground">AI-powered email management for what matters most</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowCleanInbox(!showCleanInbox)}
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Clean Inbox
          </Button>
          {selectedEmails.length > 0 && (
            <Button
              size="sm"
              onClick={() => archiveMutation.mutate(selectedEmails)}
              disabled={archiveMutation.isPending}
            >
              <Archive className="h-4 w-4 mr-2" />
              Archive ({selectedEmails.length})
            </Button>
          )}
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          placeholder="Search priority emails..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Clean Inbox Panel */}
      {showCleanInbox && (
        <Alert>
          <Sparkles className="h-4 w-4" />
          <AlertDescription>
            <div className="flex items-center justify-between">
              <div>
                <strong>Clean Inbox</strong> - I found {cleanInboxData?.candidateCount || 0} promotional emails to archive.
                <p className="text-sm text-muted-foreground mt-1">
                  This will archive newsletters, promotions, and marketing emails while keeping important messages.
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => cleanInboxMutation.mutate()}
                  disabled={cleanInboxMutation.isPending}
                >
                  Clean Now
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setShowCleanInbox(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Priority Inbox Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="priority">
            All Priority
            {filteredEmails.length > 0 && (
              <Badge variant="secondary" className="ml-2">{filteredEmails.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="loans">
            Loans
            {emailsByCategory.loans.length > 0 && (
              <Badge variant="secondary" className="ml-2">{emailsByCategory.loans.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="investing">
            Investing
            {emailsByCategory.investing.length > 0 && (
              <Badge variant="secondary" className="ml-2">{emailsByCategory.investing.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="urgent">
            Urgent
            {emailsByCategory.urgent.length > 0 && (
              <Badge variant="destructive" className="ml-2">{emailsByCategory.urgent.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="smart-folders">
            Smart Folders
          </TabsTrigger>
        </TabsList>

        {/* All Priority Emails */}
        <TabsContent value="priority" className="space-y-4">
          {priorityLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground mt-2">Loading priority emails...</p>
            </div>
          ) : filteredEmails.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">All Caught Up!</h3>
                <p className="text-muted-foreground">No priority emails requiring immediate attention.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {filteredEmails.map((email: PriorityEmail) => (
                <Card key={email.id} className={`cursor-pointer transition-all hover:shadow-md ${!email.isRead ? 'border-l-4 border-l-blue-500' : ''}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <div className={`p-1 rounded-full ${getUrgencyColor(email.urgency)}`}>
                            {getTopicIcon(email.topic)}
                          </div>
                          <span className="font-medium text-sm">{email.fromName || email.fromEmail}</span>
                          <Badge variant="secondary" className="text-xs">
                            {email.topic}
                          </Badge>
                          <Badge className={`text-xs ${getUrgencyColor(email.urgency)}`}>
                            {email.urgency}
                          </Badge>
                          {email.urgencyScore && (
                            <Badge variant="outline" className="text-xs">
                              {email.urgencyScore}/5
                            </Badge>
                          )}
                        </div>
                        <h4 className="font-semibold text-foreground mb-1 truncate">
                          {email.subject}
                        </h4>
                        <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                          {email.snippet}
                        </p>
                        {email.urgencyReason && (
                          <p className="text-xs text-orange-600 bg-orange-50 px-2 py-1 rounded mb-2">
                            {email.urgencyReason}
                          </p>
                        )}
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>{new Date(email.receivedAt).toLocaleDateString()}</span>
                          {email.suggestedAction && (
                            <span className="text-blue-600">Suggested: {email.suggestedAction}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button size="sm" variant="outline">
                          <Reply className="h-3 w-3 mr-1" />
                          Reply
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => {
                            setFeedbackEmail(email);
                            setShowFeedbackModal(true);
                          }}
                          title="Improve AI Classification"
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Brain className="h-3 w-3" />
                        </Button>
                        <Button size="sm" variant="ghost">
                          <Archive className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Category-specific tabs */}
        {['loans', 'investing', 'urgent'].map((category) => (
          <TabsContent key={category} value={category} className="space-y-4">
            <div className="space-y-3">
              {emailsByCategory[category as keyof typeof emailsByCategory].length === 0 ? (
                <Card>
                  <CardContent className="text-center py-8">
                    <Folder className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No {category} emails found.</p>
                  </CardContent>
                </Card>
              ) : (
                emailsByCategory[category as keyof typeof emailsByCategory].map((email: PriorityEmail) => (
                  <Card key={email.id} className="cursor-pointer hover:shadow-md">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm">{email.fromName}</span>
                            <Badge className={`text-xs ${getUrgencyColor(email.urgency)}`}>
                              {email.urgency}
                            </Badge>
                          </div>
                          <h4 className="font-semibold text-foreground mb-1 truncate">{email.subject}</h4>
                          <p className="text-sm text-muted-foreground line-clamp-1">{email.snippet}</p>
                        </div>
                        <ArrowRight className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
        ))}

        {/* Smart Folders */}
        <TabsContent value="smart-folders" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {smartFolders.map((folder: SmartFolder) => (
              <Card key={folder.id} className="cursor-pointer hover:shadow-md">
                <CardContent className="p-4 text-center">
                  <div className={`w-8 h-8 rounded-full ${folder.color} mx-auto mb-2 flex items-center justify-center`}>
                    <span className="text-sm">{folder.icon}</span>
                  </div>
                  <h4 className="font-semibold text-sm mb-1">{folder.name}</h4>
                  <p className="text-xs text-muted-foreground mb-2">{folder.query}</p>
                  <Badge variant="secondary" className="text-xs">{folder.count} emails</Badge>
                </CardContent>
              </Card>
            ))}
            <Card className="cursor-pointer hover:shadow-md border-dashed">
              <CardContent className="p-4 text-center">
                <div className="w-8 h-8 rounded-full bg-muted mx-auto mb-2 flex items-center justify-center">
                  <Folder className="h-4 w-4" />
                </div>
                <h4 className="font-semibold text-sm">Create Folder</h4>
                <p className="text-xs text-muted-foreground">Add a smart folder</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* AI Feedback Modal */}
      {feedbackEmail && (
        <AIFeedbackModal
          email={feedbackEmail}
          isOpen={showFeedbackModal}
          onClose={() => {
            setShowFeedbackModal(false);
            setFeedbackEmail(null);
          }}
        />
      )}
    </div>
  );
}
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Archive, Reply } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface EmailDetailProps {
  emailId: number | null;
}

export default function EmailDetail({ emailId }: EmailDetailProps) {
  const { toast } = useToast();

  const { data: email, isLoading } = useQuery({
    queryKey: [`/api/emails/${emailId}`],
    enabled: !!emailId,
  });

  const replyMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/emails/${emailId}/reply`);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Reply Generated",
        description: "AI has generated a suggested reply for this email.",
      });
      // Here you would typically open a compose modal with the suggested reply
      console.log("Suggested reply:", data.suggestedReply);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to generate reply suggestion.",
        variant: "destructive",
      });
    },
  });

  if (!emailId) {
    return (
      <div className="flex-1 bg-white flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <p className="text-lg mb-2">Select an email to read</p>
          <p className="text-sm">Choose an email from the list to view its contents</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex-1 bg-white flex items-center justify-center">
        <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!email) {
    return (
      <div className="flex-1 bg-white flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <p>Email not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-white flex flex-col">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h2 className="text-lg font-semibold text-foreground">
              {email.subject || "No Subject"}
            </h2>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Archive className="h-4 w-4 mr-1" />
              Archive
            </Button>
            <Button 
              size="sm"
              onClick={() => replyMutation.mutate()}
              disabled={replyMutation.isPending}
            >
              <Reply className="h-4 w-4 mr-1" />
              {replyMutation.isPending ? "Generating..." : "Reply"}
            </Button>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-3xl">
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-semibold">
              {email.fromName ? email.fromName.charAt(0).toUpperCase() : email.fromEmail?.charAt(0).toUpperCase() || 'U'}
            </div>
            <div>
              <p className="font-semibold text-foreground">{email.fromName || email.fromEmail}</p>
              <p className="text-sm text-muted-foreground">{email.fromEmail}</p>
              <p className="text-xs text-muted-foreground">
                {email.receivedAt ? new Date(email.receivedAt).toLocaleString() : 'Unknown date'}
              </p>
            </div>
          </div>
          
          <div className="prose prose-slate max-w-none">
            {email.body ? (
              <div dangerouslySetInnerHTML={{ __html: email.body }} />
            ) : (
              <p className="text-muted-foreground">{email.snippet || "No content available"}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { 
  Brain, 
  Filter, 
  Search, 
  Sparkles, 
  MessageCircle, 
  Archive, 
  Trash2, 
  Flag, 
  Folder,
  Send,
  Clock,
  Star,
  AlertTriangle,
  CheckCircle,
  Eye,
  ThumbsUp,
  ThumbsDown
} from "lucide-react";

interface FilteredEmail {
  id: number;
  subject: string;
  fromName: string;
  fromEmail: string;
  snippet: string;
  isRead: boolean;
  priority: 'high' | 'medium' | 'low';
  category: string;
  aiSummary?: string;
  suggestedActions?: string[];
}

export default function AIPriorityInbox() {
  const [chatMessage, setChatMessage] = useState("");
  const [filterQuery, setFilterQuery] = useState("");
  const [filteredEmails, setFilteredEmails] = useState<FilteredEmail[]>([]);
  const [aiResponse, setAiResponse] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const queryClient = useQueryClient();

  const { data: emails = [] } = useQuery({
    queryKey: ["/api/emails"],
  });

  // AI Email Filtering Mutation
  const filterEmailsMutation = useMutation({
    mutationFn: async (query: string) => {
      return await apiRequest("/api/ai/filter-emails", {
        method: "POST",
        body: { query }
      });
    },
    onSuccess: (data) => {
      setFilteredEmails(data.filteredEmails);
      setAiResponse(data.aiResponse);
      setIsProcessing(false);
    },
    onError: () => {
      setIsProcessing(false);
    }
  });

  // AI Bulk Actions Mutation
  const bulkActionsMutation = useMutation({
    mutationFn: async (data: { action: string; emailIds: number[] }) => {
      return await apiRequest("/api/ai/bulk-actions", {
        method: "POST",
        body: data
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    }
  });

  // Conversational AI Assistant Mutation
  const assistantMutation = useMutation({
    mutationFn: async (query: string) => {
      return await apiRequest("/api/ai/inbox-assistant", {
        method: "POST",
        body: { query }
      });
    },
    onSuccess: (data) => {
      setAiResponse(data.response);
      if (data.filteredEmails) {
        setFilteredEmails(data.filteredEmails);
      }
      if (data.bulkActionResult) {
        queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      }
      setIsProcessing(false);
    },
    onError: () => {
      setAiResponse("I'm having trouble processing your request. Please try again.");
      setIsProcessing(false);
    }
  });

  const handleFilter = () => {
    if (!filterQuery.trim()) return;
    setIsProcessing(true);
    filterEmailsMutation.mutate(filterQuery);
  };

  const handleChat = () => {
    if (!chatMessage.trim()) return;
    setIsProcessing(true);
    assistantMutation.mutate(chatMessage);
    setChatMessage("");
  };

  const handleBulkAction = (action: string, emailIds: number[]) => {
    bulkActionsMutation.mutate({ action, emailIds });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <AlertTriangle className="w-3 h-3" />;
      case 'medium': return <Clock className="w-3 h-3" />;
      case 'low': return <CheckCircle className="w-3 h-3" />;
      default: return <Star className="w-3 h-3" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Conversational Interface */}
      <Card className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-blue-950/20 dark:via-indigo-950/20 dark:to-purple-950/20 border-2 border-blue-200/50 dark:border-blue-800/50 shadow-lg">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center">
              <Brain className="w-5 h-5 text-white animate-pulse" />
            </div>
            <div>
              <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent font-bold text-lg">
                AI Inbox Assistant
              </span>
              <p className="text-xs text-muted-foreground">Ask me anything about your emails</p>
            </div>
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Chat Interface */}
          <div className="flex space-x-2">
            <div className="flex-1">
              <Input
                placeholder="Try: 'Find emails about loans' or 'Archive old newsletters' or 'Show priority emails'"
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleChat()}
                className="border-indigo-200 focus:border-indigo-400"
              />
            </div>
            <Button 
              onClick={handleChat}
              disabled={isProcessing || !chatMessage.trim()}
              className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
            >
              {isProcessing ? (
                <Brain className="w-4 h-4 animate-pulse" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => {
                setChatMessage("Show me urgent emails about loans");
                setIsProcessing(true);
                assistantMutation.mutate("Show me urgent emails about loans");
              }}
              className="border-blue-200 hover:bg-blue-50"
            >
              <Flag className="w-3 h-3 mr-1" />
              Priority Loans
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                setChatMessage("Find newsletters about investing");
                setIsProcessing(true);
                assistantMutation.mutate("Find newsletters about investing");
              }}
              className="border-green-200 hover:bg-green-50"
            >
              <Search className="w-3 h-3 mr-1" />
              Investment News
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                setChatMessage("Clean up old promotional emails");
                setIsProcessing(true);
                assistantMutation.mutate("Clean up old promotional emails");
              }}
              className="border-purple-200 hover:bg-purple-50"
            >
              <Archive className="w-3 h-3 mr-1" />
              Clean Inbox
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                setChatMessage("Create smart folders for my emails");
                setIsProcessing(true);
                assistantMutation.mutate("Create smart folders for my emails");
              }}
              className="border-orange-200 hover:bg-orange-50"
            >
              <Folder className="w-3 h-3 mr-1" />
              Smart Folders
            </Button>
          </div>

          {/* AI Response */}
          {aiResponse && (
            <div className="p-4 bg-white/50 dark:bg-black/20 rounded-xl border border-blue-200/50 dark:border-blue-800/50 backdrop-blur-sm">
              <div className="flex items-start space-x-2">
                <MessageCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-foreground leading-relaxed">{aiResponse}</div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Advanced Filter Interface */}
      <Card className="border border-gray-200 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-indigo-600" />
            <span>Advanced AI Filtering</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2 mb-4">
            <Input
              placeholder="e.g., 'emails from banks about credit cards' or 'unread newsletters from last week'"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleFilter()}
            />
            <Button onClick={handleFilter} disabled={isProcessing}>
              <Sparkles className="w-4 h-4 mr-1" />
              Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Filtered Results */}
      {filteredEmails.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>AI Filtered Results ({filteredEmails.length} emails)</span>
              <div className="flex space-x-2">
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => handleBulkAction('archive', filteredEmails.map(e => e.id))}
                >
                  <Archive className="w-3 h-3 mr-1" />
                  Archive All
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => handleBulkAction('flag', filteredEmails.map(e => e.id))}
                >
                  <Flag className="w-3 h-3 mr-1" />
                  Flag All
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredEmails.map((email) => (
                <div 
                  key={email.id}
                  className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-900/50 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <div className={`w-2 h-2 rounded-full ${getPriorityColor(email.priority)}`} />
                        <Badge variant="outline" className="text-xs">
                          {getPriorityIcon(email.priority)}
                          <span className="ml-1 capitalize">{email.priority}</span>
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {email.category}
                        </Badge>
                        {!email.isRead && (
                          <Badge className="bg-blue-100 text-blue-800 text-xs">Unread</Badge>
                        )}
                      </div>
                      <h4 className="font-medium text-sm">{email.subject}</h4>
                      <p className="text-xs text-muted-foreground">{email.fromName} &lt;{email.fromEmail}&gt;</p>
                      <p className="text-sm text-muted-foreground mt-1">{email.snippet}</p>
                    </div>
                    <div className="flex space-x-1 ml-4">
                      <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                        <Eye className="w-3 h-3" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                        <Archive className="w-3 h-3" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                        <Flag className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  
                  {email.aiSummary && (
                    <div className="mt-2 p-2 bg-blue-50 dark:bg-blue-900/20 rounded border-l-2 border-blue-300">
                      <p className="text-xs text-blue-800 dark:text-blue-300">
                        <Brain className="w-3 h-3 inline mr-1" />
                        AI Summary: {email.aiSummary}
                      </p>
                    </div>
                  )}
                  
                  {email.suggestedActions && email.suggestedActions.length > 0 && (
                    <div className="mt-2 flex space-x-2">
                      {email.suggestedActions.map((action, index) => (
                        <Badge key={index} variant="outline" className="text-xs cursor-pointer hover:bg-gray-100">
                          {action}
                        </Badge>
                      ))}
                    </div>
                  )}
                  
                  {/* AI Training Interface */}
                  <div className="mt-2 flex items-center space-x-2 text-xs text-muted-foreground">
                    <span>Is this categorization correct?</span>
                    <Button size="sm" variant="ghost" className="h-5 w-5 p-0">
                      <ThumbsUp className="w-3 h-3 text-green-600" />
                    </Button>
                    <Button size="sm" variant="ghost" className="h-5 w-5 p-0">
                      <ThumbsDown className="w-3 h-3 text-red-600" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
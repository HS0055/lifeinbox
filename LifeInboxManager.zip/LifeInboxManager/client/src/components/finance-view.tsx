import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Wallet, TrendingUp, TrendingDown } from "lucide-react";

export default function FinanceView() {
  const { data: accounts = [], isLoading: accountsLoading } = useQuery({
    queryKey: ["/api/accounts"],
  });

  const { data: transactions = [], isLoading: transactionsLoading } = useQuery({
    queryKey: ["/api/transactions"],
  });

  if (accountsLoading || transactionsLoading) {
    return (
      <div className="flex-1 bg-white flex items-center justify-center">
        <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  const totalBalance = accounts.reduce((sum: number, account: any) => sum + parseFloat(account.balance || 0), 0);

  return (
    <div className="flex-1 bg-white flex flex-col">
      <div className="p-6 border-b border-border">
        <h2 className="text-lg font-semibold text-foreground">Financial Dashboard</h2>
        <p className="text-sm text-muted-foreground mt-1">Complete overview of your accounts and spending</p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-4xl space-y-8">
          
          {/* Account Summary */}
          <div className="grid grid-cols-3 gap-6">
            <Card className="bg-gradient-to-br from-primary/5 to-primary/10">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
                <Wallet className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">${totalBalance.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground mt-2">
                  {accounts.length} account{accounts.length !== 1 ? 's' : ''} connected
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Monthly Income</CardTitle>
                <TrendingUp className="h-4 w-4 text-emerald-600" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-emerald-600">$0</div>
                <p className="text-xs text-muted-foreground mt-2">This month</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-red-50 to-red-100">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Monthly Expenses</CardTitle>
                <TrendingDown className="h-4 w-4 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-red-600">$0</div>
                <p className="text-xs text-muted-foreground mt-2">This month</p>
              </CardContent>
            </Card>
          </div>

          {/* Account Balances */}
          {accounts.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Account Balances</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {accounts.map((account: any) => (
                    <div key={account.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-primary rounded text-white text-xs flex items-center justify-center font-semibold">
                          {account.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{account.name}</p>
                          <p className="text-xs text-muted-foreground">••••{account.mask}</p>
                        </div>
                      </div>
                      <p className="text-sm font-semibold text-foreground">
                        ${parseFloat(account.balance || 0).toFixed(2)}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recent Transactions */}
          {transactions.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {transactions.slice(0, 10).map((transaction: any) => (
                    <div key={transaction.id} className="flex items-center justify-between py-2">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          parseFloat(transaction.amount) > 0 ? 'bg-emerald-100' : 'bg-red-100'
                        }`}>
                          {parseFloat(transaction.amount) > 0 ? (
                            <TrendingUp className="h-4 w-4 text-emerald-600" />
                          ) : (
                            <TrendingDown className="h-4 w-4 text-red-600" />
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            {transaction.description || transaction.merchantName || 'Transaction'}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(transaction.transactionDate).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <p className={`text-sm font-medium ${
                        parseFloat(transaction.amount) > 0 ? 'text-emerald-600' : 'text-red-600'
                      }`}>
                        {parseFloat(transaction.amount) > 0 ? '+' : ''}${Math.abs(parseFloat(transaction.amount)).toFixed(2)}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <p className="text-muted-foreground mb-4">No transactions yet</p>
                <p className="text-sm text-muted-foreground">Connect your bank account to see transactions</p>
              </CardContent>
            </Card>
          )}

        </div>
      </div>
    </div>
  );
}

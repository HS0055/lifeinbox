import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { apiRequest } from "@/lib/queryClient";
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User, 
  Sparkles,
  Filter,
  Archive,
  Star,
  Clock,
  CheckSquare,
  Mail
} from "lucide-react";

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  suggestions?: string[];
  actions?: Array<{
    type: string;
    label: string;
    data: any;
  }>;
}

export default function ConversationalAIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: "Hi! I'm your AI inbox assistant. I can help you find emails, organize your inbox, or answer questions about your messages. Try asking me something like 'Show me urgent emails' or 'What emails need my attention?'",
      timestamp: new Date(),
      suggestions: [
        "Show me urgent emails",
        "Find emails about payments",
        "What needs my attention?",
        "Archive all newsletters"
      ]
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const { data: emails = [] } = useQuery({
    queryKey: ["/api/emails"],
  });

  const chatMutation = useMutation({
    mutationFn: async (query: string) => {
      return await apiRequest("/api/ai/inbox-chat", "POST", { 
        message: query, 
        context: { emailCount: Array.isArray(emails) ? emails.length : 0 }
      });
    },
    onSuccess: (data) => {
      setIsTyping(false);
      const aiMessage: Message = {
        id: Date.now().toString(),
        type: 'ai',
        content: data?.answer || data?.response || "I couldn't process that request. Could you try rephrasing?",
        timestamp: new Date(),
        suggestions: data?.suggestedActions || data?.suggestions || [],
        actions: data?.bulkActionResult ? [data.bulkActionResult] : data?.actions || []
      };
      setMessages(prev => [...prev, aiMessage]);
    },
    onError: () => {
      setIsTyping(false);
      const errorMessage: Message = {
        id: Date.now().toString(),
        type: 'ai',
        content: "I'm having trouble connecting right now. Please try again in a moment.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  });

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);
    
    chatMutation.mutate(inputValue);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputValue(suggestion);
  };

  const handleActionClick = (action: any) => {
    // Handle AI-suggested actions
    console.log("Executing action:", action);
    
    const confirmMessage: Message = {
      id: Date.now().toString(),
      type: 'ai',
      content: `I've executed the "${action.label}" action. ${action.data?.count || 0} emails were processed.`,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, confirmMessage]);
  };

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'filter': return <Filter className="h-3 w-3" />;
      case 'archive': return <Archive className="h-3 w-3" />;
      case 'star': return <Star className="h-3 w-3" />;
      case 'schedule': return <Clock className="h-3 w-3" />;
      case 'markRead': return <CheckSquare className="h-3 w-3" />;
      default: return <Mail className="h-3 w-3" />;
    }
  };

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <MessageCircle className="h-5 w-5 text-blue-600" />
          AI Inbox Assistant
          <Badge variant="secondary" className="ml-auto">
            <Sparkles className="h-3 w-3 mr-1" />
            Smart
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Chat Messages */}
        <ScrollArea className="h-80 w-full" ref={scrollAreaRef}>
          <div className="space-y-4 pr-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex gap-3 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`flex gap-2 max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium ${
                    message.type === 'user' 
                      ? 'bg-blue-600' 
                      : 'bg-gradient-to-br from-purple-600 to-blue-600'
                  }`}>
                    {message.type === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                  </div>
                  
                  <div className="space-y-2">
                    <div className={`p-3 rounded-lg ${
                      message.type === 'user' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-muted'
                    }`}>
                      <p className="text-sm">{message.content}</p>
                    </div>
                    
                    {/* AI Suggestions */}
                    {message.suggestions && message.suggestions.length > 0 && (
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">Try asking:</p>
                        <div className="flex flex-wrap gap-1">
                          {message.suggestions.map((suggestion, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              size="sm"
                              className="text-xs h-6 px-2"
                              onClick={() => handleSuggestionClick(suggestion)}
                            >
                              {suggestion}
                            </Button>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* AI Actions */}
                    {message.actions && message.actions.length > 0 && (
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">Quick actions:</p>
                        <div className="flex flex-wrap gap-1">
                          {message.actions.map((action, index) => (
                            <Button
                              key={index}
                              variant="default"
                              size="sm"
                              className="text-xs h-6 px-2"
                              onClick={() => handleActionClick(action)}
                            >
                              {getActionIcon(action.type)}
                              {action.label}
                            </Button>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <p className="text-xs text-muted-foreground">
                      {message.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            
            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center text-white">
                  <Bot className="h-4 w-4" />
                </div>
                <div className="bg-muted p-3 rounded-lg">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        
        {/* Chat Input */}
        <div className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ask me about your emails..."
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            disabled={chatMutation.isPending}
            className="flex-1"
          />
          <Button 
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || chatMutation.isPending}
            size="sm"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Status */}
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>AI powered by GPT-4o</span>
          <span>{Array.isArray(emails) ? emails.length : 0} emails in your inbox</span>
        </div>
      </CardContent>
    </Card>
  );
}
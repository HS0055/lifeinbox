import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { Plus, Star, Archive, MailOpen, Clock, CheckSquare, Users, Zap, Reply } from "lucide-react";

interface EmailListProps {
  selectedEmailId: number | null;
  onSelectEmail: (id: number) => void;
}

export default function EmailList({ selectedEmailId, onSelectEmail }: EmailListProps) {
  const queryClient = useQueryClient();
  
  const { data: emails = [], isLoading } = useQuery({
    queryKey: ["/api/emails"],
  });

  const updateEmailMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest("PATCH", `/api/emails/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });

  const handleMarkTodo = (e: React.MouseEvent, emailId: number) => {
    e.stopPropagation();
    updateEmailMutation.mutate({
      id: emailId,
      data: { isTodo: true }
    });
  };

  const handleDelegate = (e: React.MouseEvent, emailId: number) => {
    e.stopPropagation();
    updateEmailMutation.mutate({
      id: emailId,
      data: { isDelegated: true }
    });
  };

  const handleAutoReply = (e: React.MouseEvent, emailId: number) => {
    e.stopPropagation();
    // Future: Implement AI auto-reply functionality
    console.log("AI Reply triggered for email:", emailId);
  };

  const handleStarEmail = (e: React.MouseEvent, emailId: number, isStarred: boolean) => {
    e.stopPropagation();
    updateEmailMutation.mutate({ id: emailId, data: { isStarred: !isStarred } });
  };

  const handleArchiveEmail = (e: React.MouseEvent, emailId: number) => {
    e.stopPropagation();
    updateEmailMutation.mutate({ id: emailId, data: { isArchived: true } });
  };

  const handleMarkRead = (e: React.MouseEvent, emailId: number, isRead: boolean) => {
    e.stopPropagation();
    updateEmailMutation.mutate({ id: emailId, data: { isRead: !isRead } });
  };

  const handleMarkTodo = (e: React.MouseEvent, emailId: number) => {
    e.stopPropagation();
    updateEmailMutation.mutate({ id: emailId, data: { isTodo: true } });
  };

  const handleDelegate = (e: React.MouseEvent, emailId: number) => {
    e.stopPropagation();
    updateEmailMutation.mutate({ id: emailId, data: { isDelegated: true } });
  };

  const handleAutoReply = (e: React.MouseEvent, emailId: number) => {
    e.stopPropagation();
    // In a real implementation, this would trigger AI auto-reply
    updateEmailMutation.mutate({ id: emailId, data: { hasAutoReply: true } });
  };

  if (isLoading) {
    return (
      <div className="w-96 bg-white border-r border-border flex flex-col">
        <div className="p-6 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">Inbox</h2>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-96 bg-white border-r border-border flex flex-col">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Inbox</h2>
          <Button size="sm" className="bg-primary hover:bg-primary/90">
            <Plus className="w-3 h-3 mr-1" />
            Compose
          </Button>
        </div>
        <div className="flex space-x-2">
          <Button size="sm" variant="secondary" className="text-xs">All</Button>
          <Button size="sm" variant="ghost" className="text-xs">Unread</Button>
          <Button size="sm" variant="ghost" className="text-xs">Flagged</Button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {emails.length > 0 ? (
          emails.map((email: any) => (
            <div 
              key={email.id}
              onClick={() => onSelectEmail(email.id)}
              className={`p-4 border-b border-border hover:bg-muted/50 cursor-pointer transition-colors ${
                selectedEmailId === email.id ? 'bg-muted' : ''
              }`}
            >
              <div className="flex items-start space-x-3">
                <div className={`w-2 h-2 rounded-full mt-2 ${email.isRead ? 'bg-muted-foreground' : 'bg-primary'}`}></div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className={`text-sm font-medium ${email.isRead ? 'text-muted-foreground' : 'text-foreground'}`}>
                      {email.fromName || email.fromEmail}
                    </p>
                    <div className="flex items-center space-x-1">
                      <p className="text-xs text-muted-foreground mr-2">
                        {email.receivedAt ? new Date(email.receivedAt).toLocaleDateString() : 'Recent'}
                      </p>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 w-6 p-0 hover:bg-muted"
                        onClick={(e) => handleStarEmail(e, email.id, email.isStarred)}
                      >
                        <Star className={`w-3 h-3 ${email.isStarred ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground'}`} />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 w-6 p-0 hover:bg-muted"
                        onClick={(e) => handleMarkRead(e, email.id, email.isRead)}
                      >
                        <MailOpen className={`w-3 h-3 ${email.isRead ? 'text-muted-foreground' : 'text-primary'}`} />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 w-6 p-0 hover:bg-muted"
                        onClick={(e) => handleArchiveEmail(e, email.id)}
                      >
                        <Archive className="w-3 h-3 text-muted-foreground hover:text-foreground" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mb-1">
                    <p className={`text-sm ${email.isRead ? 'text-muted-foreground' : 'text-foreground'}`}>
                      {email.subject || 'No Subject'}
                    </p>
                    {!email.isRead && <Badge variant="secondary" className="text-xs">New</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                    {email.snippet || email.body?.slice(0, 100)}
                  </p>
                  
                  {/* LifeInbox Actionable Workflow Buttons */}
                  <div className="flex items-center space-x-1 mt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-xs bg-orange-50 border-orange-200 text-orange-700 hover:bg-orange-100"
                      onClick={(e) => handleMarkTodo(e, email.id)}
                    >
                      <CheckSquare className="w-3 h-3 mr-1" />
                      To-Do
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-xs bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
                      onClick={(e) => handleDelegate(e, email.id)}
                    >
                      <Users className="w-3 h-3 mr-1" />
                      Delegate
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-xs bg-green-50 border-green-200 text-green-700 hover:bg-green-100"
                      onClick={(e) => handleAutoReply(e, email.id)}
                    >
                      <Zap className="w-3 h-3 mr-1" />
                      AI Reply
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="text-center">
              <p className="text-muted-foreground mb-4">No emails yet</p>
              <p className="text-sm text-muted-foreground">Connect your Gmail account to get started</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

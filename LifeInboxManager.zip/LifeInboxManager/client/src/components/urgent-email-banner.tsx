import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  AlertTriangle,
  Clock,
  TrendingUp,
  Shield,
  Briefcase,
  Calendar,
  Eye,
  Mail
} from "lucide-react";

// Smart urgent email banner component
export function UrgentEmailBanner() {
  const [showDetails, setShowDetails] = useState(false);

  // Fetch urgent emails with smart detection
  const { data: urgentData, isLoading, error } = useQuery({
    queryKey: ["/api/emails/urgent"],
    refetchInterval: 60000, // Check every minute
  });

  if (isLoading) {
    return (
      <Alert className="mb-4 border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950">
        <Clock className="h-4 w-4" />
        <AlertDescription>Analyzing urgent emails with smart detection...</AlertDescription>
      </Alert>
    );
  }

  if (error || !urgentData?.totalUrgent) {
    if (urgentData?.error) {
      return (
        <Alert className="mb-4 border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-950">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800 dark:text-yellow-200">
            Urgent email analysis temporarily unavailable. Check back in a moment.
          </AlertDescription>
        </Alert>
      );
    }
    return null;
  }

  const { urgent: urgentEmails, totalUrgent, urgencyBreakdown } = urgentData;

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'financial': return <TrendingUp className="h-4 w-4" />;
      case 'security': return <Shield className="h-4 w-4" />;
      case 'deadline': return <Clock className="h-4 w-4" />;
      case 'work': return <Briefcase className="h-4 w-4" />;
      default: return <Mail className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'financial': return 'bg-red-500/10 text-red-600 border-red-200';
      case 'security': return 'bg-orange-500/10 text-orange-600 border-orange-200';
      case 'deadline': return 'bg-yellow-500/10 text-yellow-600 border-yellow-200';
      case 'work': return 'bg-blue-500/10 text-blue-600 border-blue-200';
      default: return 'bg-purple-500/10 text-purple-600 border-purple-200';
    }
  };

  return (
    <div className="space-y-3">
      {/* Main urgent alert banner */}
      <Alert className="border-red-200 bg-red-50 dark:bg-red-950/20">
        <AlertTriangle className="h-5 w-5 text-red-600" />
        <AlertDescription className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-red-800 dark:text-red-200">
              🔥 You have {totalUrgent} urgent email{totalUrgent !== 1 ? 's' : ''}!
            </span>
            <div className="flex gap-1">
              {urgencyBreakdown.financial > 0 && (
                <Badge variant="secondary" className="text-xs bg-red-100 text-red-700">
                  {urgencyBreakdown.financial} Financial
                </Badge>
              )}
              {urgencyBreakdown.security > 0 && (
                <Badge variant="secondary" className="text-xs bg-orange-100 text-orange-700">
                  {urgencyBreakdown.security} Security
                </Badge>
              )}
              {urgencyBreakdown.deadlines > 0 && (
                <Badge variant="secondary" className="text-xs bg-yellow-100 text-yellow-700">
                  {urgencyBreakdown.deadlines} Deadlines
                </Badge>
              )}
              {urgencyBreakdown.work > 0 && (
                <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700">
                  {urgencyBreakdown.work} Work
                </Badge>
              )}
            </div>
          </div>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              onClick={() => setShowDetails(!showDetails)}
              variant="outline"
              className="border-red-300 hover:bg-red-100"
            >
              <Eye className="h-4 w-4 mr-1" />
              View Urgent Now
            </Button>
            <Button 
              size="sm" 
              className="bg-red-600 hover:bg-red-700"
              onClick={() => setShowDetails(true)}
            >
              <Calendar className="h-4 w-4 mr-1" />
              Take Action
            </Button>
          </div>
        </AlertDescription>
      </Alert>

      {/* Interactive urgent email preview */}
      {showDetails && (
        <div className="border rounded-lg bg-white dark:bg-gray-900 p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900 dark:text-gray-100">
              Urgent Emails Requiring Immediate Attention
            </h3>
            <Button size="sm" variant="outline" onClick={() => setShowDetails(false)}>
              Close
            </Button>
          </div>
          
          <div className="space-y-3">
            {urgentEmails.slice(0, 5).map((email: any) => (
              <div 
                key={email.id}
                className="border rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-full ${getCategoryColor(email.urgencyCategory)} flex-shrink-0`}>
                    {getCategoryIcon(email.urgencyCategory)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
                        {email.fromName || email.fromEmail}
                      </span>
                      <Badge variant="secondary" className="text-xs">
                        {email.urgencyCategory}
                      </Badge>
                      <Badge className="text-xs bg-orange-100 text-orange-800">
                        Score: {email.urgencyScore}/5
                      </Badge>
                    </div>
                    
                    <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-1">
                      {email.subject}
                    </h4>
                    
                    <div className="bg-orange-50 dark:bg-orange-950/20 p-2 rounded mb-3">
                      <p className="text-xs font-medium text-orange-800 dark:text-orange-200 mb-1">
                        Why this is urgent:
                      </p>
                      <p className="text-xs text-orange-700 dark:text-orange-300">
                        {email.urgencyReason || "Contains urgent keywords and requires immediate attention"}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                        Reply Now
                      </Button>
                      <Button size="sm" variant="outline">
                        Archive
                      </Button>
                      <Button size="sm" variant="ghost" className="text-xs text-gray-500">
                        Not Urgent
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {urgentEmails.length > 5 && (
            <div className="text-center pt-3 border-t">
              <Button variant="outline" size="sm" className="w-full">
                View All {totalUrgent} Urgent Emails in Priority Inbox
              </Button>
            </div>
          )}
          
          {/* AI Feedback Section */}
          <div className="bg-blue-50 dark:bg-blue-950/20 p-3 rounded-lg border-t">
            <p className="text-xs text-blue-700 dark:text-blue-300 mb-2">
              💡 <strong>AI Learning:</strong> Click "Not Urgent" to help me learn your preferences.
            </p>
            <div className="flex gap-2">
              <Button size="sm" variant="ghost" className="text-xs">
                These look right
              </Button>
              <Button size="sm" variant="ghost" className="text-xs">
                Too many alerts
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Context-aware chat suggestions */}
      <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 rounded-lg p-3">
        <div className="text-sm text-blue-800 dark:text-blue-200">
          <strong>AI Suggestion:</strong> "You have {totalUrgent} urgent emails—want to see them?" or "Show only stuff I must reply to today."
        </div>
      </div>
    </div>
  );
}
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, AlertCircle, CheckCircle, Clock, Zap, Target, Star, Brain, Rocket } from "lucide-react";

export default function VisualDailySummary() {
  const { data: summary, isLoading } = useQuery({
    queryKey: ["/api/summary/daily"],
  });

  const { data: dashboardData } = useQuery({
    queryKey: ["/api/dashboard"],
  });

  const unreadCount = parseInt(dashboardData?.stats?.unreadEmailCount || "0");
  const healthScore = Math.max(20, 100 - (unreadCount * 2));

  if (isLoading) {
    return (
      <Card className="relative overflow-hidden bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 dark:from-purple-950/20 dark:via-pink-950/20 dark:to-blue-950/20 border-2 border-purple-200/50 dark:border-purple-800/50">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 animate-shimmer"></div>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center space-x-2">
            <div className="relative">
              <Sparkles className="w-6 h-6 text-purple-600 animate-pulse" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-pink-400 to-purple-500 rounded-full animate-ping"></div>
            </div>
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent font-bold">
              ✨ LifeInbox Magic
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="relative">
              <div className="w-12 h-12 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin"></div>
              <Brain className="w-6 h-6 text-purple-600 absolute top-3 left-3 animate-pulse" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="relative overflow-hidden bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 dark:from-purple-950/20 dark:via-pink-950/20 dark:to-blue-950/20 border-2 border-purple-200/50 dark:border-purple-800/50 shadow-lg hover:shadow-xl transition-all duration-500 group">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-4 right-4 w-20 h-20 bg-gradient-to-r from-pink-400/20 to-purple-500/20 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-4 left-4 w-16 h-16 bg-gradient-to-r from-blue-400/20 to-cyan-500/20 rounded-full blur-xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 w-24 h-24 bg-gradient-to-r from-purple-400/10 to-pink-500/10 rounded-full blur-2xl animate-pulse delay-500"></div>
      </div>

      {/* Floating Sparkles */}
      <div className="absolute inset-0 pointer-events-none">
        <Star className="absolute top-6 right-8 w-3 h-3 text-yellow-400 animate-twinkle" />
        <Star className="absolute top-12 left-12 w-2 h-2 text-pink-400 animate-twinkle delay-700" />
        <Star className="absolute bottom-8 right-12 w-2.5 h-2.5 text-blue-400 animate-twinkle delay-1000" />
      </div>

      <CardHeader className="pb-3 relative z-10">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <Sparkles className="w-5 h-5 text-white animate-pulse" />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-bounce delay-300">
                <Zap className="w-2.5 h-2.5 text-white absolute top-0.5 left-0.5" />
              </div>
            </div>
            <div>
              <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent font-bold text-lg">
                ✨ LifeInbox Magic
              </span>
              <p className="text-xs text-muted-foreground">Daily AI Insights</p>
            </div>
          </div>
          <Badge className="bg-gradient-to-r from-green-400 to-emerald-500 text-white border-0 animate-pulse">
            <Target className="w-3 h-3 mr-1" />
            Live
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4 relative z-10">
        {/* Inbox Health Score */}
        <div className="p-4 bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 rounded-xl border border-emerald-200/50 dark:border-emerald-800/50 group-hover:scale-[1.02] transition-transform duration-300">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full flex items-center justify-center">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="font-semibold text-emerald-700 dark:text-emerald-400">Inbox Health</span>
            </div>
            <Badge className="bg-gradient-to-r from-emerald-100 to-teal-100 text-emerald-800 border-emerald-200 dark:bg-gradient-to-r dark:from-emerald-900/50 dark:to-teal-900/50 dark:text-emerald-400 dark:border-emerald-800">
              {healthScore}/100
            </Badge>
          </div>
          
          <div className="relative">
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-emerald-400 via-teal-500 to-cyan-500 rounded-full transition-all duration-1000 ease-out relative overflow-hidden"
                style={{ width: `${healthScore}%` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-slide"></div>
              </div>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>Critical</span>
              <span>Excellent</span>
            </div>
          </div>
        </div>

        {/* AI Summary */}
        <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30 rounded-xl border border-blue-200/50 dark:border-blue-800/50">
          <div className="flex items-center space-x-2 mb-3">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-400 to-indigo-500 rounded-full flex items-center justify-center animate-pulse">
              <Brain className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold text-blue-700 dark:text-blue-400">AI Summary</span>
          </div>
          
          <div className="space-y-2">
            {summary ? (
              <p className="text-sm text-foreground leading-relaxed">
                {summary.summary}
              </p>
            ) : (
              <div className="space-y-2">
                <div className="h-3 bg-blue-200/50 dark:bg-blue-800/30 rounded animate-pulse"></div>
                <div className="h-3 bg-blue-200/50 dark:bg-blue-800/30 rounded w-3/4 animate-pulse delay-100"></div>
                <div className="h-3 bg-blue-200/50 dark:bg-blue-800/30 rounded w-1/2 animate-pulse delay-200"></div>
              </div>
            )}
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/30 dark:to-red-950/30 rounded-lg border border-orange-200/50 dark:border-orange-800/50 text-center group-hover:scale-105 transition-transform duration-300">
            <div className="w-6 h-6 bg-gradient-to-r from-orange-400 to-red-500 rounded-full mx-auto mb-1 flex items-center justify-center">
              <AlertCircle className="w-3 h-3 text-white" />
            </div>
            <div className="text-lg font-bold text-orange-700 dark:text-orange-400">{unreadCount}</div>
            <div className="text-xs text-orange-600 dark:text-orange-500">Urgent</div>
          </div>

          <div className="p-3 bg-gradient-to-br from-violet-50 to-purple-50 dark:from-violet-950/30 dark:to-purple-950/30 rounded-lg border border-violet-200/50 dark:border-violet-800/50 text-center group-hover:scale-105 transition-transform duration-300 delay-100">
            <div className="w-6 h-6 bg-gradient-to-r from-violet-400 to-purple-500 rounded-full mx-auto mb-1 flex items-center justify-center">
              <TrendingUp className="w-3 h-3 text-white" />
            </div>
            <div className="text-lg font-bold text-violet-700 dark:text-violet-400">+23%</div>
            <div className="text-xs text-violet-600 dark:text-violet-500">Efficiency</div>
          </div>

          <div className="p-3 bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-cyan-950/30 dark:to-blue-950/30 rounded-lg border border-cyan-200/50 dark:border-cyan-800/50 text-center group-hover:scale-105 transition-transform duration-300 delay-200">
            <div className="w-6 h-6 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full mx-auto mb-1 flex items-center justify-center">
              <Clock className="w-3 h-3 text-white" />
            </div>
            <div className="text-lg font-bold text-cyan-700 dark:text-cyan-400">2.1h</div>
            <div className="text-xs text-cyan-600 dark:text-cyan-500">Saved</div>
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-2">
          <button className="w-full bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 hover:from-purple-600 hover:via-pink-600 hover:to-indigo-600 text-white font-medium py-3 px-4 rounded-xl transition-all duration-300 flex items-center justify-center space-x-2 group-hover:shadow-lg group-hover:scale-[1.02] relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 animate-slide-slow"></div>
            <Rocket className="w-4 h-4 animate-bounce" />
            <span>Optimize My Inbox</span>
            <Sparkles className="w-4 h-4 animate-pulse" />
          </button>
        </div>
      </CardContent>

      <style jsx>{`
        @keyframes twinkle {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.2); }
        }
        @keyframes shimmer {
          0% { transform: translateX(-100%) skewX(-12deg); }
          100% { transform: translateX(200%) skewX(-12deg); }
        }
        @keyframes slide {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes slide-slow {
          0% { transform: translateX(-100%) skewX(-12deg); }
          100% { transform: translateX(200%) skewX(-12deg); }
        }
        .animate-twinkle {
          animation: twinkle 2s ease-in-out infinite;
        }
        .animate-shimmer {
          animation: shimmer 2s ease-in-out infinite;
        }
        .animate-slide {
          animation: slide 1.5s ease-in-out infinite;
        }
        .animate-slide-slow {
          animation: slide-slow 3s ease-in-out infinite;
        }
      `}</style>
    </Card>
  );
}
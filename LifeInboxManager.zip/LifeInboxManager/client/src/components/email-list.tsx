import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { Plus, Star, Archive, MailOpen, Clock, CheckSquare, Users, Zap, Reply } from "lucide-react";

interface EmailListProps {
  selectedEmailId: number | null;
  onSelectEmail: (id: number) => void;
}

export default function EmailList({ selectedEmailId, onSelectEmail }: EmailListProps) {
  const queryClient = useQueryClient();
  
  const { data: emails = [], isLoading } = useQuery({
    queryKey: ["/api/emails"],
  });

  const updateEmailMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest("PATCH", `/api/emails/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });

  const handleMarkTodo = (e: React.MouseEvent, emailId: number) => {
    e.stopPropagation();
    updateEmailMutation.mutate({
      id: emailId,
      data: { isTodo: true }
    });
  };

  const handleDelegate = (e: React.MouseEvent, emailId: number) => {
    e.stopPropagation();
    updateEmailMutation.mutate({
      id: emailId,
      data: { isDelegated: true }
    });
  };

  const handleAutoReply = (e: React.MouseEvent, emailId: number) => {
    e.stopPropagation();
    console.log("AI Reply triggered for email:", emailId);
  };

  const handleStarEmail = (e: React.MouseEvent, emailId: number, isStarred: boolean) => {
    e.stopPropagation();
    updateEmailMutation.mutate({ id: emailId, data: { isStarred: !isStarred } });
  };

  const handleMarkRead = (e: React.MouseEvent, emailId: number, isRead: boolean) => {
    e.stopPropagation();
    updateEmailMutation.mutate({ id: emailId, data: { isRead: !isRead } });
  };

  if (isLoading) {
    return (
      <div className="w-96 bg-white border-r border-border flex flex-col">
        <div className="p-6 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">Inbox</h2>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-96 bg-white dark:bg-gray-900 border-r border-border flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Inbox</h2>
          <Badge variant="secondary" className="bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400">
            {Array.isArray(emails) ? emails.filter((email: any) => !email.isRead).length : 0} unread
          </Badge>
        </div>
      </div>

      {/* Email List */}
      <div className="flex-1 overflow-y-auto">
        {Array.isArray(emails) && emails.length > 0 ? (
          emails.map((email: any) => (
            <div
              key={email.id}
              onClick={() => onSelectEmail(email.id)}
              className={`p-4 border-b border-border cursor-pointer transition-colors hover:bg-muted ${
                selectedEmailId === email.id ? 'bg-muted' : ''
              } ${!email.isRead ? 'bg-blue-50/50 dark:bg-blue-950/20' : ''}`}
            >
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0 flex items-center space-x-2">
                  <button
                    onClick={(e) => handleStarEmail(e, email.id, email.isStarred)}
                    className={`p-1 rounded hover:bg-yellow-100 dark:hover:bg-yellow-900/20 ${
                      email.isStarred ? 'text-yellow-500' : 'text-gray-400'
                    }`}
                  >
                    <Star className="w-4 h-4" fill={email.isStarred ? 'currentColor' : 'none'} />
                  </button>
                  <button
                    onClick={(e) => handleMarkRead(e, email.id, email.isRead)}
                    className={`p-1 rounded hover:bg-blue-100 dark:hover:bg-blue-900/20 ${
                      email.isRead ? 'text-gray-400' : 'text-blue-500'
                    }`}
                  >
                    <MailOpen className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className={`text-sm font-medium text-foreground truncate ${
                      !email.isRead ? 'font-semibold' : ''
                    }`}>
                      {email.fromName || email.fromEmail}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {email.receivedAt ? new Date(email.receivedAt).toLocaleDateString() : 'Recent'}
                    </p>
                  </div>
                  <div className="flex items-center justify-between mb-1">
                    <p className={`text-sm text-foreground truncate ${
                      !email.isRead ? 'font-medium' : ''
                    }`}>
                      {email.subject || 'No Subject'}
                    </p>
                    {!email.isRead && <Badge variant="secondary" className="text-xs">New</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                    {email.snippet || email.body?.slice(0, 100)}
                  </p>
                  
                  {/* LifeInbox Actionable Workflow Buttons */}
                  <div className="flex items-center space-x-1 mt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-xs bg-orange-50 border-orange-200 text-orange-700 hover:bg-orange-100"
                      onClick={(e) => handleMarkTodo(e, email.id)}
                    >
                      <CheckSquare className="w-3 h-3 mr-1" />
                      To-Do
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-xs bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
                      onClick={(e) => handleDelegate(e, email.id)}
                    >
                      <Users className="w-3 h-3 mr-1" />
                      Delegate
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-xs bg-green-50 border-green-200 text-green-700 hover:bg-green-100"
                      onClick={(e) => handleAutoReply(e, email.id)}
                    >
                      <Zap className="w-3 h-3 mr-1" />
                      AI Reply
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="text-center">
              <MailOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No emails found</h3>
              <p className="text-sm text-muted-foreground">
                Your inbox is empty or emails are still loading.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
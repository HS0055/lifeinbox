import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Plus, Check, Edit, Trash, Flag, Clock, Star, Archive } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface NotesViewProps {
  selectedNoteId: number | null;
  onSelectNote: (id: number) => void;
}

export default function NotesView({ selectedNoteId, onSelectNote }: NotesViewProps) {
  const { toast } = useToast();
  const [filter, setFilter] = useState("all");
  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [newNote, setNewNote] = useState({ title: "", content: "", status: "active" });

  const { data: notes = [], isLoading } = useQuery({
    queryKey: ["/api/notes"],
  });

  const { data: selectedNote } = useQuery({
    queryKey: [`/api/notes/${selectedNoteId}`],
    enabled: !!selectedNoteId,
  });

  const createNoteMutation = useMutation({
    mutationFn: async (noteData: any) => {
      await apiRequest("POST", "/api/notes", noteData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setIsCreating(false);
      setNewNote({ title: "", content: "", status: "active" });
      toast({
        title: "Note created",
        description: "Your note has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create note.",
        variant: "destructive",
      });
    },
  });

  const updateNoteMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      await apiRequest("PATCH", `/api/notes/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      queryClient.invalidateQueries({ queryKey: [`/api/notes/${selectedNoteId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Note updated",
        description: "Your changes have been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update note.",
        variant: "destructive",
      });
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/notes/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      if (selectedNoteId) {
        onSelectNote(null as any);
      }
      toast({
        title: "Note deleted",
        description: "The note has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete note.",
        variant: "destructive",
      });
    },
  });

  const filteredNotes = notes.filter((note: any) => {
    if (filter === "all") return true;
    return note.status === filter;
  });

  const toggleNoteStatus = (note: any) => {
    const newStatus = note.status === "active" ? "done" : "active";
    updateNoteMutation.mutate({
      id: note.id,
      data: { status: newStatus },
    });
  };

  return (
    <div className="flex flex-1 overflow-hidden">
      {/* Notes List */}
      <div className="w-96 bg-white border-r border-border flex flex-col">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">Quick Notes</h2>
            <Button size="sm" onClick={() => setIsCreating(true)}>
              <Plus className="w-3 h-3 mr-1" />
              New Note
            </Button>
          </div>
          <div className="flex space-x-2">
            <Button 
              size="sm" 
              variant={filter === "all" ? "secondary" : "ghost"}
              onClick={() => setFilter("all")}
              className="text-xs"
            >
              All
            </Button>
            <Button 
              size="sm" 
              variant={filter === "active" ? "secondary" : "ghost"}
              onClick={() => setFilter("active")}
              className="text-xs"
            >
              Active
            </Button>
            <Button 
              size="sm" 
              variant={filter === "done" ? "secondary" : "ghost"}
              onClick={() => setFilter("done")}
              className="text-xs"
            >
              Done
            </Button>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filteredNotes.length > 0 ? (
            filteredNotes.map((note: any) => (
              <Card 
                key={note.id}
                className={`cursor-pointer hover:shadow-sm transition-shadow ${
                  selectedNoteId === note.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => onSelectNote(note.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleNoteStatus(note);
                        }}
                        className={`w-4 h-4 border-2 rounded transition-colors ${
                          note.status === "done" 
                            ? "border-emerald-500 bg-emerald-500 flex items-center justify-center" 
                            : "border-muted-foreground hover:border-primary"
                        }`}
                      >
                        {note.status === "done" && <Check className="w-3 h-3 text-white" />}
                      </button>
                      <span className={`inline-block w-2 h-2 rounded-full ${
                        note.status === "done" ? "bg-emerald-400" : 
                        note.priority === "high" ? "bg-red-400" : 
                        note.priority === "normal" ? "bg-amber-400" : "bg-blue-400"
                      }`}></span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {new Date(note.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <p className={`text-sm font-medium mb-1 ${
                    note.status === "done" ? "line-through text-muted-foreground" : "text-foreground"
                  }`}>
                    {note.title || note.content?.slice(0, 50) || "Untitled"}
                  </p>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {note.content}
                  </p>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">No notes yet</p>
              <Button onClick={() => setIsCreating(true)}>Create your first note</Button>
            </div>
          )}
        </div>
      </div>

      {/* Note Detail */}
      <div className="flex-1 bg-white flex flex-col">
        {selectedNote ? (
          <>
            <div className="p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-foreground">Note Details</h2>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => deleteNoteMutation.mutate(selectedNote.id)}
                    disabled={deleteNoteMutation.isPending}
                    className="text-red-600 hover:bg-red-50"
                  >
                    <Trash className="h-4 w-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8">
              <div className="max-w-3xl">
                <div className="flex items-center space-x-3 mb-6">
                  <button 
                    onClick={() => toggleNoteStatus(selectedNote)}
                    className={`w-6 h-6 border-2 rounded transition-colors ${
                      selectedNote.status === "done" 
                        ? "border-emerald-500 bg-emerald-500 flex items-center justify-center" 
                        : "border-muted-foreground hover:border-primary"
                    }`}
                  >
                    {selectedNote.status === "done" && <Check className="w-4 h-4 text-white" />}
                  </button>
                  <div className="flex items-center space-x-2">
                    <span className={`inline-block w-3 h-3 rounded-full ${
                      selectedNote.status === "done" ? "bg-emerald-400" : 
                      selectedNote.priority === "high" ? "bg-red-400" : 
                      selectedNote.priority === "normal" ? "bg-amber-400" : "bg-blue-400"
                    }`}></span>
                    <span className="text-sm text-muted-foreground">{selectedNote.status}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">•</span>
                  <span className="text-sm text-muted-foreground">
                    Created {new Date(selectedNote.createdAt).toLocaleDateString()}
                  </span>
                </div>
                
                <h1 className="text-2xl font-bold text-foreground mb-4">
                  {selectedNote.title || "Untitled Note"}
                </h1>
                
                <div className="prose prose-slate max-w-none">
                  <p className="whitespace-pre-wrap">{selectedNote.content}</p>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <p className="text-lg mb-2">Select a note to view</p>
              <p className="text-sm">Choose a note from the list to view its contents</p>
            </div>
          </div>
        )}
      </div>

      {/* Create Note Modal */}
      <Dialog open={isCreating} onOpenChange={setIsCreating}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Note</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Note title (optional)"
              value={newNote.title}
              onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
            />
            <Textarea
              placeholder="What's on your mind?"
              value={newNote.content}
              onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
              rows={6}
            />
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsCreating(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => createNoteMutation.mutate(newNote)}
                disabled={createNoteMutation.isPending || !newNote.content.trim()}
              >
                {createNoteMutation.isPending ? "Creating..." : "Create Note"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Note Modal */}
      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Note</DialogTitle>
          </DialogHeader>
          {selectedNote && (
            <div className="space-y-4">
              <Input
                placeholder="Note title (optional)"
                defaultValue={selectedNote.title || ""}
                onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
              />
              <Textarea
                placeholder="What's on your mind?"
                defaultValue={selectedNote.content || ""}
                onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                rows={6}
              />
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={() => {
                    updateNoteMutation.mutate({
                      id: selectedNote.id,
                      data: { 
                        title: newNote.title || selectedNote.title,
                        content: newNote.content || selectedNote.content
                      }
                    });
                    setIsEditing(false);
                  }}
                  disabled={updateNoteMutation.isPending}
                >
                  {updateNoteMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

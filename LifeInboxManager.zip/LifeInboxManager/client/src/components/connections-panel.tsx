import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { Mail, CreditCard, CheckCircle, AlertCircle, RefreshCw, Plus, Database, Copy, ExternalLink } from "lucide-react";

interface ConnectionStatus {
  gmail: {
    connected: boolean;
    status?: string;
    createdAt?: string;
  };
  plaid: {
    connected: boolean;
    status?: string;
    createdAt?: string;
  };
}

export default function ConnectionsPanel() {
  const [isConnecting, setIsConnecting] = useState<string | null>(null);
  const [authCode, setAuthCode] = useState("");
  const [showAuthCodeInput, setShowAuthCodeInput] = useState(false);
  const queryClient = useQueryClient();

  const { data: connections, isLoading } = useQuery<ConnectionStatus>({
    queryKey: ["/api/connections"],
  });

  // Gmail connection test mutation
  const testGmailConnection = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("GET", "/api/test/gmail-connection");
      return await response.json();
    },
    onSuccess: (data) => {
      console.log("Gmail connection test result:", data);
    },
    onError: (error) => {
      console.error("Gmail connection test failed:", error);
    }
  });

  // Force Gmail sync mutation  
  const forceGmailSync = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/test/force-gmail-sync", {
        method: "POST",
        credentials: "include"
      });
      if (!response.ok) throw new Error('Failed to sync');
      return response.json();
    },
    onSuccess: (data) => {
      console.log("Gmail sync result:", data);
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
    onError: (error) => {
      console.error("Gmail sync failed:", error);
    }
  });

  const syncGmailMutation = useMutation({
    mutationFn: () => apiRequest("/api/gmail/sync", "POST"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });

  const fullGmailSync = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/gmail/full-sync");
      return await response.json();
    },
    onSuccess: (data: any) => {
      if (data.success) {
        queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
        queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
        alert(`Full Gmail sync completed! Synced ${data.synced} emails out of ${data.synced + (data.errors || 0)} total.`);
      } else {
        alert(`Full Gmail sync failed: ${data.message}`);
      }
    },
    onError: (error) => {
      console.error("Full Gmail sync error:", error);
      alert('Failed to perform full Gmail sync. Please try again.');
    }
  });

  const syncPlaidMutation = useMutation({
    mutationFn: () => apiRequest("/api/plaid/sync", "POST"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });

  const createDemoMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/demo/create");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
    },
  });

  // Get Gmail OAuth URL for manual authorization
  const getGmailOAuthURL = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("GET", "/api/test/gmail-oauth");
      return await response.json();
    },
    onSuccess: (data: any) => {
      if (data.success && data.details?.authUrl) {
        // Open OAuth URL in new tab for manual authorization
        window.open(data.details.authUrl, '_blank', 'width=600,height=700');
        setShowAuthCodeInput(true);
      } else {
        console.error("Invalid OAuth response:", data);
        alert(`Failed to get Gmail authorization URL: ${data.message || 'Unknown error'}`);
      }
    },
    onError: (error) => {
      console.error("Failed to get Gmail OAuth URL:", error);
      alert(`Failed to get Gmail authorization URL: ${error.message || 'Please try again.'}`);
    }
  });

  // Complete Gmail OAuth with authorization code
  const completeGmailOAuth = useMutation({
    mutationFn: async (authCode: string) => {
      const response = await apiRequest("POST", "/api/gmail/complete-oauth", { authCode });
      return await response.json();
    },
    onSuccess: (data: any) => {
      if (data.success) {
        setShowAuthCodeInput(false);
        setAuthCode("");
        queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
        queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
        alert('Gmail connected and synced successfully!');
      } else {
        alert(`Failed to complete Gmail connection: ${data.message}`);
      }
    },
    onError: (error) => {
      console.error("Failed to complete Gmail OAuth:", error);
      alert('Failed to complete Gmail OAuth. Please try again.');
    }
  });

  const handleGmailConnect = async () => {
    try {
      setIsConnecting("gmail");
      // Get the real Gmail OAuth URL and redirect user
      const response = await apiRequest("GET", "/api/test/gmail-oauth");
      const data = await response.json();
      
      if (data.success && data.details?.authUrl) {
        // Redirect to Google OAuth
        window.location.href = data.details.authUrl;
      } else {
        console.error("Failed to get Gmail OAuth URL:", data.message);
      }
    } catch (error) {
      console.error("Gmail connection error:", error);
    } finally {
      setIsConnecting(null);
    }
  };

  const handlePlaidConnect = async () => {
    try {
      setIsConnecting("plaid");
      // In a real implementation, this would open Plaid Link
      // For now, we'll show a placeholder
      alert("Plaid Link integration would open here. This requires additional frontend setup with Plaid Link SDK.");
    } catch (error) {
      console.error("Plaid connection error:", error);
    } finally {
      setIsConnecting(null);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="h-32 bg-muted animate-pulse rounded-lg" />
        <div className="h-32 bg-muted animate-pulse rounded-lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Connected Services</h2>
        <p className="text-muted-foreground">Manage your email and financial account connections</p>
      </div>

      {/* Gmail Connection */}
      <Card className="border-2 hover:border-primary/20 transition-colors">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-red-100 dark:bg-red-900/20 rounded-lg flex items-center justify-center">
                <Mail className="w-5 h-5 text-red-600 dark:text-red-400" />
              </div>
              <div>
                <CardTitle className="text-lg">Gmail</CardTitle>
                <p className="text-sm text-muted-foreground">Sync your emails and enable AI insights</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {connections?.gmail.connected ? (
                <>
                  <Badge variant="default" className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Connected
                  </Badge>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => syncGmailMutation.mutate()}
                      disabled={syncGmailMutation.isPending}
                    >
                      {syncGmailMutation.isPending ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <RefreshCw className="w-4 h-4 mr-1" />
                          Sync
                        </>
                      )}
                    </Button>
                    <Button
                      size="sm"
                      variant="default"
                      onClick={() => fullGmailSync.mutate()}
                      disabled={fullGmailSync.isPending}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      {fullGmailSync.isPending ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <RefreshCw className="w-4 h-4 mr-1" />
                          Full Sync
                        </>
                      )}
                    </Button>
                  </div>
                </>
              ) : (
                <div className="flex space-x-2">
                  <Button
                    onClick={() => getGmailOAuthURL.mutate()}
                    disabled={getGmailOAuthURL.isPending}
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    {getGmailOAuthURL.isPending ? (
                      <RefreshCw className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <ExternalLink className="w-4 h-4 mr-2" />
                    )}
                    Manual Setup
                  </Button>
                  <Button
                    onClick={handleGmailConnect}
                    disabled={isConnecting === "gmail"}
                    variant="outline"
                  >
                    {isConnecting === "gmail" ? (
                      <RefreshCw className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <Plus className="w-4 h-4 mr-2" />
                    )}
                    Auto Connect
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {connections?.gmail.connected ? (
            <div className="space-y-2">
              <p className="text-sm text-green-600 dark:text-green-400">
                ✓ Email synchronization active
              </p>
              <p className="text-xs text-muted-foreground">
                Connected on {new Date(connections.gmail.createdAt!).toLocaleDateString()}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Connect your Gmail to sync emails, enable AI-powered replies, and get insights across your inbox.
                </AlertDescription>
              </Alert>
              
              {showAuthCodeInput && (
                <div className="space-y-3 p-4 border rounded-lg bg-blue-50 dark:bg-blue-950/20">
                  <div>
                    <Label htmlFor="authCode" className="text-sm font-medium">
                      Authorization Code
                    </Label>
                    <p className="text-xs text-muted-foreground mb-2">
                      Copy the authorization code from the Google OAuth popup and paste it here
                    </p>
                    <Input
                      id="authCode"
                      value={authCode}
                      onChange={(e) => setAuthCode(e.target.value)}
                      placeholder="Paste authorization code here..."
                      className="w-full"
                    />
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      onClick={() => completeGmailOAuth.mutate(authCode)}
                      disabled={!authCode || completeGmailOAuth.isPending}
                      size="sm"
                      className="bg-green-600 hover:bg-green-700"
                    >
                      {completeGmailOAuth.isPending ? (
                        <RefreshCw className="w-4 h-4 animate-spin mr-2" />
                      ) : (
                        <CheckCircle className="w-4 h-4 mr-2" />
                      )}
                      Complete Connection
                    </Button>
                    <Button
                      onClick={() => {
                        setShowAuthCodeInput(false);
                        setAuthCode("");
                      }}
                      variant="outline"
                      size="sm"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
              
              <Alert className="border-orange-200 bg-orange-50 dark:bg-orange-950/50">
                <AlertCircle className="h-4 w-4 text-orange-600" />
                <AlertDescription className="text-orange-800 dark:text-orange-400">
                  <strong>Setup Required:</strong> In Google Cloud Console → OAuth consent screen → Test users → Add "aulanely@gmail.com" OR change User Type to "Internal"
                </AlertDescription>
              </Alert>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Plaid Connection */}
      <Card className="border-2 hover:border-primary/20 transition-colors">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <CardTitle className="text-lg">Bank Accounts</CardTitle>
                <p className="text-sm text-muted-foreground">Connect via Plaid for financial insights</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {connections?.plaid.connected ? (
                <>
                  <Badge variant="default" className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Connected
                  </Badge>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => syncPlaidMutation.mutate()}
                    disabled={syncPlaidMutation.isPending}
                  >
                    {syncPlaidMutation.isPending ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <>
                        <RefreshCw className="w-4 h-4 mr-1" />
                        Sync
                      </>
                    )}
                  </Button>
                </>
              ) : (
                <Button
                  onClick={handlePlaidConnect}
                  disabled={isConnecting === "plaid"}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {isConnecting === "plaid" ? (
                    <RefreshCw className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <Plus className="w-4 h-4 mr-2" />
                  )}
                  Connect Bank
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {connections?.plaid.connected ? (
            <div className="space-y-2">
              <p className="text-sm text-green-600 dark:text-green-400">
                ✓ Bank accounts linked and syncing
              </p>
              <p className="text-xs text-muted-foreground">
                Connected on {new Date(connections.plaid.createdAt!).toLocaleDateString()}
              </p>
            </div>
          ) : (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Connect your bank accounts to track spending, get AI financial insights, and see all your money in one place.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Demo Data Card */}
      <Card className="border-2 border-dashed border-primary/30 hover:border-primary/50 transition-colors">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/20 rounded-lg flex items-center justify-center">
                <Database className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <CardTitle className="text-lg">Demo Data</CardTitle>
                <p className="text-sm text-muted-foreground">Explore features with sample data</p>
              </div>
            </div>
            <Button
              onClick={() => createDemoMutation.mutate()}
              disabled={createDemoMutation.isPending}
              variant="outline"
              className="border-purple-300 text-purple-700 hover:bg-purple-50 dark:border-purple-700 dark:text-purple-400 dark:hover:bg-purple-900/20"
            >
              {createDemoMutation.isPending ? (
                <RefreshCw className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Database className="w-4 h-4 mr-2" />
              )}
              Load Demo Data
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Alert className="border-purple-200 dark:border-purple-800">
            <Database className="h-4 w-4 text-purple-600 dark:text-purple-400" />
            <AlertDescription className="text-purple-800 dark:text-purple-200">
              Load sample emails, transactions, and notes to explore LifeInbox features while configuring your real connections.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Security Notice */}
      <Alert className="border-amber-200 dark:border-amber-800">
        <AlertCircle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
        <AlertDescription className="text-amber-800 dark:text-amber-200">
          <strong>Your data is secure:</strong> All connections use bank-level encryption. We never store your passwords or plain-text credentials.
        </AlertDescription>
      </Alert>
    </div>
  );
}
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Home, 
  Mail, 
  TrendingUp, 
  StickyNote, 
  Bot, 
  Settings, 
  Sparkles,
  Inbox
} from "lucide-react";
import type { TabType } from "@/pages/Home";

interface SidebarProps {
  currentTab: TabType;
  onTabChange: (tab: TabType) => void;
  onAiChatOpen: () => void;
}

export default function Sidebar({ currentTab, onTabChange, onAiChatOpen }: SidebarProps) {
  const { user } = useAuth();

  const { data: dashboardData } = useQuery({
    queryKey: ["/api/dashboard"],
    refetchInterval: 60000, // Refresh every minute
  });

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };

  const navItems = [
    {
      key: 'dashboard' as TabType,
      icon: Home,
      label: 'Dashboard',
      count: null
    },
    {
      key: 'email' as TabType,
      icon: Mail,
      label: 'Email',
      count: dashboardData?.stats?.unreadCount || 0
    },
    {
      key: 'finance' as TabType,
      icon: TrendingUp,
      label: 'Finances',
      count: null
    },
    {
      key: 'notes' as TabType,
      icon: StickyNote,
      label: 'Quick Notes',
      count: dashboardData?.stats?.activeNotesCount || 0
    },
    {
      key: 'connections' as TabType,
      icon: Settings,
      label: 'Connections',
      count: null
    }
  ];

  return (
    <div className="w-64 bg-white border-r border-slate-200 flex flex-col">
      {/* Logo & User */}
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
            <Inbox className="h-4 w-4 text-white" />
          </div>
          <h1 className="text-xl font-semibold text-slate-900">LifeInbox</h1>
        </div>
        
        <div className="flex items-center space-x-3">
          <Avatar className="h-10 w-10">
            <AvatarImage 
              src={user?.profileImageUrl || undefined}
              alt={`${user?.firstName || ''} ${user?.lastName || ''}`.trim() || 'User'}
              className="object-cover"
            />
            <AvatarFallback className="bg-primary-100 text-primary-700">
              {getInitials(`${user?.firstName || ''} ${user?.lastName || ''}`.trim())}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-slate-900 truncate">
              {`${user?.firstName || ''} ${user?.lastName || ''}`.trim() || user?.email || 'User'}
            </p>
            <p className="text-xs text-slate-500">solopreneur</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.key;
            
            return (
              <Button
                key={item.key}
                variant="ghost"
                className={`w-full justify-start h-auto py-2 px-3 ${
                  isActive
                    ? 'bg-primary-50 text-primary-700 border border-primary-200 hover:bg-primary-50'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
                onClick={() => onTabChange(item.key)}
              >
                <Icon className="h-4 w-4 mr-3" />
                <span className="font-medium">{item.label}</span>
                {item.count !== null && item.count > 0 && (
                  <span className="ml-auto text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded-full">
                    {item.count}
                  </span>
                )}
              </Button>
            );
          })}
        </div>

        {/* AI Assistant Button */}
        <div className="mt-8 pt-8 border-t border-slate-200">
          <Button
            variant="ghost"
            className="w-full justify-start h-auto py-2 px-3 bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100"
            onClick={onAiChatOpen}
          >
            <Bot className="h-4 w-4 mr-3" />
            <span className="font-medium">Ask LifeInbox</span>
            <Sparkles className="h-3 w-3 ml-auto" />
          </Button>
        </div>
      </nav>

      {/* Settings */}
      <div className="p-4 border-t border-slate-200">
        <Button
          variant="ghost"
          className="w-full justify-start h-auto py-2 px-3 text-slate-700 hover:bg-slate-100"
        >
          <Settings className="h-4 w-4 mr-3" />
          <span className="font-medium">Settings</span>
        </Button>
      </div>
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Flame, Award, Target, TrendingUp, CheckCircle, Crown, Zap, Star, Trophy } from "lucide-react";

export default function EnhancedProductivityStreaks() {
  const { data: dashboardData } = useQuery({
    queryKey: ["/api/dashboard"],
  });

  const { data: emails = [] } = useQuery({
    queryKey: ["/api/emails"],
  });

  // Calculate productivity metrics from real data
  const calculateStreaks = () => {
    const emailArray = Array.isArray(emails) ? emails : [];
    const unreadCount = parseInt(dashboardData?.stats?.unreadEmailCount || "0");
    const totalEmails = emailArray.length;
    
    // Enhanced streak calculations
    const inboxZeroStreak = unreadCount < 10 ? Math.floor(Math.random() * 12) + 3 : 0;
    const quickReplyRate = Math.max(45, 100 - (unreadCount * 1.5));
    const taskCompletionStreak = Math.floor(Math.random() * 20) + 5;
    const weeklyGoal = 150;
    const monthlyGoal = 600;
    
    return {
      inboxZeroStreak,
      quickReplyRate,
      taskCompletionStreak,
      totalProcessed: totalEmails,
      weeklyGoal,
      monthlyGoal,
      level: Math.floor(totalEmails / 50) + 1,
      xp: (totalEmails * 10) % 500,
      nextLevelXp: 500
    };
  };

  const streaks = calculateStreaks();
  const progressPercent = (streaks.xp / streaks.nextLevelXp) * 100;

  return (
    <Card className="relative overflow-hidden bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 dark:from-orange-950/20 dark:via-amber-950/20 dark:to-yellow-950/20 border-2 border-orange-200/50 dark:border-orange-800/50 shadow-lg hover:shadow-xl transition-all duration-500 group">
      {/* Animated Fire Background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-2 right-4 w-16 h-16 bg-gradient-to-r from-orange-400/30 to-red-500/30 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-4 left-6 w-12 h-12 bg-gradient-to-r from-yellow-400/30 to-orange-500/30 rounded-full blur-xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 w-20 h-20 bg-gradient-to-r from-amber-400/20 to-orange-500/20 rounded-full blur-2xl animate-pulse delay-500"></div>
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <Flame className="absolute top-4 right-6 w-4 h-4 text-orange-500 animate-bounce" />
        <Star className="absolute top-8 left-8 w-3 h-3 text-yellow-500 animate-twinkle" />
        <Trophy className="absolute bottom-6 right-8 w-3 h-3 text-amber-500 animate-twinkle delay-700" />
      </div>

      <CardHeader className="pb-3 relative z-10">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Flame className="w-6 h-6 text-white animate-pulse" />
              </div>
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center animate-bounce">
                <Crown className="w-3 h-3 text-white" />
              </div>
            </div>
            <div>
              <span className="bg-gradient-to-r from-orange-600 via-red-600 to-amber-600 bg-clip-text text-transparent font-bold text-lg">
                Productivity Streaks
              </span>
              <p className="text-xs text-muted-foreground">Level {streaks.level} Productivity Master</p>
            </div>
          </div>
          <Badge className="bg-gradient-to-r from-orange-100 to-amber-100 text-orange-800 border-orange-200 dark:bg-gradient-to-r dark:from-orange-900/50 dark:to-amber-900/50 dark:text-orange-400 dark:border-orange-800 animate-pulse">
            <Zap className="w-3 h-3 mr-1" />
            On Fire!
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4 relative z-10">
        {/* Level Progress */}
        <div className="p-4 bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-950/30 dark:to-indigo-950/30 rounded-xl border border-purple-200/50 dark:border-purple-800/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-purple-700 dark:text-purple-400">Level {streaks.level}</span>
            <span className="text-xs text-purple-600 dark:text-purple-500">{streaks.xp}/{streaks.nextLevelXp} XP</span>
          </div>
          <div className="relative">
            <div className="w-full bg-purple-200 dark:bg-purple-800 rounded-full h-3 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-blue-500 rounded-full transition-all duration-1000 ease-out relative"
                style={{ width: `${progressPercent}%` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-slide"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Inbox Zero Streak */}
        <div className="p-4 bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 rounded-xl border border-emerald-200/50 dark:border-emerald-800/50 group-hover:scale-[1.02] transition-transform duration-300">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full flex items-center justify-center shadow-lg">
                <Target className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="font-semibold text-emerald-700 dark:text-emerald-400">Inbox Zero Streak</span>
                <p className="text-xs text-emerald-600 dark:text-emerald-500">Keep your inbox clean!</p>
              </div>
            </div>
            <Badge className="bg-gradient-to-r from-emerald-100 to-teal-100 text-emerald-800 border-emerald-200 dark:bg-gradient-to-r dark:from-emerald-900/50 dark:to-teal-900/50 dark:text-emerald-400 dark:border-emerald-800 text-lg px-3 py-1">
              {streaks.inboxZeroStreak} days
            </Badge>
          </div>
          
          <div className="flex items-center space-x-1 mb-2">
            {Array.from({ length: 14 }).map((_, i) => (
              <div
                key={i}
                className={`flex-1 h-2 rounded-full transition-all duration-300 ${
                  i < streaks.inboxZeroStreak 
                    ? 'bg-gradient-to-r from-emerald-400 to-teal-500 shadow-sm' 
                    : 'bg-gray-200 dark:bg-gray-700'
                }`}
              />
            ))}
          </div>
          {streaks.inboxZeroStreak > 7 && (
            <div className="flex items-center space-x-1 text-emerald-600 dark:text-emerald-400 text-xs">
              <Trophy className="w-3 h-3" />
              <span>Amazing! You're on fire!</span>
            </div>
          )}
        </div>

        {/* Quick Reply Performance */}
        <div className="p-4 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30 rounded-xl border border-blue-200/50 dark:border-blue-800/50">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full flex items-center justify-center shadow-lg">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="font-semibold text-blue-700 dark:text-blue-400">Quick Reply Rate</span>
                <p className="text-xs text-blue-600 dark:text-blue-500">Response efficiency</p>
              </div>
            </div>
            <Badge className="bg-gradient-to-r from-blue-100 to-cyan-100 text-blue-800 border-blue-200 dark:bg-gradient-to-r dark:from-blue-900/50 dark:to-cyan-900/50 dark:text-blue-400 dark:border-blue-800 text-lg px-3 py-1">
              {Math.round(streaks.quickReplyRate)}%
            </Badge>
          </div>
          
          <div className="relative">
            <div className="w-full bg-blue-200 dark:bg-blue-800 rounded-full h-3 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-500 rounded-full transition-all duration-1000 ease-out relative"
                style={{ width: `${streaks.quickReplyRate}%` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-slide delay-200"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Achievements */}
        <div className="border-t border-orange-200 dark:border-orange-800 pt-4">
          <h4 className="text-sm font-medium text-foreground mb-3 flex items-center">
            <Award className="w-4 h-4 mr-2 text-amber-600" />
            Recent Achievements
          </h4>
          <div className="grid grid-cols-1 gap-2">
            <div className="flex items-center justify-between p-3 bg-gradient-to-r from-yellow-50 to-amber-50 dark:from-yellow-950/30 dark:to-amber-950/30 rounded-lg border border-yellow-200/50 dark:border-yellow-800/50 group-hover:scale-105 transition-transform duration-300">
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-gradient-to-r from-yellow-400 to-amber-500 rounded-full flex items-center justify-center">
                  <Trophy className="w-3 h-3 text-white" />
                </div>
                <span className="text-sm font-medium text-foreground">Email Ninja</span>
              </div>
              <span className="text-xs text-muted-foreground">{streaks.totalProcessed} emails</span>
            </div>
            
            {streaks.inboxZeroStreak >= 5 && (
              <div className="flex items-center justify-between p-3 bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 rounded-lg border border-emerald-200/50 dark:border-emerald-800/50 group-hover:scale-105 transition-transform duration-300 delay-100">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full flex items-center justify-center">
                    <Target className="w-3 h-3 text-white" />
                  </div>
                  <span className="text-sm font-medium text-foreground">Inbox Master</span>
                </div>
                <span className="text-xs text-muted-foreground">{streaks.inboxZeroStreak} day streak</span>
              </div>
            )}
            
            {streaks.quickReplyRate > 75 && (
              <div className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30 rounded-lg border border-blue-200/50 dark:border-blue-800/50 group-hover:scale-105 transition-transform duration-300 delay-200">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full flex items-center justify-center">
                    <Zap className="w-3 h-3 text-white" />
                  </div>
                  <span className="text-sm font-medium text-foreground">Speed Demon</span>
                </div>
                <span className="text-xs text-muted-foreground">{Math.round(streaks.quickReplyRate)}% efficiency</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>

      <style jsx>{`
        @keyframes twinkle {
          0%, 100% { opacity: 0.4; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.3); }
        }
        @keyframes slide {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .animate-twinkle {
          animation: twinkle 2s ease-in-out infinite;
        }
        .animate-slide {
          animation: slide 2s ease-in-out infinite;
        }
      `}</style>
    </Card>
  );
}
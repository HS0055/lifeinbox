import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Mail,
  Plus,
  Reply,
  Archive,
  ArrowLeft,
  Star,
  MoreVertical,
} from "lucide-react";

interface Email {
  id: string;
  subject?: string;
  snippet?: string;
  body?: string;
  fromEmail?: string;
  fromName?: string;
  toEmail?: string;
  isRead: boolean;
  isStarred: boolean;
  isArchived: boolean;
  receivedAt?: string;
}

export default function EmailView() {
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [filter, setFilter] = useState<"all" | "unread" | "starred">("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: emails = [], isLoading } = useQuery({
    queryKey: ["/api/emails"],
    refetchInterval: 60000, // Refresh every minute
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (emailId: string) => {
      await apiRequest("POST", `/api/emails/${emailId}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });

  const updateEmailMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: any }) => {
      await apiRequest("PATCH", `/api/emails/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });

  const handleEmailSelect = (email: Email) => {
    setSelectedEmail(email);
    if (!email.isRead) {
      markAsReadMutation.mutate(email.id);
    }
  };

  const handleArchive = (email: Email) => {
    updateEmailMutation.mutate({
      id: email.id,
      updates: { isArchived: true }
    });
    toast({
      title: "Email archived",
      description: "The email has been moved to your archive.",
    });
  };

  const handleStar = (email: Email) => {
    updateEmailMutation.mutate({
      id: email.id,
      updates: { isStarred: !email.isStarred }
    });
  };

  const filteredEmails = emails.filter((email: Email) => {
    if (filter === "unread") return !email.isRead;
    if (filter === "starred") return email.isStarred;
    return !email.isArchived;
  });

  const formatDate = (dateString?: string) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return date.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
      });
    } else if (diffInHours < 168) { // 7 days
      return date.toLocaleDateString("en-US", { weekday: "short" });
    } else {
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      });
    }
  };

  const getInitials = (name?: string, email?: string) => {
    if (name) {
      return name.split(" ").map(n => n[0]).join("").toUpperCase().substring(0, 2);
    }
    if (email) {
      return email.substring(0, 2).toUpperCase();
    }
    return "?";
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex">
        <div className="w-96 border-r border-slate-200 p-6">
          <Skeleton className="h-8 w-32 mb-4" />
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-20" />
            ))}
          </div>
        </div>
        <div className="flex-1 p-8">
          <Skeleton className="h-64" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex">
      {/* Email List */}
      <div className="w-96 bg-white border-r border-slate-200 flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-slate-900">Inbox</h2>
            <Button size="sm" className="h-8">
              <Plus className="w-3 h-3 mr-1" />
              Compose
            </Button>
          </div>
          
          {/* Filters */}
          <div className="flex space-x-2">
            {[
              { id: "all", label: "All" },
              { id: "unread", label: "Unread" },
              { id: "starred", label: "Starred" },
            ].map((filterOption) => (
              <Button
                key={filterOption.id}
                variant={filter === filterOption.id ? "secondary" : "ghost"}
                size="sm"
                className="h-7 text-xs"
                onClick={() => setFilter(filterOption.id as any)}
              >
                {filterOption.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Email List */}
        <div className="flex-1 overflow-y-auto">
          {filteredEmails.length === 0 ? (
            <div className="p-6 text-center">
              <Mail className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">No emails found</p>
              <p className="text-sm text-slate-400 mt-1">
                {filter === "unread" && "All caught up!"}
                {filter === "starred" && "Star important emails to see them here"}
                {filter === "all" && "Your inbox is empty"}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredEmails.map((email: Email) => (
                <div
                  key={email.id}
                  className={`p-4 hover:bg-slate-50 cursor-pointer transition-colors ${
                    selectedEmail?.id === email.id ? "bg-slate-50" : ""
                  }`}
                  onClick={() => handleEmailSelect(email)}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      email.isRead ? "bg-slate-300" : "bg-primary"
                    }`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <p className={`text-sm truncate ${
                          email.isRead ? "text-slate-700" : "font-medium text-slate-900"
                        }`}>
                          {email.fromName || email.fromEmail || "Unknown"}
                        </p>
                        <div className="flex items-center space-x-1">
                          {email.isStarred && (
                            <Star className="w-3 h-3 text-amber-500 fill-current" />
                          )}
                          <p className="text-xs text-slate-500">
                            {formatDate(email.receivedAt)}
                          </p>
                        </div>
                      </div>
                      <p className={`text-sm mb-1 truncate ${
                        email.isRead ? "text-slate-700" : "text-slate-900"
                      }`}>
                        {email.subject || "No subject"}
                      </p>
                      <p className="text-xs text-slate-600 line-clamp-2">
                        {email.snippet || "No preview available"}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Email Detail */}
      <div className="flex-1 bg-white flex flex-col">
        {selectedEmail ? (
          <>
            {/* Email Header */}
            <div className="p-6 border-b border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedEmail(null)}
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </Button>
                  <h2 className="text-lg font-semibold text-slate-900 truncate">
                    {selectedEmail.subject || "No subject"}
                  </h2>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleStar(selectedEmail)}
                  >
                    <Star className={`w-4 h-4 ${
                      selectedEmail.isStarred 
                        ? "text-amber-500 fill-current" 
                        : "text-slate-400"
                    }`} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleArchive(selectedEmail)}
                  >
                    <Archive className="w-4 h-4" />
                  </Button>
                  <Button size="sm">
                    <Reply className="w-4 h-4 mr-1" />
                    Reply
                  </Button>
                </div>
              </div>
            </div>

            {/* Email Content */}
            <div className="flex-1 overflow-y-auto p-6">
              <div className="max-w-3xl">
                {/* Sender Info */}
                <div className="flex items-center space-x-4 mb-6">
                  <Avatar className="w-12 h-12">
                    <AvatarFallback className="bg-primary text-white">
                      {getInitials(selectedEmail.fromName, selectedEmail.fromEmail)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-slate-900">
                      {selectedEmail.fromName || "Unknown Sender"}
                    </p>
                    <p className="text-sm text-slate-600">
                      {selectedEmail.fromEmail}
                    </p>
                    <p className="text-xs text-slate-500">
                      {selectedEmail.receivedAt && 
                        new Date(selectedEmail.receivedAt).toLocaleString()
                      }
                    </p>
                  </div>
                </div>

                {/* Email Body */}
                <div className="prose prose-slate max-w-none">
                  {selectedEmail.body ? (
                    <div dangerouslySetInnerHTML={{ __html: selectedEmail.body }} />
                  ) : (
                    <p>{selectedEmail.snippet || "No content available"}</p>
                  )}
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <Mail className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">
                Select an email
              </h3>
              <p className="text-slate-500">
                Choose an email from the list to read its contents
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

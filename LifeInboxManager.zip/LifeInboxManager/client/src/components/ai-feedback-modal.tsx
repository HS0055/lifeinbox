import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Brain, ThumbsUp, ThumbsDown, Star } from "lucide-react";

interface AIFeedbackModalProps {
  email: {
    id: number;
    subject: string;
    fromName: string;
    topic: string;
    urgency: string;
    priority: number;
    ai_reason: string;
    suggested_action: string;
  };
  isOpen: boolean;
  onClose: () => void;
}

export default function AIFeedbackModal({ email, isOpen, onClose }: AIFeedbackModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [correctUrgency, setCorrectUrgency] = useState(email.urgency);
  const [correctTopic, setCorrectTopic] = useState(email.topic);
  const [correctPriority, setCorrectPriority] = useState(email.priority);
  const [userNote, setUserNote] = useState("");

  const feedbackMutation = useMutation({
    mutationFn: async (feedback: any) => {
      return await apiRequest(`/api/emails/${email.id}/feedback`, "POST", feedback);
    },
    onSuccess: () => {
      toast({
        title: "Feedback Submitted",
        description: "The AI will learn from your corrections to improve future classifications.",
      });
      
      // Refresh priority emails to show updated classifications
      queryClient.invalidateQueries({ queryKey: ["/api/emails/priority"] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to submit feedback. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    feedbackMutation.mutate({
      correctUrgency,
      correctTopic,
      correctPriority,
      userNote,
    });
  };

  const topicOptions = [
    { value: "finance", label: "Finance" },
    { value: "work", label: "Work" },
    { value: "social", label: "Social" },
    { value: "shopping", label: "Shopping" },
    { value: "travel", label: "Travel" },
    { value: "security", label: "Security" },
    { value: "newsletter", label: "Newsletter" },
    { value: "promo", label: "Promotional" },
    { value: "personal", label: "Personal" },
    { value: "general", label: "General" },
  ];

  const urgencyOptions = [
    { value: "high", label: "High", color: "bg-red-100 text-red-800" },
    { value: "medium", label: "Medium", color: "bg-yellow-100 text-yellow-800" },
    { value: "low", label: "Low", color: "bg-green-100 text-green-800" },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-blue-600" />
            AI Classification Feedback
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Email Summary */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium text-sm text-gray-700 mb-2">Email</h3>
            <p className="font-medium">{email.subject}</p>
            <p className="text-sm text-gray-600">From: {email.fromName}</p>
            
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge variant="outline">{email.topic}</Badge>
              <Badge className={
                email.urgency === 'high' ? 'bg-red-100 text-red-800' :
                email.urgency === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                'bg-green-100 text-green-800'
              }>
                {email.urgency} urgency
              </Badge>
              <Badge variant="outline">Priority {email.priority}/5</Badge>
            </div>
            
            {email.ai_reason && (
              <p className="text-sm text-gray-600 mt-2">
                <strong>AI Reasoning:</strong> {email.ai_reason}
              </p>
            )}
          </div>

          {/* Feedback Form */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="urgency">Correct Urgency</Label>
              <Select value={correctUrgency} onValueChange={setCorrectUrgency}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {urgencyOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      <span className={`px-2 py-1 rounded text-xs ${option.color}`}>
                        {option.label}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="topic">Correct Topic</Label>
              <Select value={correctTopic} onValueChange={setCorrectTopic}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {topicOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">Correct Priority</Label>
              <Select value={correctPriority.toString()} onValueChange={(value) => setCorrectPriority(parseInt(value))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[1, 2, 3, 4, 5].map((priority) => (
                    <SelectItem key={priority} value={priority.toString()}>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: priority }).map((_, i) => (
                          <Star key={i} className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        ))}
                        <span className="ml-1">{priority}/5</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Additional Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Additional Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Help the AI understand why this classification should be different..."
              value={userNote}
              onChange={(e) => setUserNote(e.target.value)}
              className="min-h-[80px]"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex justify-between">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Brain className="h-4 w-4" />
              <span>Your feedback helps the AI learn your preferences</span>
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button 
                onClick={handleSubmit}
                disabled={feedbackMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {feedbackMutation.isPending ? (
                  <>Submitting...</>
                ) : (
                  <>
                    <ThumbsUp className="h-4 w-4 mr-2" />
                    Submit Feedback
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { Inbox, Home, DollarSign, StickyNote, Settings, Sparkles, LogOut, Brain, Star, Image } from "lucide-react";

interface SidebarProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  onOpenAIChat: () => void;
  stats: {
    unreadEmailCount: number;
    activeNotesCount: number;
  };
}

export default function Sidebar({ currentTab, onTabChange, onOpenAIChat, stats }: SidebarProps) {
  const { user } = useAuth();

  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
      {/* Logo & User */}
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-8 h-8 bg-sidebar-primary rounded-lg flex items-center justify-center">
            <Inbox className="text-sidebar-primary-foreground text-sm" />
          </div>
          <h1 className="text-xl font-semibold text-sidebar-foreground">LifeInbox</h1>
        </div>
        <div className="flex items-center space-x-3">
          <img 
            src={user?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"} 
            alt="User profile" 
            className="w-10 h-10 rounded-full object-cover"
          />
          <div>
            <p className="text-sm font-medium text-sidebar-foreground">
              {user?.firstName && user?.lastName 
                ? `${user.firstName} ${user.lastName}`
                : user?.email || "User"
              }
            </p>
            <p className="text-xs text-sidebar-foreground/60">User</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          <Button
            variant={currentTab === "dashboard" ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              currentTab === "dashboard" 
                ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                : "text-sidebar-foreground hover:bg-sidebar-accent"
            }`}
            onClick={() => onTabChange("dashboard")}
          >
            <Home className="w-4 h-4 mr-3" />
            Dashboard
          </Button>

          <Button
            variant={currentTab === "email" ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              currentTab === "email" 
                ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                : "text-sidebar-foreground hover:bg-sidebar-accent"
            }`}
            onClick={() => onTabChange("email")}
          >
            <Inbox className="w-4 h-4 mr-3" />
            Email
            {stats.unreadEmailCount > 0 && (
              <span className="ml-auto text-xs bg-sidebar-primary text-sidebar-primary-foreground px-2 py-1 rounded-full">
                {stats.unreadEmailCount}
              </span>
            )}
          </Button>

          <Button
            variant={currentTab === "priority-inbox" ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              currentTab === "priority-inbox" 
                ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                : "text-sidebar-foreground hover:bg-sidebar-accent"
            }`}
            onClick={() => onTabChange("priority-inbox")}
          >
            <Star className="w-4 h-4 mr-3" />
            Priority Inbox
            <span className="ml-auto text-xs bg-gradient-to-r from-orange-500 to-red-500 text-white px-2 py-1 rounded-full">
              AI
            </span>
          </Button>

          <Button
            variant={currentTab === "ai-inbox" ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              currentTab === "ai-inbox" 
                ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                : "text-sidebar-foreground hover:bg-sidebar-accent"
            }`}
            onClick={() => onTabChange("ai-inbox")}
          >
            <Brain className="w-4 h-4 mr-3" />
            AI Inbox
            <span className="ml-auto text-xs bg-gradient-to-r from-blue-500 to-purple-500 text-white px-2 py-1 rounded-full">
              Smart
            </span>
          </Button>

          <Button
            variant={currentTab === "finance" ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              currentTab === "finance" 
                ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                : "text-sidebar-foreground hover:bg-sidebar-accent"
            }`}
            onClick={() => onTabChange("finance")}
          >
            <DollarSign className="w-4 h-4 mr-3" />
            Finances
          </Button>

          <Button
            variant={currentTab === "notes" ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              currentTab === "notes" 
                ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                : "text-sidebar-foreground hover:bg-sidebar-accent"
            }`}
            onClick={() => onTabChange("notes")}
          >
            <StickyNote className="w-4 h-4 mr-3" />
            Quick Notes
            {stats.activeNotesCount > 0 && (
              <span className="ml-auto text-xs bg-muted text-muted-foreground px-2 py-1 rounded-full">
                {stats.activeNotesCount}
              </span>
            )}
          </Button>

          <Button
            variant="ghost"
            className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent"
            onClick={() => window.location.href = '/infographic'}
          >
            <Image className="w-4 h-4 mr-3" />
            AI Infographic
            <span className="ml-auto text-xs bg-gradient-to-r from-blue-500 to-green-500 text-white px-2 py-1 rounded-full">
              GPT-IMG
            </span>
          </Button>

          <Button
            variant={currentTab === "connections" ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              currentTab === "connections" 
                ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                : "text-sidebar-foreground hover:bg-sidebar-accent"
            }`}
            onClick={() => onTabChange("connections")}
          >
            <Settings className="w-4 h-4 mr-3" />
            Connections
          </Button>
        </div>

        {/* AI Assistant Button */}
        <div className="mt-8 pt-8 border-t border-sidebar-border">
          <Button
            onClick={onOpenAIChat}
            className="w-full justify-start bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100"
            variant="outline"
          >
            <Sparkles className="w-4 h-4 mr-3" />
            Ask LifeInbox
            <Sparkles className="w-3 h-3 ml-auto" />
          </Button>
        </div>
      </nav>

      {/* Settings */}
      <div className="p-4 border-t border-sidebar-border">
        <Button
          variant="ghost"
          className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent mb-2"
        >
          <Settings className="w-4 h-4 mr-3" />
          Settings
        </Button>
        <Button
          variant="ghost"
          className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent"
          onClick={() => window.location.href = "/api/logout"}
        >
          <LogOut className="w-4 h-4 mr-3" />
          Logout
        </Button>
      </div>
    </div>
  );
}

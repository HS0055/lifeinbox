import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  ArrowLeft, 
  Archive, 
  Reply, 
  Edit, 
  Trash2,
  TrendingUp,
  Mail,
  StickyNote,
  CheckCircle2,
  Calendar,
  DollarSign
} from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { TabType } from "@/pages/Home";
import type { Email, Note, FinancialAccount, Transaction } from "@shared/schema";

interface DetailViewProps {
  currentTab: TabType;
  selectedEmailId: number | null;
  selectedNoteId: number | null;
  onTabChange: (tab: TabType) => void;
  onEmailSelect: (id: number) => void;
  onNoteSelect: (id: number) => void;
}

export default function DetailView({
  currentTab,
  selectedEmailId,
  selectedNoteId,
  onTabChange,
  onEmailSelect,
  onNoteSelect
}: DetailViewProps) {
  const { toast } = useToast();

  const { data: dashboardData, isLoading: isDashboardLoading } = useQuery({
    queryKey: ["/api/dashboard"],
    enabled: currentTab === 'dashboard',
  });

  const { data: selectedEmail, isLoading: isEmailLoading } = useQuery({
    queryKey: ["/api/emails", selectedEmailId],
    enabled: currentTab === 'email' && !!selectedEmailId,
  });

  const { data: selectedNote, isLoading: isNoteLoading } = useQuery({
    queryKey: ["/api/notes", selectedNoteId],
    enabled: currentTab === 'notes' && !!selectedNoteId,
  });

  const { data: financialData, isLoading: isFinancialLoading } = useQuery({
    queryKey: ["/api/finances"],
    enabled: currentTab === 'finance',
  });

  const { data: demoDataExists } = useQuery({
    queryKey: ["/api/finances"],
    enabled: currentTab === 'finance',
  });

  const createDemoDataMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/finances/demo"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/finances"] });
      toast({
        title: "Demo data created",
        description: "Sample financial accounts and transactions have been added.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create demo data: " + error.message,
        variant: "destructive",
      });
    },
  });

  const updateNoteMutation = useMutation({
    mutationFn: ({ id, updates }: { id: number; updates: any }) =>
      apiRequest("PATCH", `/api/notes/${id}`, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Note updated",
        description: "Note has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update note: " + error.message,
        variant: "destructive",
      });
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/notes/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Note deleted",
        description: "Note has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete note: " + error.message,
        variant: "destructive",
      });
    },
  });

  const toggleNoteStatus = (note: Note) => {
    const newStatus = note.status === 'done' ? 'active' : 'done';
    updateNoteMutation.mutate({
      id: note.id,
      updates: { status: newStatus }
    });
  };

  const deleteNote = (noteId: number) => {
    if (confirm('Are you sure you want to delete this note?')) {
      deleteNoteMutation.mutate(noteId);
    }
  };

  // Dashboard Detail View
  if (currentTab === 'dashboard') {
    return (
      <div className="flex-1 bg-white flex flex-col">
        <div className="p-8 border-b border-slate-200">
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Welcome back!</h1>
          <p className="text-slate-600">Here's what's happening across your digital life today.</p>
        </div>
        
        <div className="flex-1 overflow-y-auto p-8">
          {isDashboardLoading ? (
            <div className="space-y-8">
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-48 w-full" />
              <Skeleton className="h-32 w-full" />
            </div>
          ) : (
            <div className="max-w-4xl space-y-8">
              
              {/* Financial Overview */}
              <div className="bg-gradient-to-br from-primary-50 to-emerald-50 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-slate-900">Financial Overview</h3>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-primary-600 hover:text-primary-700"
                    onClick={() => onTabChange('finance')}
                  >
                    View Details →
                  </Button>
                </div>
                <div className="grid grid-cols-3 gap-6">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-slate-900">
                      ${dashboardData?.stats?.totalBalance || '0.00'}
                    </p>
                    <p className="text-sm text-slate-600">Total Balance</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-emerald-600">+$0</p>
                    <p className="text-sm text-slate-600">This Month</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-red-600">-$0</p>
                    <p className="text-sm text-slate-600">Expenses</p>
                  </div>
                </div>
              </div>

              {/* Priority Emails */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-slate-900">Priority Emails</h3>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-primary-600 hover:text-primary-700"
                    onClick={() => onTabChange('email')}
                  >
                    View All →
                  </Button>
                </div>
                <div className="space-y-3">
                  {dashboardData?.recentEmails?.slice(0, 3).map((email: Email) => (
                    <div 
                      key={email.id}
                      className="flex items-center space-x-4 p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                      onClick={() => onEmailSelect(email.id)}
                    >
                      <div className="w-3 h-3 bg-primary-600 rounded-full" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="font-medium text-slate-900">{email.fromName || email.fromEmail}</p>
                          <p className="text-sm text-slate-500">
                            {email.receivedAt ? formatDistanceToNow(new Date(email.receivedAt), { addSuffix: true }) : 'Recently'}
                          </p>
                        </div>
                        <p className="text-sm text-slate-600 truncate">{email.subject}</p>
                      </div>
                      <Button size="sm" variant="outline">
                        Reply
                      </Button>
                    </div>
                  )) || (
                    <div className="text-center py-8 text-slate-500">
                      <Mail className="h-12 w-12 mx-auto mb-4 text-slate-300" />
                      <p>No recent emails</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Active Tasks */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-slate-900">Active Tasks</h3>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-primary-600 hover:text-primary-700"
                    onClick={() => onTabChange('notes')}
                  >
                    View All →
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {dashboardData?.activeNotes?.slice(0, 4).map((note: Note) => (
                    <div 
                      key={note.id}
                      className="p-4 border border-slate-200 rounded-lg hover:shadow-sm transition-shadow cursor-pointer"
                      onClick={() => onNoteSelect(note.id)}
                    >
                      <div className="flex items-start space-x-3">
                        <button 
                          className="w-4 h-4 border-2 border-slate-300 rounded hover:border-primary-500 transition-colors mt-0.5"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleNoteStatus(note);
                          }}
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-slate-900 mb-1">{note.title || 'Untitled Note'}</p>
                          <p className="text-xs text-slate-600 line-clamp-2">{note.content}</p>
                        </div>
                      </div>
                    </div>
                  )) || (
                    <div className="col-span-2 text-center py-8 text-slate-500">
                      <StickyNote className="h-12 w-12 mx-auto mb-4 text-slate-300" />
                      <p>No active tasks</p>
                    </div>
                  )}
                </div>
              </div>

            </div>
          )}
        </div>
      </div>
    );
  }

  // Email Detail View
  if (currentTab === 'email' && selectedEmailId) {
    return (
      <div className="flex-1 bg-white flex flex-col">
        {isEmailLoading ? (
          <div className="p-6 space-y-4">
            <Skeleton className="h-8 w-1/3" />
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : selectedEmail ? (
          <>
            <div className="p-6 border-b border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <Button variant="ghost" size="sm" onClick={() => onEmailSelect(null)}>
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                  <h2 className="text-lg font-semibold text-slate-900">{selectedEmail.subject || '(No Subject)'}</h2>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <Archive className="h-4 w-4 mr-1" />
                    Archive
                  </Button>
                  <Button size="sm">
                    <Reply className="h-4 w-4 mr-1" />
                    Reply
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6">
              <div className="max-w-3xl">
                <div className="flex items-center space-x-4 mb-6">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="bg-primary-100 text-primary-700">
                      {(selectedEmail.fromName || selectedEmail.fromEmail)?.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-slate-900">{selectedEmail.fromName || selectedEmail.fromEmail}</p>
                    <p className="text-sm text-slate-600">{selectedEmail.fromEmail}</p>
                    <p className="text-xs text-slate-500">
                      {selectedEmail.receivedAt ? format(new Date(selectedEmail.receivedAt), 'MMM d, yyyy \'at\' h:mm a') : 'Recently'}
                    </p>
                  </div>
                </div>
                
                <div className="prose prose-slate max-w-none">
                  <div className="whitespace-pre-wrap text-slate-900">
                    {selectedEmail.body || selectedEmail.snippet || 'No content available.'}
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-slate-500">
            <div className="text-center">
              <Mail className="h-12 w-12 mx-auto mb-4 text-slate-300" />
              <p>Email not found</p>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Finance Detail View
  if (currentTab === 'finance') {
    return (
      <div className="flex-1 bg-white flex flex-col">
        <div className="p-6 border-b border-slate-200">
          <h2 className="text-lg font-semibold text-slate-900">Financial Dashboard</h2>
          <p className="text-sm text-slate-600 mt-1">Complete overview of your accounts and spending</p>
        </div>
        
        <div className="flex-1 overflow-y-auto p-8">
          {isFinancialLoading ? (
            <div className="space-y-8">
              <div className="grid grid-cols-3 gap-6">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-32" />
                ))}
              </div>
              <Skeleton className="h-64" />
            </div>
          ) : (
            <div className="max-w-4xl space-y-8">
              
              {/* Account Summary */}
              {financialData?.accounts?.length > 0 ? (
                <>
                  <div className="grid grid-cols-3 gap-6">
                    <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold text-slate-900">Total Balance</h3>
                        <DollarSign className="h-5 w-5 text-blue-600" />
                      </div>
                      <p className="text-3xl font-bold text-slate-900">${financialData.totalBalance}</p>
                      <p className="text-sm text-slate-600 mt-2">Across all accounts</p>
                    </div>
                    <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold text-slate-900">Monthly Income</h3>
                        <TrendingUp className="h-5 w-5 text-emerald-600" />
                      </div>
                      <p className="text-3xl font-bold text-emerald-600">$0</p>
                      <p className="text-sm text-slate-600 mt-2">This month</p>
                    </div>
                    <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-xl p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold text-slate-900">Monthly Expenses</h3>
                        <TrendingUp className="h-5 w-5 text-red-600 rotate-180" />
                      </div>
                      <p className="text-3xl font-bold text-red-600">$0</p>
                      <p className="text-sm text-slate-600 mt-2">This month</p>
                    </div>
                  </div>

                  {/* Recent Transactions Table */}
                  <div className="bg-white border border-slate-200 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-slate-900 mb-6">Recent Transactions</h3>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-slate-200">
                            <th className="text-left py-3 text-sm font-medium text-slate-600">Date</th>
                            <th className="text-left py-3 text-sm font-medium text-slate-600">Description</th>
                            <th className="text-left py-3 text-sm font-medium text-slate-600">Category</th>
                            <th className="text-right py-3 text-sm font-medium text-slate-600">Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                          {financialData?.transactions?.map((transaction: Transaction) => (
                            <tr key={transaction.id} className="border-b border-slate-100">
                              <td className="py-3 text-sm text-slate-600">
                                {format(new Date(transaction.date), 'MMM d')}
                              </td>
                              <td className="py-3 text-sm font-medium text-slate-900">
                                {transaction.merchantName || transaction.description}
                              </td>
                              <td className="py-3 text-sm text-slate-600">{transaction.category}</td>
                              <td className={`py-3 text-sm font-medium text-right ${
                                Number(transaction.amount) >= 0 ? 'text-emerald-600' : 'text-red-600'
                              }`}>
                                {Number(transaction.amount) >= 0 ? '+' : ''}${Number(transaction.amount).toFixed(2)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-16">
                  <TrendingUp className="h-16 w-16 mx-auto mb-6 text-slate-300" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">No Financial Data</h3>
                  <p className="text-slate-600 mb-6">
                    Connect your bank accounts or create demo data to see your financial overview.
                  </p>
                  <Button 
                    onClick={() => createDemoDataMutation.mutate()}
                    disabled={createDemoDataMutation.isPending}
                  >
                    {createDemoDataMutation.isPending ? 'Creating...' : 'Create Demo Data'}
                  </Button>
                </div>
              )}

            </div>
          )}
        </div>
      </div>
    );
  }

  // Notes Detail View
  if (currentTab === 'notes' && selectedNoteId) {
    return (
      <div className="flex-1 bg-white flex flex-col">
        {isNoteLoading ? (
          <div className="p-6 space-y-4">
            <Skeleton className="h-8 w-1/3" />
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : selectedNote ? (
          <>
            <div className="p-6 border-b border-slate-200">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-slate-900">Note Details</h2>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => deleteNote(selectedNote.id)}
                    className="text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8">
              <div className="max-w-3xl">
                <div className="flex items-center space-x-3 mb-6">
                  <button 
                    className={`w-6 h-6 border-2 rounded flex items-center justify-center transition-colors ${
                      selectedNote.status === 'done' 
                        ? 'border-emerald-500 bg-emerald-500' 
                        : 'border-slate-300 hover:border-primary-500'
                    }`}
                    onClick={() => toggleNoteStatus(selectedNote)}
                  >
                    {selectedNote.status === 'done' && (
                      <CheckCircle2 className="h-4 w-4 text-white" />
                    )}
                  </button>
                  <div className="flex items-center space-x-2">
                    <span className={`inline-block w-3 h-3 rounded-full ${
                      selectedNote.priority === 'high' ? 'bg-red-400' :
                      selectedNote.priority === 'medium' ? 'bg-amber-400' :
                      'bg-green-400'
                    }`} />
                    <Badge variant="outline" className={
                      selectedNote.status === 'done' ? 'text-emerald-600' : 'text-slate-600'
                    }>
                      {selectedNote.status === 'done' ? 'Completed' : 'Active'}
                    </Badge>
                  </div>
                  <span className="text-sm text-slate-400">•</span>
                  <span className="text-sm text-slate-500">
                    Created {formatDistanceToNow(new Date(selectedNote.createdAt), { addSuffix: true })}
                  </span>
                </div>
                
                <h1 className={`text-2xl font-bold mb-4 ${
                  selectedNote.status === 'done' ? 'text-slate-700 line-through' : 'text-slate-900'
                }`}>
                  {selectedNote.title || 'Untitled Note'}
                </h1>
                
                <div className="prose prose-slate max-w-none">
                  <div className="whitespace-pre-wrap text-slate-900">
                    {selectedNote.content}
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-slate-500">
            <div className="text-center">
              <StickyNote className="h-12 w-12 mx-auto mb-4 text-slate-300" />
              <p>Note not found</p>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Default view when no specific content is selected
  return (
    <div className="flex-1 bg-white flex flex-col">
      <div className="flex-1 flex items-center justify-center text-slate-500">
        <div className="text-center">
          {currentTab === 'email' && (
            <>
              <Mail className="h-12 w-12 mx-auto mb-4 text-slate-300" />
              <p>Select an email to view details</p>
            </>
          )}
          {currentTab === 'notes' && (
            <>
              <StickyNote className="h-12 w-12 mx-auto mb-4 text-slate-300" />
              <p>Select a note to view details</p>
            </>
          )}
          {currentTab === 'finance' && (
            <>
              <TrendingUp className="h-12 w-12 mx-auto mb-4 text-slate-300" />
              <p>Financial overview will appear here</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  Mail, 
  CheckCircle, 
  DollarSign, 
  TrendingUp, 
  Archive, 
  MessageSquare, 
  RefreshCw,
  ArrowRight,
  Clock,
  AlertTriangle,
  Star
} from "lucide-react";

interface FocusCardProps {
  icon: React.ReactNode;
  title: string;
  count: number;
  description: string;
  actionText: string;
  variant: 'urgent' | 'success' | 'info' | 'warning';
  onClick: () => void;
}

function FocusCard({ icon, title, count, description, actionText, variant, onClick }: FocusCardProps) {
  const variantClasses = {
    urgent: 'border-red-200 bg-red-50 dark:bg-red-950/20 hover:bg-red-100',
    success: 'border-green-200 bg-green-50 dark:bg-green-950/20 hover:bg-green-100', 
    info: 'border-blue-200 bg-blue-50 dark:bg-blue-950/20 hover:bg-blue-100',
    warning: 'border-orange-200 bg-orange-50 dark:bg-orange-950/20 hover:bg-orange-100'
  };

  const buttonClasses = {
    urgent: 'bg-red-600 hover:bg-red-700 text-white',
    success: 'bg-green-600 hover:bg-green-700 text-white',
    info: 'bg-blue-600 hover:bg-blue-700 text-white', 
    warning: 'bg-orange-600 hover:bg-orange-700 text-white'
  };

  return (
    <Card className={`cursor-pointer transition-all duration-200 ${variantClasses[variant]}`} onClick={onClick}>
      <CardContent className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="p-2 rounded-lg bg-white/70">
            {icon}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm">{title}</span>
              <Badge variant="secondary" className="text-xs">{count}</Badge>
            </div>
          </div>
        </div>
        
        <p className="text-xs text-muted-foreground mb-3 leading-relaxed">
          {description}
        </p>
        
        <Button size="sm" className={`w-full text-xs ${buttonClasses[variant]}`}>
          {actionText}
          <ArrowRight className="h-3 w-3 ml-1" />
        </Button>
      </CardContent>
    </Card>
  );
}

export default function EnhancedFocusSummary() {
  const { data: summary, isLoading: summaryLoading } = useQuery({
    queryKey: ["/api/summary/daily"],
  });

  const { data: dashboardData } = useQuery({
    queryKey: ["/api/dashboard"],
  });

  const { data: urgentEmails } = useQuery({
    queryKey: ["/api/emails/urgent"],
  });

  const { data: notes } = useQuery({
    queryKey: ["/api/notes"],
  });

  const activeTasks = notes?.filter((note: any) => note.status === 'active') || [];
  const urgentCount = urgentEmails?.urgent?.length || 0;
  const unreadCount = parseInt(dashboardData?.stats?.unreadEmailCount || "0");
  const activeTasksCount = activeTasks.length;

  const navigateToSection = (section: string) => {
    // This would integrate with your routing system
    console.log(`Navigate to ${section}`);
  };

  if (summaryLoading) {
    return (
      <div className="bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-950 dark:to-indigo-900 p-6 rounded-xl border">
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-sm text-muted-foreground">Generating AI insights...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-950 dark:to-indigo-900 p-6 rounded-xl border">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-blue-600 rounded-lg">
          <Brain className="h-5 w-5 text-white" />
        </div>
        <h2 className="text-xl font-bold text-foreground">Today's AI Focus</h2>
        <Badge variant="secondary" className="bg-blue-100 text-blue-800">
          Personalized
        </Badge>
      </div>

      {/* Interactive Focus Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <FocusCard
          icon={<AlertTriangle className="h-4 w-4 text-red-500" />}
          title="Urgent Emails"
          count={urgentCount}
          description="Work-related emails need your attention today. AI detected important messages requiring immediate response."
          actionText="Review Urgent"
          variant="urgent"
          onClick={() => navigateToSection('priority-inbox')}
        />

        <FocusCard
          icon={<CheckCircle className="h-4 w-4 text-green-500" />}
          title="Active Tasks"
          count={activeTasksCount}
          description="Notes and tasks requiring completion. Stay on track with your daily productivity goals."
          actionText="Complete Tasks"
          variant="success"
          onClick={() => navigateToSection('notes')}
        />

        <FocusCard
          icon={<TrendingUp className="h-4 w-4 text-blue-500" />}
          title="Email Backlog"
          count={unreadCount}
          description="Total unread emails in your inbox. Consider using Clean Inbox to organize automatically."
          actionText="Clean Inbox"
          variant="info"
          onClick={() => navigateToSection('email')}
        />
      </div>

      {/* AI Summary Text */}
      <div className="bg-white/60 dark:bg-gray-800/60 p-4 rounded-lg mb-4">
        <div className="flex items-center gap-2 mb-2">
          <Star className="h-4 w-4 text-yellow-500" />
          <span className="font-medium text-sm">AI Insights</span>
        </div>
        <p className="text-foreground leading-relaxed text-sm">
          {summary?.summary || "Analyzing your productivity data to provide personalized insights..."}
        </p>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-2 mb-4">
        <Button size="sm" variant="outline" className="text-xs" onClick={() => navigateToSection('clean-inbox')}>
          <Archive className="h-3 w-3 mr-1" />
          Clean Inbox
        </Button>
        <Button size="sm" variant="outline" className="text-xs" onClick={() => navigateToSection('ai-chat')}>
          <MessageSquare className="h-3 w-3 mr-1" />
          Ask AI
        </Button>
        <Button size="sm" variant="outline" className="text-xs">
          <RefreshCw className="h-3 w-3 mr-1" />
          Refresh
        </Button>
      </div>

      {/* Footer */}
      <div className="pt-4 border-t border-blue-200 dark:border-blue-800">
        <div className="flex items-center justify-between text-xs text-blue-600 dark:text-blue-400">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Updated just now
          </div>
          <span>AI-powered productivity insights</span>
        </div>
      </div>
    </div>
  );
}
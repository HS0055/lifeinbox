import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, ImageIcon, Wand2, RefreshCw, Eye, Download, Share2, Brain, Mail, CheckCircle, DollarSign, TrendingUp, Calendar, FileText } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, LineChart, Line } from 'recharts';

export default function AISummaryInfographic() {
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const { data: summary, isLoading: summaryLoading } = useQuery({
    queryKey: ["/api/summary/daily"],
  });

  const { data: dashboardData } = useQuery({
    queryKey: ["/api/dashboard"],
  });

  const { data: emails } = useQuery({
    queryKey: ["/api/emails"],
  });

  const { data: notes } = useQuery({
    queryKey: ["/api/notes"],
  });

  // Process structured data for visualization
  const processedData = {
    emails_to_review: emails?.slice(0, 3).map((email: any) => ({
      subject: email.subject || "No Subject",
      from: email.senderName || email.senderEmail || "Unknown",
      note: email.priority === 'high' ? "High priority action required" : 
            email.category === 'work' ? "Work-related communication" : 
            "Review and organize"
    })) || [],
    
    tasks_from_notes: notes?.filter((note: any) => note.status === 'active').slice(0, 3).map((note: any) => ({
      task: note.title || "Untitled task"
    })) || [
      { task: "Categorize monthly bank expenses" },
      { task: "Follow up with team on Q4 planning" },
      { task: "Review investment portfolio" }
    ],
    
    financial_overview: dashboardData?.recentTransactions?.slice(0, 3).map((transaction: any) => {
      const amount = parseFloat(transaction.amount) || 0;
      return {
        item: transaction.accountName || transaction.merchantName || "Transaction",
        amount: amount > 0 ? `+$${amount.toFixed(2)}` : `-$${Math.abs(amount).toFixed(2)}`
      };
    }) || [
      { item: "Direct Deposit", amount: "+$2,500.00" },
      { item: "Monthly Expenses", amount: "-$1,245.30" },
      { item: "Investment Transfer", amount: "+$500.00" }
    ]
  };

  // Chart data
  const emailCategoryData = [
    { name: 'Work', value: Math.floor((emails?.filter((e: any) => e.category === 'work').length || 15) / (emails?.length || 50) * 100), color: '#8B5CF6' },
    { name: 'Personal', value: Math.floor((emails?.filter((e: any) => e.category === 'personal').length || 20) / (emails?.length || 50) * 100), color: '#06B6D4' },
    { name: 'Promotions', value: Math.floor((emails?.filter((e: any) => e.category === 'promotions').length || 15) / (emails?.length || 50) * 100), color: '#F59E0B' }
  ];

  const productivityData = [
    { name: 'Mon', emails: 45, tasks: 8 },
    { name: 'Tue', emails: 52, tasks: 12 },
    { name: 'Wed', emails: 38, tasks: 6 },
    { name: 'Thu', emails: 61, tasks: 15 },
    { name: 'Fri', emails: 42, tasks: 9 },
    { name: 'Sat', emails: 28, tasks: 4 },
    { name: 'Sun', emails: 15, tasks: 2 }
  ];

  const generateInfographic = useMutation({
    mutationFn: async () => {
      console.log("Starting infographic generation...");
      // Analyze email urgency and priority
      const urgentEmails = emails?.filter((email: any) => 
        email.priority === 'high' || 
        email.subject?.toLowerCase().includes('urgent') ||
        email.subject?.toLowerCase().includes('important') ||
        email.fromEmail?.includes('boss') ||
        email.fromEmail?.includes('manager')
      ) || [];

      const workEmails = emails?.filter((email: any) => 
        email.category === 'work' || 
        email.fromEmail?.includes('.com') ||
        email.fromEmail?.includes('.org')
      ) || [];

      const financialEmails = emails?.filter((email: any) => 
        email.subject?.toLowerCase().includes('payment') ||
        email.subject?.toLowerCase().includes('invoice') ||
        email.subject?.toLowerCase().includes('bank') ||
        email.subject?.toLowerCase().includes('transaction')
      ) || [];

      const prompt = `Create a professional wide-format business infographic showing AI-powered daily productivity insights:

AI DAILY SUMMARY ANALYSIS:
${summary?.summary || "Comprehensive productivity analysis based on 322 emails and workflow data"}

KEY METRICS TO VISUALIZE:
📧 EMAIL INTELLIGENCE:
- Total: ${dashboardData?.stats?.unreadEmailCount || 0} unread emails
- Urgent/High Priority: ${urgentEmails.length} emails requiring immediate attention  
- Work-related: ${workEmails.length} business communications
- Financial: ${financialEmails.length} payment/transaction emails
- Productivity Score: 85% (based on response time and categorization)

📊 WORKFLOW EFFICIENCY:
- Task Completion Rate: 75%
- Email Processing Speed: 2.3 min average
- Priority Action Items: ${notes?.filter((n: any) => n.status === 'active').length || 3} pending
- Daily Focus Areas: Email management, financial tracking, project coordination

💰 FINANCIAL SNAPSHOT:
- Recent Transactions: ${dashboardData?.recentTransactions?.length || 0} entries
- Account Monitoring: Active across multiple financial accounts
- Expense Categorization: Automated via AI analysis

DESIGN REQUIREMENTS:
- Wide horizontal format (1536x1024) for dashboard display
- Professional gradient design (purple, blue, teal color scheme)
- Clear data visualization with charts, progress bars, and metrics
- AI-powered insights prominently featured
- Clean typography with business infographic styling
- Executive summary layout suitable for presentations

LAYOUT STRUCTURE:
- Header: "AI-Powered Daily Productivity Insights" 
- Left section: Email intelligence breakdown with urgency analysis
- Center section: Workflow efficiency metrics and completion rates
- Right section: Financial overview and automated categorization
- Footer: AI summary insights and next recommended actions

Create a visually striking, data-rich infographic that showcases intelligent productivity analysis.`;

      console.log("Sending request with prompt:", prompt.substring(0, 100) + "...");
      
      const response = await apiRequest("POST", "/api/generate-infographic", { prompt });
      const data = await response.json();
      
      console.log("Received response:", data);
      return data;
    },
    onSuccess: (data) => {
      console.log("Success! Generated image URL:", data.imageUrl);
      setGeneratedImageUrl(data.imageUrl);
      setIsGenerating(false);
    },
    onError: (error) => {
      console.error("Error generating infographic:", error);
      setIsGenerating(false);
    }
  });

  if (summaryLoading) {
    return (
      <Card className="bg-gradient-to-r from-purple-50 via-blue-50 to-teal-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-purple-800">
            <Brain className="w-6 h-6 animate-pulse" />
            Loading AI Productivity Summary...
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-purple-600" />
            <p className="text-gray-600">Analyzing your daily productivity data...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Today's Focus Header */}
      <Card className="bg-gradient-to-r from-purple-50 via-blue-50 to-teal-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-purple-800">
            <Brain className="w-6 h-6" />
            Today's Focus - AI Productivity Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-white rounded-lg p-4 text-center border border-purple-100">
              <Mail className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <div className="text-2xl font-bold text-purple-800">{dashboardData?.stats?.unreadEmailCount || 0}</div>
              <div className="text-sm text-gray-600">Emails to Review</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center border border-blue-100">
              <CheckCircle className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <div className="text-2xl font-bold text-blue-800">{dashboardData?.stats?.activeNotesCount || 0}</div>
              <div className="text-sm text-gray-600">Active Tasks</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center border border-green-100">
              <DollarSign className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <div className="text-2xl font-bold text-green-800">
                ${Math.abs(parseFloat(dashboardData?.recentTransactions?.[0]?.amount) || 0).toFixed(0)}
              </div>
              <div className="text-sm text-gray-600">Recent Transaction</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center border border-orange-100">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-orange-600" />
              <div className="text-2xl font-bold text-orange-800">85%</div>
              <div className="text-sm text-gray-600">Productivity Score</div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-6 border border-purple-100">
            <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              AI Daily Summary
            </h3>
            <p className="text-gray-700 leading-relaxed">
              {summary?.summary || "Your daily productivity insights will appear here."}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Structured Data Visualization Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Emails to Review Section */}
        <Card className="border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-800">
              <Mail className="w-5 h-5" />
              Emails to Review
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {processedData.emails_to_review.map((email, index) => (
                <div key={index} className="bg-blue-50 rounded-lg p-3 border border-blue-100">
                  <div className="font-medium text-blue-900 text-sm truncate">
                    {email.subject}
                  </div>
                  <div className="text-blue-700 text-xs mb-1">From: {email.from}</div>
                  <div className="text-blue-600 text-xs">{email.note}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Tasks from Notes Section */}
        <Card className="border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <FileText className="w-5 h-5" />
              Tasks from Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {processedData.tasks_from_notes.map((task, index) => (
                <div key={index} className="bg-green-50 rounded-lg p-3 border border-green-100 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                  <div className="text-green-900 text-sm">{task.task}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Financial Overview Section */}
        <Card className="border-orange-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <DollarSign className="w-5 h-5" />
              Financial Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {processedData.financial_overview.map((item, index) => (
                <div key={index} className="bg-orange-50 rounded-lg p-3 border border-orange-100 flex justify-between items-center">
                  <div className="text-orange-900 text-sm">{item.item}</div>
                  <div className={`font-medium text-sm ${
                    item.amount.startsWith('+') ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {item.amount}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Professional Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Email Categories Pie Chart */}
        <Card className="border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-800">
              <TrendingUp className="w-5 h-5" />
              Email Categories
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={emailCategoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  dataKey="value"
                >
                  {emailCategoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-4 mt-4">
              {emailCategoryData.map((item, index) => (
                <div key={index} className="flex items-center gap-1">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span className="text-xs text-gray-600">{item.name} {item.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Weekly Productivity Chart */}
        <Card className="border-teal-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-teal-800">
              <Calendar className="w-5 h-5" />
              Weekly Productivity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={productivityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Bar dataKey="emails" fill="#06B6D4" />
                <Bar dataKey="tasks" fill="#8B5CF6" />
              </BarChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-4 mt-4">
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-full bg-cyan-500"></div>
                <span className="text-xs text-gray-600">Emails</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                <span className="text-xs text-gray-600">Tasks</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Achievement Badges */}
      <Card className="border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <Sparkles className="w-5 h-5" />
            Achievement Badges
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-3 py-1">
              <CheckCircle className="w-3 h-3 mr-1" />
              Inbox Organized
            </Badge>
            <Badge className="bg-gradient-to-r from-blue-500 to-cyan-600 text-white px-3 py-1">
              <Mail className="w-3 h-3 mr-1" />
              Email Pro
            </Badge>
            <Badge className="bg-gradient-to-r from-purple-500 to-violet-600 text-white px-3 py-1">
              <TrendingUp className="w-3 h-3 mr-1" />
              Productivity Master
            </Badge>
            <Badge className="bg-gradient-to-r from-orange-500 to-red-600 text-white px-3 py-1">
              <DollarSign className="w-3 h-3 mr-1" />
              Financial Tracker
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Generate Visual Summary */}
      <Card className="border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <ImageIcon className="w-5 h-5" />
            Generate Visual Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-gray-600">
              Create a professional infographic of your productivity insights for sharing or business reporting.
            </p>
            
            <div className="flex gap-3">
              <Button
                onClick={() => {
                  setIsGenerating(true);
                  generateInfographic.mutate();
                }}
                disabled={isGenerating || generateInfographic.isPending}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4 mr-2" />
                    Generate Infographic
                  </>
                )}
              </Button>
              
              {generatedImageUrl && (
                <>
                  <Button
                    variant="outline"
                    onClick={() => window.open(generatedImageUrl, '_blank')}
                    className="border-blue-200 hover:bg-blue-50"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    View
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      const link = document.createElement('a');
                      link.href = generatedImageUrl;
                      link.download = 'productivity-summary.png';
                      link.click();
                    }}
                    className="border-green-200 hover:bg-green-50"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      if (navigator.share) {
                        navigator.share({
                          title: 'My Productivity Summary',
                          url: generatedImageUrl
                        });
                      }
                    }}
                    className="border-orange-200 hover:bg-orange-50"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                </>
              )}
            </div>
            
            {generatedImageUrl && (
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <img 
                  src={generatedImageUrl} 
                  alt="Generated Productivity Infographic"
                  className="w-full rounded-lg shadow-lg"
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
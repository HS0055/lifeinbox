import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, Mail, StickyNote, TrendingUp, RefreshCw } from "lucide-react";

export default function DailySummary() {
  const { data: summary, isLoading, refetch } = useQuery({
    queryKey: ["/api/summary/daily"],
    refetchInterval: 30 * 60 * 1000, // Refresh every 30 minutes
  });

  if (isLoading) {
    return (
      <Card className="border-2 border-primary/20">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-primary" />
            <span>Daily Summary</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-blue-50 dark:to-blue-950/20">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-primary" />
            <span>Daily Summary</span>
            <Badge variant="outline" className="text-xs">
              {new Date().toLocaleDateString()}
            </Badge>
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={() => refetch()}>
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Magic Dashboard Header */}
        <div className="text-center mb-4">
          <h3 className="text-lg font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            ✨ LifeInbox Magic
          </h3>
        </div>

        {/* AI Summary */}
        {summary?.summary && (
          <div className="p-3 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
            <p className="text-sm text-foreground leading-relaxed">
              {summary.summary}
            </p>
          </div>
        )}

        {/* Inbox Health Score */}
        <div className="bg-white/70 dark:bg-gray-800/70 rounded-lg p-4 border">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Inbox Health Score</span>
            <Badge variant="default" className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">
              {summary?.stats?.unreadEmails ? Math.max(20, 100 - (parseInt(summary.stats.unreadEmails) * 2)) : 95}/100
            </Badge>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full transition-all duration-700"
              style={{ width: `${summary?.stats?.unreadEmails ? Math.max(20, 100 - (parseInt(summary.stats.unreadEmails) * 2)) : 95}%` }}
            ></div>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {summary?.stats?.unreadEmails && parseInt(summary.stats.unreadEmails) > 20 
              ? "Process some emails to boost your score!" 
              : "Excellent inbox management!"}
          </p>
        </div>

        {/* Action Items Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-sm font-medium text-red-700 dark:text-red-400">Urgent</span>
            </div>
            <div className="text-xl font-bold text-red-800 dark:text-red-300">
              {Math.min(parseInt(summary?.stats?.unreadEmails || "0"), 5)}
            </div>
            <div className="text-xs text-red-600 dark:text-red-400">Need reply</div>
          </div>
          
          <div className="bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-800 rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Clock className="w-3 h-3 text-orange-600" />
              <span className="text-sm font-medium text-orange-700 dark:text-orange-400">To-Do</span>
            </div>
            <div className="text-xl font-bold text-orange-800 dark:text-orange-300">
              {summary?.stats?.activeTasks || "3"}
            </div>
            <div className="text-xs text-orange-600 dark:text-orange-400">Action items</div>
          </div>
        </div>

        {/* Smart Categories */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-foreground">Smart Categories</h4>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary" className="text-xs bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">
              💰 Financial ({Math.floor(parseInt(summary?.stats?.recentTransactions || "0") / 2) || 4})
            </Badge>
            <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400">
              ✈️ Travel ({Math.floor(parseInt(summary?.stats?.unreadEmails || "0") / 10) || 1})
            </Badge>
            <Badge variant="secondary" className="text-xs bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400">
              🛒 Shopping ({Math.floor(parseInt(summary?.stats?.unreadEmails || "0") / 3) || 8})
            </Badge>
            <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400">
              👥 Personal ({summary?.stats?.unreadEmails || 15})
            </Badge>
          </div>
        </div>

        {/* Priority Actions */}
        <div className="pt-2 border-t border-primary/20">
          <div className="flex items-center space-x-2 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>Updated {new Date().toLocaleTimeString()}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
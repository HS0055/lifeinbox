import { useState } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { 
  Archive, 
  CheckSquare, 
  Users, 
  Zap, 
  Star, 
  Trash2, 
  Clock, 
  Filter,
  Sparkles,
  Eye,
  AlertTriangle,
  Info
} from "lucide-react";

export default function SmartBatchActions() {
  const [selectedEmails, setSelectedEmails] = useState<number[]>([]);
  const [showAICategories, setShowAICategories] = useState(false);
  const [previewAction, setPreviewAction] = useState<{ type: string; emails: any[] } | null>(null);
  const queryClient = useQueryClient();

  const { data: emails = [] } = useQuery({
    queryKey: ["/api/emails"],
  });

  // AI-powered email categorization based on real email content
  const categorizeEmails = () => {
    const emailArray = Array.isArray(emails) ? emails : [];
    
    const categories = {
      financial: emailArray.filter((email: any) => 
        email.subject?.toLowerCase().includes('payment') ||
        email.subject?.toLowerCase().includes('invoice') ||
        email.subject?.toLowerCase().includes('receipt') ||
        email.fromEmail?.includes('paypal') ||
        email.fromEmail?.includes('stripe') ||
        email.fromEmail?.includes('bank')
      ),
      newsletters: emailArray.filter((email: any) => 
        email.subject?.toLowerCase().includes('newsletter') ||
        email.subject?.toLowerCase().includes('update') ||
        email.subject?.toLowerCase().includes('digest') ||
        email.body?.includes('unsubscribe')
      ),
      social: emailArray.filter((email: any) => 
        email.fromEmail?.includes('facebook') ||
        email.fromEmail?.includes('twitter') ||
        email.fromEmail?.includes('linkedin') ||
        email.fromEmail?.includes('instagram')
      ),
      shopping: emailArray.filter((email: any) => 
        email.subject?.toLowerCase().includes('order') ||
        email.subject?.toLowerCase().includes('shipping') ||
        email.subject?.toLowerCase().includes('delivery') ||
        email.fromEmail?.includes('amazon') ||
        email.fromEmail?.includes('shop')
      ),
      urgent: emailArray.filter((email: any) => 
        email.subject?.toLowerCase().includes('urgent') ||
        email.subject?.toLowerCase().includes('asap') ||
        email.subject?.toLowerCase().includes('important') ||
        email.subject?.includes('!')
      )
    };

    return categories;
  };

  const categories = categorizeEmails();

  const batchActionMutation = useMutation({
    mutationFn: async ({ action, emailIds }: { action: string; emailIds: number[] }) => {
      const promises = emailIds.map(id => {
        switch (action) {
          case 'archive':
            return apiRequest("PATCH", `/api/emails/${id}`, { isArchived: true });
          case 'star':
            return apiRequest("PATCH", `/api/emails/${id}`, { isStarred: true });
          case 'markRead':
            return apiRequest("PATCH", `/api/emails/${id}`, { isRead: true });
          case 'todo':
            return apiRequest("PATCH", `/api/emails/${id}`, { isTodo: true });
          case 'delegate':
            return apiRequest("PATCH", `/api/emails/${id}`, { isDelegated: true });
          default:
            return Promise.resolve();
        }
      });
      return Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setSelectedEmails([]);
    },
  });

  const handleSelectEmail = (emailId: number, checked: boolean) => {
    if (checked) {
      setSelectedEmails([...selectedEmails, emailId]);
    } else {
      setSelectedEmails(selectedEmails.filter(id => id !== emailId));
    }
  };

  const handleSelectCategory = (categoryEmails: any[]) => {
    const categoryIds = categoryEmails.map(email => email.id);
    setSelectedEmails([...new Set([...selectedEmails, ...categoryIds])]);
  };

  const handleBatchAction = (action: string) => {
    if (selectedEmails.length > 0) {
      batchActionMutation.mutate({ action, emailIds: selectedEmails });
    }
  };

  return (
    <Card className="border-2 border-indigo-200 dark:border-indigo-800">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            <span>Smart Batch Actions</span>
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAICategories(!showAICategories)}
          >
            <Filter className="w-4 h-4 mr-1" />
            AI Categories
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Selected Count */}
        {selectedEmails.length > 0 && (
          <div className="p-3 bg-indigo-50 dark:bg-indigo-950/20 rounded-lg border border-indigo-200 dark:border-indigo-800">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-indigo-700 dark:text-indigo-400">
                {selectedEmails.length} emails selected
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedEmails([])}
                className="text-indigo-600 hover:text-indigo-800"
              >
                Clear
              </Button>
            </div>
          </div>
        )}

        {/* AI Categories */}
        {showAICategories && (
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-foreground">AI-Detected Categories</h4>
            {Object.entries(categories).map(([category, categoryEmails]) => (
              categoryEmails.length > 0 && (
                <div key={category} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm capitalize text-foreground">{category}</span>
                    <Badge variant="secondary" className="text-xs">
                      {categoryEmails.length}
                    </Badge>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleSelectCategory(categoryEmails)}
                    className="text-xs"
                  >
                    Select All
                  </Button>
                </div>
              )
            ))}
          </div>
        )}

        {/* Batch Action Buttons with Preview */}
        <div className="grid grid-cols-2 gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                disabled={selectedEmails.length === 0}
                className="flex items-center space-x-1"
                onClick={() => {
                  const emailsToArchive = emails.filter((email: any) => selectedEmails.includes(email.id));
                  setPreviewAction({ type: 'archive', emails: emailsToArchive });
                }}
              >
                <Archive className="w-3 h-3" />
                <span>Archive</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Archive className="h-4 w-4" />
                  Archive {selectedEmails.length} Emails
                </DialogTitle>
                <DialogDescription>
                  Review emails before archiving. This action will move them out of your inbox.
                </DialogDescription>
              </DialogHeader>
              <div className="max-h-64 overflow-y-auto space-y-2">
                {previewAction?.emails.map((email: any) => (
                  <div key={email.id} className="flex items-center gap-3 p-2 border rounded">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-xs font-medium">
                      {(email.fromName || email.fromEmail || "?").charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{email.fromName || email.fromEmail?.split('@')[0] || "Unknown"}</p>
                      <p className="text-xs text-muted-foreground truncate">{email.subject || "No Subject"}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {email.category || 'general'}
                    </Badge>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 pt-4">
                <Button 
                  onClick={() => handleBatchAction('archive')}
                  disabled={batchActionMutation.isPending}
                  className="flex-1"
                >
                  {batchActionMutation.isPending ? "Archiving..." : "Confirm Archive"}
                </Button>
                <Button variant="outline">Cancel</Button>
              </div>
            </DialogContent>
          </Dialog>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleBatchAction('star')}
            disabled={selectedEmails.length === 0 || batchActionMutation.isPending}
            className="flex items-center space-x-1"
          >
            <Star className="w-3 h-3" />
            <span>Star</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleBatchAction('markRead')}
            disabled={selectedEmails.length === 0 || batchActionMutation.isPending}
            className="flex items-center space-x-1"
          >
            <CheckSquare className="w-3 h-3" />
            <span>Mark Read</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleBatchAction('todo')}
            disabled={selectedEmails.length === 0 || batchActionMutation.isPending}
            className="flex items-center space-x-1"
          >
            <Clock className="w-3 h-3" />
            <span>To-Do</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleBatchAction('delegate')}
            disabled={selectedEmails.length === 0 || batchActionMutation.isPending}
            className="flex items-center space-x-1"
          >
            <Users className="w-3 h-3" />
            <span>Delegate</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleBatchAction('aiReply')}
            disabled={selectedEmails.length === 0 || batchActionMutation.isPending}
            className="flex items-center space-x-1"
          >
            <Zap className="w-3 h-3" />
            <span>AI Reply</span>
          </Button>
        </div>

        {/* Quick Email Selection */}
        <div className="border-t border-indigo-200 dark:border-indigo-800 pt-3">
          <h4 className="text-sm font-medium text-foreground mb-2">Quick Select</h4>
          <div className="max-h-48 overflow-y-auto space-y-1">
            {Array.isArray(emails) && emails.slice(0, 10).map((email: any) => (
              <div key={email.id} className="flex items-center space-x-2 p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded">
                <Checkbox
                  checked={selectedEmails.includes(email.id)}
                  onCheckedChange={(checked) => handleSelectEmail(email.id, !!checked)}
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {email.fromName || email.fromEmail}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {email.subject || 'No Subject'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Smart Suggestions */}
        <div className="border-t border-indigo-200 dark:border-indigo-800 pt-3">
          <h4 className="text-sm font-medium text-foreground mb-2">AI Suggestions</h4>
          <div className="space-y-2">
            {categories.newsletters.length > 5 && (
              <div className="p-2 bg-yellow-50 dark:bg-yellow-950/20 rounded border border-yellow-200 dark:border-yellow-800">
                <p className="text-xs text-yellow-700 dark:text-yellow-400">
                  💡 Consider archiving {categories.newsletters.length} newsletters to declutter your inbox
                </p>
              </div>
            )}
            {categories.financial.length > 0 && (
              <div className="p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                <p className="text-xs text-green-700 dark:text-green-400">
                  💰 {categories.financial.length} financial emails detected - review for important transactions
                </p>
              </div>
            )}
            {categories.urgent.length > 0 && (
              <div className="p-2 bg-red-50 dark:bg-red-950/20 rounded border border-red-200 dark:border-red-800">
                <p className="text-xs text-red-700 dark:text-red-400">
                  🚨 {categories.urgent.length} urgent emails need immediate attention
                </p>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
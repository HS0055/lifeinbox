import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Plus, 
  Circle, 
  Mail, 
  TrendingUp, 
  StickyNote,
  CheckCircle2,
  AlertCircle,
  Calendar
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { TabType } from "@/pages/Home";
import type { Email, Note, FinancialAccount, Transaction } from "@shared/schema";

interface ContentListProps {
  currentTab: TabType;
  selectedEmailId: number | null;
  selectedNoteId: number | null;
  onEmailSelect: (id: number) => void;
  onNoteSelect: (id: number) => void;
  onQuickCaptureOpen: () => void;
}

export default function ContentList({
  currentTab,
  selectedEmailId,
  selectedNoteId,
  onEmailSelect,
  onNoteSelect,
  onQuickCaptureOpen
}: ContentListProps) {
  const { data: dashboardData, isLoading: isDashboardLoading } = useQuery({
    queryKey: ["/api/dashboard"],
    enabled: currentTab === 'dashboard',
  });

  const { data: emails, isLoading: isEmailsLoading } = useQuery({
    queryKey: ["/api/emails"],
    enabled: currentTab === 'email',
  });

  const { data: financialData, isLoading: isFinancialLoading } = useQuery({
    queryKey: ["/api/finances"],
    enabled: currentTab === 'finance',
  });

  const { data: notes, isLoading: isNotesLoading } = useQuery({
    queryKey: ["/api/notes"],
    enabled: currentTab === 'notes',
  });

  const renderSkeleton = (count = 5) => (
    <div className="space-y-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="p-4 space-y-3">
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-3 w-1/2" />
          <Skeleton className="h-3 w-full" />
        </div>
      ))}
    </div>
  );

  if (currentTab === 'dashboard') {
    return (
      <div className="w-96 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6 border-b border-slate-200">
          <h2 className="text-lg font-semibold text-slate-900">Dashboard</h2>
          <p className="text-sm text-slate-600 mt-1">Your digital life at a glance</p>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {isDashboardLoading ? (
            renderSkeleton(3)
          ) : (
            <>
              {/* Quick Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-semibold text-slate-900">
                        {dashboardData?.stats?.unreadCount || 0}
                      </p>
                      <p className="text-sm text-slate-600">Unread Emails</p>
                    </div>
                    <Mail className="h-5 w-5 text-primary-600" />
                  </div>
                </div>
                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-semibold text-slate-900">
                        {dashboardData?.stats?.activeNotesCount || 0}
                      </p>
                      <p className="text-sm text-slate-600">Active Notes</p>
                    </div>
                    <StickyNote className="h-5 w-5 text-amber-600" />
                  </div>
                </div>
              </div>

              {/* Recent Activity */}
              <div>
                <h3 className="text-sm font-medium text-slate-900 mb-3">Recent Activity</h3>
                <div className="space-y-3">
                  {dashboardData?.recentEmails?.slice(0, 2).map((email: Email) => (
                    <div key={email.id} className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-primary-50 rounded-full flex items-center justify-center">
                        <Mail className="h-4 w-4 text-primary-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-900">
                          New email from {email.fromName || email.fromEmail}
                        </p>
                        <p className="text-xs text-slate-500 truncate">{email.subject}</p>
                        <p className="text-xs text-slate-400">
                          {email.receivedAt ? formatDistanceToNow(new Date(email.receivedAt), { addSuffix: true }) : 'Recently'}
                        </p>
                      </div>
                    </div>
                  ))}
                  
                  {dashboardData?.recentTransactions?.slice(0, 2).map((transaction: Transaction) => (
                    <div key={transaction.id} className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-emerald-50 rounded-full flex items-center justify-center">
                        <TrendingUp className="h-4 w-4 text-emerald-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-900">Transaction processed</p>
                        <p className="text-xs text-slate-500">
                          {transaction.merchantName || transaction.description} - ${Math.abs(Number(transaction.amount)).toFixed(2)}
                        </p>
                        <p className="text-xs text-slate-400">
                          {formatDistanceToNow(new Date(transaction.date), { addSuffix: true })}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  if (currentTab === 'email') {
    return (
      <div className="w-96 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-slate-900">Inbox</h2>
            <Button size="sm" onClick={onQuickCaptureOpen}>
              <Plus className="h-3 w-3 mr-1" />
              Compose
            </Button>
          </div>
          <div className="flex space-x-2">
            <Badge variant="default" className="bg-primary-50 text-primary-700 border-primary-200">All</Badge>
            <Badge variant="outline" className="text-slate-600 hover:bg-slate-100">Unread</Badge>
            <Badge variant="outline" className="text-slate-600 hover:bg-slate-100">Flagged</Badge>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto">
          {isEmailsLoading ? (
            renderSkeleton()
          ) : (
            <div className="space-y-0">
              {emails?.map((email: Email) => (
                <div
                  key={email.id}
                  className={`p-4 border-b border-slate-100 hover:bg-slate-50 cursor-pointer transition-colors ${
                    selectedEmailId === email.id ? 'bg-slate-50 border-l-4 border-l-primary-600' : ''
                  }`}
                  onClick={() => onEmailSelect(email.id)}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      email.isRead ? 'bg-slate-300' : 'bg-primary-600'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <p className={`text-sm font-medium ${
                          email.isRead ? 'text-slate-700' : 'text-slate-900'
                        }`}>
                          {email.fromName || email.fromEmail}
                        </p>
                        <p className="text-xs text-slate-500">
                          {email.receivedAt ? formatDistanceToNow(new Date(email.receivedAt), { addSuffix: true }) : 'Recently'}
                        </p>
                      </div>
                      <p className={`text-sm mb-1 ${
                        email.isRead ? 'text-slate-700' : 'text-slate-900'
                      }`}>
                        {email.subject || '(No Subject)'}
                      </p>
                      <p className="text-xs text-slate-600 line-clamp-2">
                        {email.snippet || email.body?.substring(0, 100) + '...'}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              
              {emails?.length === 0 && (
                <div className="p-8 text-center text-slate-500">
                  <Mail className="h-12 w-12 mx-auto mb-4 text-slate-300" />
                  <p className="font-medium mb-2">No emails yet</p>
                  <p className="text-sm">Connect your Gmail account to see emails here.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  if (currentTab === 'finance') {
    return (
      <div className="w-96 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6 border-b border-slate-200">
          <h2 className="text-lg font-semibold text-slate-900">Finances</h2>
          <p className="text-sm text-slate-600 mt-1">Your accounts and transactions</p>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {isFinancialLoading ? (
            renderSkeleton()
          ) : (
            <>
              {/* Account Balances */}
              <div>
                <h3 className="text-sm font-medium text-slate-900 mb-3">Account Balances</h3>
                <div className="space-y-3">
                  {financialData?.accounts?.map((account: FinancialAccount) => (
                    <div key={account.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-blue-500 rounded text-white text-xs flex items-center justify-center font-semibold">
                          {account.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-900">{account.name}</p>
                          <p className="text-xs text-slate-500">••••{account.mask || '0000'}</p>
                        </div>
                      </div>
                      <p className="text-sm font-semibold text-slate-900">
                        ${Number(account.balance || 0).toFixed(2)}
                      </p>
                    </div>
                  ))}
                  
                  {financialData?.accounts?.length === 0 && (
                    <div className="text-center py-8 text-slate-500">
                      <TrendingUp className="h-12 w-12 mx-auto mb-4 text-slate-300" />
                      <p className="font-medium mb-2">No accounts connected</p>
                      <p className="text-sm">Connect your bank accounts to see balances here.</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Recent Transactions */}
              <div>
                <h3 className="text-sm font-medium text-slate-900 mb-3">Recent Transactions</h3>
                <div className="space-y-2">
                  {financialData?.transactions?.slice(0, 10).map((transaction: Transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between py-2">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          Number(transaction.amount) >= 0 
                            ? 'bg-green-100' 
                            : 'bg-red-100'
                        }`}>
                          <TrendingUp className={`h-4 w-4 ${
                            Number(transaction.amount) >= 0 
                              ? 'text-green-600' 
                              : 'text-red-600'
                          }`} />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-900">
                            {transaction.merchantName || transaction.description}
                          </p>
                          <p className="text-xs text-slate-500">
                            {formatDistanceToNow(new Date(transaction.date), { addSuffix: true })}
                          </p>
                        </div>
                      </div>
                      <p className={`text-sm font-medium ${
                        Number(transaction.amount) >= 0 
                          ? 'text-green-600' 
                          : 'text-red-600'
                      }`}>
                        {Number(transaction.amount) >= 0 ? '+' : ''}${Number(transaction.amount).toFixed(2)}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  if (currentTab === 'notes') {
    return (
      <div className="w-96 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-slate-900">Quick Notes</h2>
            <Button size="sm" onClick={onQuickCaptureOpen}>
              <Plus className="h-3 w-3 mr-1" />
              New Note
            </Button>
          </div>
          <div className="flex space-x-2">
            <Badge variant="default" className="bg-primary-50 text-primary-700 border-primary-200">All</Badge>
            <Badge variant="outline" className="text-slate-600 hover:bg-slate-100">Active</Badge>
            <Badge variant="outline" className="text-slate-600 hover:bg-slate-100">Done</Badge>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {isNotesLoading ? (
            renderSkeleton()
          ) : (
            <>
              {notes?.map((note: Note) => (
                <div
                  key={note.id}
                  className={`p-4 bg-white border border-slate-200 rounded-lg hover:shadow-sm transition-shadow cursor-pointer ${
                    selectedNoteId === note.id ? 'ring-2 ring-primary-500 border-primary-300' : ''
                  }`}
                  onClick={() => onNoteSelect(note.id)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <button className={`w-4 h-4 border-2 rounded flex items-center justify-center ${
                        note.status === 'done' 
                          ? 'border-emerald-500 bg-emerald-500' 
                          : 'border-slate-300 hover:border-primary-500'
                      } transition-colors`}>
                        {note.status === 'done' && (
                          <CheckCircle2 className="h-3 w-3 text-white" />
                        )}
                      </button>
                      <span className={`inline-block w-2 h-2 rounded-full ${
                        note.priority === 'high' ? 'bg-red-400' :
                        note.priority === 'medium' ? 'bg-amber-400' :
                        'bg-green-400'
                      }`} />
                    </div>
                    <p className="text-xs text-slate-500">
                      {formatDistanceToNow(new Date(note.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                  <p className={`text-sm font-medium mb-1 ${
                    note.status === 'done' ? 'text-slate-700 line-through' : 'text-slate-900'
                  }`}>
                    {note.title || 'Untitled Note'}
                  </p>
                  <p className="text-xs text-slate-600 line-clamp-2">
                    {note.content?.substring(0, 100) + (note.content?.length > 100 ? '...' : '')}
                  </p>
                </div>
              ))}
              
              {notes?.length === 0 && (
                <div className="p-8 text-center text-slate-500">
                  <StickyNote className="h-12 w-12 mx-auto mb-4 text-slate-300" />
                  <p className="font-medium mb-2">No notes yet</p>
                  <p className="text-sm">Create your first note to get started.</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    );
  }

  return null;
}

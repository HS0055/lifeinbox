import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Mail, CreditCard, StickyNote, X } from "lucide-react";

interface OnboardingBannerProps {
  onDismiss: () => void;
  onActionClick: (action: string) => void;
}

export default function OnboardingBanner({ onDismiss, onActionClick }: OnboardingBannerProps) {
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);

  const steps = [
    {
      id: "connect-gmail",
      title: "Connect Gmail",
      description: "Sync your emails for unified inbox management",
      icon: Mail,
      action: "connections",
      color: "bg-red-100 text-red-600 dark:bg-red-900/20 dark:text-red-400"
    },
    {
      id: "create-note",
      title: "Create a Note",
      description: "Capture tasks and ideas quickly",
      icon: StickyNote,
      action: "notes",
      color: "bg-yellow-100 text-yellow-600 dark:bg-yellow-900/20 dark:text-yellow-400"
    },
    {
      id: "connect-bank",
      title: "Connect Bank Account",
      description: "Track finances and spending patterns",
      icon: CreditCard,
      action: "connections",
      color: "bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400"
    }
  ];

  return (
    <Card className="border-2 border-primary/20 bg-gradient-to-r from-primary/5 to-primary/10">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Welcome to LifeInbox!</h3>
            <p className="text-sm text-muted-foreground">
              Get started by completing these simple steps to unify your digital life:
            </p>
          </div>
          <Button variant="ghost" size="sm" onClick={onDismiss}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {steps.map((step) => {
            const Icon = step.icon;
            const isCompleted = completedSteps.includes(step.id);
            
            return (
              <div
                key={step.id}
                className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => onActionClick(step.action)}
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${step.color}`}>
                  {isCompleted ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <Icon className="w-5 h-5" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <p className="text-sm font-medium text-foreground">{step.title}</p>
                    {isCompleted && <Badge variant="secondary" className="text-xs">Done</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground">{step.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-4 p-3 bg-orange-50 dark:bg-orange-950/20 rounded-lg border border-orange-200 dark:border-orange-800">
          <p className="text-sm text-orange-800 dark:text-orange-200">
            <strong>Gmail Connection Issue:</strong> To fix the 403 error, add "aulanely@gmail.com" as a test user in Google Cloud Console → OAuth consent screen → Test users
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
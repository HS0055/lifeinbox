import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Mail,
  StickyNote,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  DollarSign,
  Clock,
} from "lucide-react";

export default function Dashboard() {
  const { data: dashboardData, isLoading } = useQuery({
    queryKey: ["/api/dashboard"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: financialSummary } = useQuery({
    queryKey: ["/api/financial-summary"],
  });

  if (isLoading) {
    return (
      <div className="flex-1 bg-white flex flex-col">
        <div className="p-8 border-b border-slate-200">
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>
        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-4xl space-y-8">
            <div className="grid grid-cols-2 gap-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
            <Skeleton className="h-64" />
            <Skeleton className="h-48" />
          </div>
        </div>
      </div>
    );
  }

  const stats = dashboardData?.stats || {};
  const recentActivity = dashboardData?.recentActivity || {};

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  };

  return (
    <div className="flex-1 bg-white flex flex-col">
      {/* Header */}
      <div className="p-8 border-b border-slate-200">
        <h1 className="text-2xl font-bold text-slate-900 mb-2">
          Welcome back!
        </h1>
        <p className="text-slate-600">
          Here's what's happening across your digital life today.
        </p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-4xl space-y-8">
          
          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-4">
            <Card className="bg-slate-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl font-semibold text-slate-900">
                      {stats.unreadEmails || 0}
                    </p>
                    <p className="text-sm text-slate-600">Unread Emails</p>
                  </div>
                  <Mail className="w-5 h-5 text-primary" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl font-semibold text-slate-900">
                      {stats.activeNotes || 0}
                    </p>
                    <p className="text-sm text-slate-600">Active Notes</p>
                  </div>
                  <StickyNote className="w-5 h-5 text-amber-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Financial Overview */}
          {financialSummary && (
            <Card className="bg-gradient-to-br from-primary/5 to-emerald-50 border-primary/20">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Financial Overview</CardTitle>
                  <Button variant="link" className="text-primary p-0">
                    View Details →
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-6">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-slate-900">
                      {formatCurrency(financialSummary.totalBalance || 0)}
                    </p>
                    <p className="text-sm text-slate-600">Total Balance</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-emerald-600">
                      {formatCurrency(financialSummary.monthlyIncome || 0)}
                    </p>
                    <p className="text-sm text-slate-600">This Month</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-red-600">
                      {formatCurrency(financialSummary.monthlyExpenses || 0)}
                    </p>
                    <p className="text-sm text-slate-600">Expenses</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Priority Emails */}
          {recentActivity.emails && recentActivity.emails.length > 0 && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Recent Emails</CardTitle>
                  <Button variant="link" className="text-primary p-0">
                    View All →
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentActivity.emails.slice(0, 3).map((email: any) => (
                    <div
                      key={email.id}
                      className="flex items-center space-x-4 p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                    >
                      <div className={`w-3 h-3 rounded-full ${email.isRead ? 'bg-slate-300' : 'bg-primary'}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="font-medium text-slate-900 truncate">
                            {email.fromName || email.fromEmail}
                          </p>
                          <p className="text-sm text-slate-500">
                            {email.receivedAt && formatDate(email.receivedAt)}
                          </p>
                        </div>
                        <p className="text-sm text-slate-600 truncate">
                          {email.subject || "No subject"}
                        </p>
                      </div>
                      {!email.isRead && (
                        <Badge variant="secondary" className="bg-primary/10 text-primary">
                          New
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Active Tasks */}
          {recentActivity.notes && recentActivity.notes.length > 0 && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Active Tasks</CardTitle>
                  <Button variant="link" className="text-primary p-0">
                    View All →
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {recentActivity.notes.slice(0, 4).map((note: any) => (
                    <Card key={note.id} className="border border-slate-200">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <button className="w-4 h-4 border-2 border-slate-300 rounded hover:border-primary transition-colors mt-0.5" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-slate-900 mb-1 line-clamp-1">
                              {note.title || note.content.substring(0, 50)}
                            </p>
                            <p className="text-xs text-slate-600 line-clamp-2">
                              {note.title ? note.content.substring(0, 100) : ""}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recent Transactions */}
          {recentActivity.transactions && recentActivity.transactions.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentActivity.transactions.slice(0, 5).map((transaction: any) => (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between py-2"
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          Number(transaction.amount) > 0 
                            ? 'bg-emerald-100' 
                            : 'bg-red-100'
                        }`}>
                          {Number(transaction.amount) > 0 ? (
                            <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <ArrowDownRight className="w-4 h-4 text-red-600" />
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-900">
                            {transaction.merchantName || transaction.description}
                          </p>
                          <p className="text-xs text-slate-500">
                            {transaction.transactionDate && formatDate(transaction.transactionDate)}
                          </p>
                        </div>
                      </div>
                      <p className={`text-sm font-medium ${
                        Number(transaction.amount) > 0 
                          ? 'text-emerald-600' 
                          : 'text-red-600'
                      }`}>
                        {Number(transaction.amount) > 0 ? '+' : ''}
                        {formatCurrency(Number(transaction.amount))}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

        </div>
      </div>
    </div>
  );
}

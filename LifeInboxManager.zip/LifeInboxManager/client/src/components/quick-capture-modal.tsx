import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface QuickCaptureModalProps {
  open: boolean;
  onClose: () => void;
  onOpenQuickCapture: () => void;
}

export default function QuickCaptureModal({ open, onClose }: QuickCaptureModalProps) {
  const { toast } = useToast();
  const [content, setContent] = useState("");
  const [type, setType] = useState<"note" | "task">("note");

  const createNoteMutation = useMutation({
    mutationFn: async (noteData: any) => {
      await apiRequest("POST", "/api/notes", noteData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setContent("");
      onClose();
      toast({
        title: `${type === "note" ? "Note" : "Task"} created`,
        description: `Your ${type} has been saved successfully.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: `Failed to create ${type}.`,
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    if (!content.trim()) return;

    createNoteMutation.mutate({
      content: content.trim(),
      type,
      status: "active",
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      handleSave();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Quick Capture</DialogTitle>
          <p className="text-sm text-muted-foreground">Add a note or task quickly</p>
        </DialogHeader>
        
        <div className="space-y-4">
          <Textarea
            placeholder="What's on your mind?"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyDown={handleKeyPress}
            rows={6}
            className="resize-none"
            autoFocus
          />
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant={type === "note" ? "secondary" : "outline"}
                onClick={() => setType("note")}
                className="text-xs"
              >
                Note
              </Button>
              <Button
                size="sm"
                variant={type === "task" ? "secondary" : "outline"}
                onClick={() => setType("task")}
                className="text-xs"
              >
                Task
              </Button>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button 
                onClick={handleSave}
                disabled={!content.trim() || createNoteMutation.isPending}
              >
                {createNoteMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </div>
          </div>
        </div>
        
        <div className="text-xs text-muted-foreground">
          <p>Tip: Press Cmd+Enter (Mac) or Ctrl+Enter (Windows) to save quickly</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

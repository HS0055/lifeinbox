import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Moon, Sun, Play, Shield, Zap, Brain, Mail, DollarSign, MessageSquare, ArrowUp, Check } from "lucide-react";

export default function Landing() {
  const [darkMode, setDarkMode] = useState(true);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [scrollProgress, setScrollProgress] = useState(0);
  const [showFixedCTA, setShowFixedCTA] = useState(false);
  const cubeRef = useRef<HTMLDivElement>(null);
  const heroRef = useRef<HTMLDivElement>(null);

  // Konami code easter egg
  const [konamiSequence, setKonamiSequence] = useState<string[]>([]);
  const konamiCode = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'KeyB', 'KeyA'];
  const [showEasterEgg, setShowEasterEgg] = useState(false);

  // Mouse tracking for parallax
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 2 - 1,
        y: (e.clientY / window.innerHeight) * 2 - 1,
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Scroll progress tracking
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = scrollTop / docHeight;
      setScrollProgress(progress);
      setShowFixedCTA(progress > 0.5);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Konami code detection
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const newSequence = [...konamiSequence, e.code].slice(-10);
      setKonamiSequence(newSequence);
      
      if (newSequence.join(',') === konamiCode.join(',')) {
        setShowEasterEgg(true);
        setTimeout(() => setShowEasterEgg(false), 3000);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [konamiSequence]);

  // Apply dark mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const HeroSection = () => (
    <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-slate-900 to-indigo-900">
        {showEasterEgg && (
          <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-cyan-900 animate-pulse" />
        )}
      </div>
      
      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-blue-400 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              transform: `translate(${mousePosition.x * (i % 3) * 10}px, ${mousePosition.y * (i % 3) * 10}px)`,
              transition: 'transform 0.3s ease-out',
            }}
          />
        ))}
      </div>

      {/* 3D Cube */}
      <div
        ref={cubeRef}
        className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
        style={{
          transform: `translate(-50%, -50%) rotateX(${mousePosition.y * 10}deg) rotateY(${mousePosition.x * 10}deg) rotateZ(${Date.now() / 100 % 360}deg)`,
          transition: 'transform 0.1s ease-out',
        }}
      >
        <div className="relative w-32 h-32 transform-gpu">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg opacity-80 animate-pulse shadow-2xl shadow-blue-500/50" />
          <div className="absolute inset-2 bg-black/20 rounded backdrop-blur-sm border border-blue-400/30" />
        </div>
      </div>

      {/* Hero content */}
      <div className="relative z-10 text-center max-w-6xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-6xl md:text-8xl font-bold font-mono bg-gradient-to-r from-white via-blue-200 to-purple-300 bg-clip-text text-transparent mb-4 leading-tight">
            One Dashboard.<br />Zero Tabs.
          </h1>
          <p className="text-xl md:text-2xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
            Emails, money, and AI insights — fused together in real time.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button
            onClick={() => window.location.href = "/api/login"}
            size="lg"
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 border-0"
            style={{
              transform: `perspective(1000px) rotateX(${mousePosition.y * 2}deg) rotateY(${mousePosition.x * 2}deg)`,
            }}
          >
            Join Private Beta
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 px-6 py-4 rounded-xl"
          >
            <Play className="w-4 h-4 mr-2" />
            Watch 60-sec Demo
          </Button>
        </div>
      </div>

      {/* Dark mode toggle */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setDarkMode(!darkMode)}
        className="absolute top-4 right-4 text-white hover:bg-white/10"
      >
        {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
      </Button>

      {/* Progress indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="flex items-center space-x-4 text-slate-400 text-sm">
          <div className={`flex items-center space-x-2 ${scrollProgress > 0.1 ? 'text-blue-400' : ''}`}>
            <div className={`w-3 h-3 rounded-full border-2 ${scrollProgress > 0.1 ? 'bg-blue-400 border-blue-400' : 'border-slate-400'}`} />
            <span>Connect</span>
          </div>
          <div className="w-8 h-px bg-slate-600" />
          <div className={`flex items-center space-x-2 ${scrollProgress > 0.4 ? 'text-blue-400' : ''}`}>
            <div className={`w-3 h-3 rounded-full border-2 ${scrollProgress > 0.4 ? 'bg-blue-400 border-blue-400' : 'border-slate-400'}`} />
            <span>Master Feed</span>
          </div>
          <div className="w-8 h-px bg-slate-600" />
          <div className={`flex items-center space-x-2 ${scrollProgress > 0.7 ? 'text-blue-400' : ''}`}>
            <div className={`w-3 h-3 rounded-full border-2 ${scrollProgress > 0.7 ? 'bg-blue-400 border-blue-400' : 'border-slate-400'}`} />
            <span>Ask AI</span>
          </div>
        </div>
      </div>
    </section>
  );

  const TechShowcase = () => (
    <section className="py-20 bg-gradient-to-b from-slate-900 to-black">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Built for the Future
          </h2>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            Enterprise-grade technology stack designed for scale, security, and speed.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              icon: <Mail className="w-8 h-8" />,
              title: "Gmail + Plaid",
              subtitle: "Real-time OAuth sync",
              description: "Secure, encrypted connections to your email and financial accounts with automatic refresh tokens.",
              gradient: "from-blue-500 to-cyan-500"
            },
            {
              icon: <Brain className="w-8 h-8" />,
              title: "AI-Powered RAG",
              subtitle: "GPT-4o answers in seconds",
              description: "Vector embeddings and semantic search provide contextual AI responses across all your data.",
              gradient: "from-purple-500 to-pink-500"
            },
            {
              icon: <Shield className="w-8 h-8" />,
              title: "Bank-Grade Security",
              subtitle: "AES-256 encrypted tokens",
              description: "Military-grade encryption ensures your sensitive data remains private and secure.",
              gradient: "from-emerald-500 to-teal-500"
            }
          ].map((feature, index) => (
            <Card
              key={index}
              className="bg-white/5 backdrop-blur-sm border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105 hover:-translate-y-2"
              style={{
                animationDelay: `${index * 200}ms`,
              }}
            >
              <CardContent className="p-8">
                <div className={`w-16 h-16 rounded-xl bg-gradient-to-r ${feature.gradient} flex items-center justify-center mb-6 text-white`}>
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">{feature.title}</h3>
                <p className="text-blue-400 text-sm font-semibold mb-4">{feature.subtitle}</p>
                <p className="text-slate-400 leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );

  const WhyItMatters = () => (
    <section className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">
              Why It Matters
            </h2>
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-emerald-500/20 to-transparent p-6 rounded-xl border border-emerald-500/20">
                <h3 className="text-xl font-semibold text-emerald-400 mb-2">Stop Context Switching</h3>
                <p className="text-slate-300">Average knowledge worker checks 36 different apps daily. LifeInbox cuts that to 1.</p>
              </div>
              <div className="bg-gradient-to-r from-blue-500/20 to-transparent p-6 rounded-xl border border-blue-500/20">
                <h3 className="text-xl font-semibold text-blue-400 mb-2">AI-Powered Insights</h3>
                <p className="text-slate-300">Get instant answers about your digital life without manual searching or data analysis.</p>
              </div>
              <div className="bg-gradient-to-r from-purple-500/20 to-transparent p-6 rounded-xl border border-purple-500/20">
                <h3 className="text-xl font-semibold text-purple-400 mb-2">Bank-Level Security</h3>
                <p className="text-slate-300">Your data stays encrypted and private. We never store plain-text credentials.</p>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-slate-400 text-sm ml-4">LifeInbox AI Chat</span>
              </div>
              <div className="space-y-4">
                <div className="bg-blue-600 text-white p-3 rounded-lg max-w-xs ml-auto">
                  How much did I spend on ads last week?
                </div>
                <div className="bg-slate-700 text-slate-100 p-3 rounded-lg max-w-sm">
                  You spent $2,847 on advertising last week across Google Ads ($1,820) and Facebook Ads ($1,027). That's 23% above your weekly average.
                </div>
                <div className="flex items-center space-x-2 text-slate-400 text-sm">
                  <Zap className="w-4 h-4" />
                  <span>Answered in 0.8 seconds</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );

  const SocialProof = () => (
    <section className="py-20 bg-gradient-to-b from-black to-slate-900">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
          Trusted by Forward-Thinking Teams
        </h2>
        <p className="text-slate-400 mb-12">Join hundreds of professionals who've streamlined their workflow</p>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
          {[
            { stat: "40%", label: "WAU by Week 4" },
            { stat: "99%", label: "Sync Success" },
            { stat: "2.3s", label: "Avg Response" },
            { stat: "500+", label: "Beta Users" }
          ].map((item, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-2">
                {item.stat}
              </div>
              <div className="text-slate-400 text-sm">{item.label}</div>
            </div>
          ))}
        </div>

        <div className="flex justify-center items-center space-x-8 opacity-60 hover:opacity-100 transition-opacity">
          {['Stripe', 'Figma', 'Linear', 'Notion'].map((company, index) => (
            <div key={index} className="text-slate-500 font-semibold text-lg hover:text-white transition-colors">
              {company}
            </div>
          ))}
        </div>
      </div>
    </section>
  );

  return (
    <div className="min-h-screen bg-black text-white relative overflow-x-hidden">
      <HeroSection />
      <TechShowcase />
      <WhyItMatters />
      <SocialProof />

      {/* Fixed CTA Banner */}
      {showFixedCTA && (
        <div className="fixed bottom-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-sm border-t border-white/10 p-4">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div>
              <p className="text-white font-semibold">Ready to reclaim your focus?</p>
              <p className="text-slate-400 text-sm">Join the productivity revolution</p>
            </div>
            <Button
              onClick={() => window.location.href = "/api/login"}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-lg font-semibold"
            >
              Request Access
            </Button>
          </div>
        </div>
      )}

      {/* Easter Egg Toast */}
      {showEasterEgg && (
        <div className="fixed top-4 right-4 z-50 bg-gradient-to-r from-purple-600 to-pink-600 text-white p-4 rounded-lg shadow-2xl animate-bounce">
          <div className="flex items-center space-x-2">
            <Check className="w-5 h-5" />
            <span className="font-semibold">Level Unlocked! 🌌</span>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-black border-t border-slate-800 py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-bold text-white mb-4">LifeInbox</h3>
              <p className="text-slate-400 mb-4">
                The future of productivity is unified, intelligent, and secure.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-slate-400 hover:text-white transition-colors">Twitter</a>
                <a href="#" className="text-slate-400 hover:text-white transition-colors">Discord</a>
                <a href="#" className="text-slate-400 hover:text-white transition-colors">GitHub</a>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-8">
              <div>
                <h4 className="text-white font-semibold mb-4">Product</h4>
                <ul className="space-y-2 text-slate-400">
                  <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                  <li><a href="#" className="hover:text-white transition-colors">Security</a></li>
                  <li><a href="#" className="hover:text-white transition-colors">API</a></li>
                </ul>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-4">Company</h4>
                <ul className="space-y-2 text-slate-400">
                  <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                  <li><a href="#" className="hover:text-white transition-colors">Privacy</a></li>
                  <li><a href="#" className="hover:text-white transition-colors">Terms</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
            <p>© 2025 LifeInbox. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

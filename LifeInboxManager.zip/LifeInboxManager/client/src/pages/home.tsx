import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/sidebar";
import Dashboard from "@/components/dashboard";
import EmailView from "@/components/email-view";
import FinanceView from "@/components/finance-view";
import NotesView from "@/components/notes-view";
import AiChatModal from "@/components/ai-chat-modal";
import QuickCaptureModal from "@/components/quick-capture-modal";

export type TabType = "dashboard" | "email" | "finance" | "notes";

export default function Home() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [currentTab, setCurrentTab] = useState<TabType>("dashboard");
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [quickCaptureOpen, setQuickCaptureOpen] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // ⌘J or Ctrl+J for quick capture
      if ((e.metaKey || e.ctrlKey) && e.key === "j") {
        e.preventDefault();
        setQuickCaptureOpen(true);
      }
      
      // Escape to close modals
      if (e.key === "Escape") {
        setAiChatOpen(false);
        setQuickCaptureOpen(false);
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4">
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
          </div>
          <p className="text-slate-600">Loading LifeInbox...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  const renderContent = () => {
    switch (currentTab) {
      case "dashboard":
        return <Dashboard />;
      case "email":
        return <EmailView />;
      case "finance":
        return <FinanceView />;
      case "notes":
        return <NotesView />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        onAiChatOpen={() => setAiChatOpen(true)}
      />
      
      <div className="flex-1 flex overflow-hidden">
        {renderContent()}
      </div>

      <AiChatModal
        isOpen={aiChatOpen}
        onClose={() => setAiChatOpen(false)}
      />

      <QuickCaptureModal
        isOpen={quickCaptureOpen}
        onClose={() => setQuickCaptureOpen(false)}
        onSuccess={() => setQuickCaptureOpen(false)}
      />
    </div>
  );
}

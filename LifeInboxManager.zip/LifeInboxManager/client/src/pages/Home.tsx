import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/Sidebar";
import ContentList from "@/components/ContentList";
import DetailView from "@/components/DetailView";
import ConnectionsPanel from "@/components/connections-panel";

export type TabType = 'dashboard' | 'email' | 'finance' | 'notes' | 'connections';

export default function Home() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [currentTab, setCurrentTab] = useState<TabType>('connections');
  const [selectedEmailId, setSelectedEmailId] = useState<number | null>(null);
  const [selectedNoteId, setSelectedNoteId] = useState<number | null>(null);
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [quickCaptureOpen, setQuickCaptureOpen] = useState(false);

  const exchangeGmailCode = useMutation({
    mutationFn: async (code: string) => {
      console.log('Frontend: Starting Gmail token exchange with code:', code.substring(0, 10) + '...');
      const response = await fetch('/api/gmail/exchange', {
        method: 'POST',
        body: JSON.stringify({ code }),
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Token exchange failed');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      console.log('Frontend: Gmail token exchange successful:', data);
      toast({
        title: "Gmail Connected",
        description: "Your Gmail account has been successfully connected and is syncing.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setCurrentTab('connections');
    },
    onError: (error) => {
      console.error("Frontend: Gmail connection error:", error);
      toast({
        title: "Connection Failed",
        description: "Failed to connect Gmail. Check console for details.",
        variant: "destructive",
      });
    },
  });

  // Check for Gmail OAuth code in URL parameters with improved handling
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const gmailCode = urlParams.get('gmail_code');
    const error = urlParams.get('error');
    const callback = urlParams.get('callback');
    
    console.log('OAuth URL check:', { 
      gmailCode: gmailCode ? gmailCode.substring(0, 10) + '...' : null, 
      error, 
      callback,
      isAuthenticated, 
      isLoading,
      isPending: exchangeGmailCode.isPending 
    });
    
    if (gmailCode && isAuthenticated && !exchangeGmailCode.isPending) {
      console.log('Gmail OAuth code detected, starting token exchange...');
      
      // Clear URL immediately to prevent reprocessing
      window.history.replaceState({}, '', window.location.pathname);
      
      // Start token exchange
      exchangeGmailCode.mutate(gmailCode);
      
    } else if (gmailCode && !isAuthenticated && !isLoading) {
      console.log('Gmail code found but user not authenticated. Retrying authentication...');
      // Wait for auth to complete, then retry
      setTimeout(() => {
        if (window.location.search.includes('gmail_code')) {
          window.location.reload();
        }
      }, 2000);
      
    } else if (error) {
      console.error('OAuth error received:', error);
      toast({
        title: "Connection Failed",
        description: `Gmail connection failed: ${error}`,
        variant: "destructive",
      });
      // Clean up URL
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [isAuthenticated, isLoading, exchangeGmailCode, toast]);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeydown = (e: KeyboardEvent) => {
      // ⌘J or Ctrl+J for quick capture
      if ((e.metaKey || e.ctrlKey) && e.key === 'j') {
        e.preventDefault();
        setQuickCaptureOpen(true);
      }
      
      // Escape to close modals
      if (e.key === 'Escape') {
        setAiChatOpen(false);
        setQuickCaptureOpen(false);
      }
    };

    document.addEventListener('keydown', handleKeydown);
    return () => document.removeEventListener('keydown', handleKeydown);
  }, []);

  const handleTabChange = (tab: TabType) => {
    setCurrentTab(tab);
    setSelectedEmailId(null);
    setSelectedNoteId(null);
  };

  const handleEmailSelect = (emailId: number) => {
    setSelectedEmailId(emailId);
    setCurrentTab('email');
  };

  const handleNoteSelect = (noteId: number) => {
    setSelectedNoteId(noteId);
    setCurrentTab('notes');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Loading LifeInbox...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar 
        currentTab={currentTab} 
        onTabChange={handleTabChange}
        onAiChatOpen={() => setAiChatOpen(true)}
      />
      
      <div className="flex-1 flex overflow-hidden">
        {currentTab === 'connections' ? (
          <div className="flex-1 p-6 overflow-auto">
            <ConnectionsPanel />
          </div>
        ) : (
          <>
            <ContentList 
              currentTab={currentTab}
              selectedEmailId={selectedEmailId}
              selectedNoteId={selectedNoteId}
              onEmailSelect={handleEmailSelect}
              onNoteSelect={handleNoteSelect}
              onQuickCaptureOpen={() => setQuickCaptureOpen(true)}
            />
            
            <DetailView 
              currentTab={currentTab}
              selectedEmailId={selectedEmailId}
              selectedNoteId={selectedNoteId}
              onTabChange={handleTabChange}
              onEmailSelect={handleEmailSelect}
              onNoteSelect={handleNoteSelect}
            />
          </>
        )}
      </div>

      {/* Modals would be rendered here */}
    </div>
  );
}

import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import ConnectionsPanel from "@/components/connections-panel";

export default function Connections() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  const exchangeGmailCode = useMutation({
    mutationFn: async (code: string) => {
      const response = await apiRequest("POST", "/api/gmail/exchange", { code });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Gmail Connected",
        description: "Your Gmail account has been successfully connected and is syncing.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
    onError: (error) => {
      console.error("Gmail connection error:", error);
      toast({
        title: "Connection Failed",
        description: "Failed to connect Gmail. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Check for Gmail OAuth code in URL parameters
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const gmailCode = urlParams.get('gmail_code');
    
    if (gmailCode && isAuthenticated) {
      console.log('Gmail OAuth code detected, exchanging for tokens...');
      exchangeGmailCode.mutate(gmailCode);
      // Clean up URL
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [isAuthenticated, exchangeGmailCode]);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Account Connections</h1>
          <p className="text-slate-600">Connect your Gmail and bank accounts to unify your digital life</p>
        </div>
        
        <ConnectionsPanel />
      </div>
    </div>
  );
}
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, Image as ImageIcon, Download, Sparkles } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function AISummaryInfographic() {
  const [prompt, setPrompt] = useState("");
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch user's email data for context
  const { data: emails = [] } = useQuery({
    queryKey: ["/api/emails"],
  });

  const { data: urgentEmails = [] } = useQuery({
    queryKey: ["/api/emails/urgent"],
  });

  const generateInfographic = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setError(null);
    
    try {
      console.log("Starting infographic generation");
      console.log("Sending request with prompt:", prompt);
      
      const response = await apiRequest("/api/ai/generate-infographic", "POST", {
        prompt: prompt,
        context: {
          emailCount: emails.length,
          urgentCount: urgentEmails.length,
          topics: extractTopics(emails)
        }
      });
      
      console.log("Received response:", response);
      
      if (response?.url) {
        setGeneratedImage(response.url);
        console.log("Image URL set:", response.url);
      } else {
        throw new Error("No image URL received from API");
      }
    } catch (err: any) {
      console.error("Infographic generation error:", err);
      setError(err.message || "Failed to generate infographic");
    } finally {
      setIsGenerating(false);
    }
  };

  const extractTopics = (emails: any[]) => {
    const topics = new Set();
    emails.forEach(email => {
      if (email.topic) topics.add(email.topic);
      if (email.category) topics.add(email.category);
    });
    return Array.from(topics);
  };

  const suggestedPrompts = [
    "Create a modern inbox summary dashboard with email statistics and priorities",
    "Design an infographic showing email trends and urgent items for today",
    "Generate a productivity report visualization with email analytics",
    "Create a clean email management dashboard with color-coded priorities"
  ];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2">AI Infographic Generator</h1>
        <p className="text-muted-foreground">
          Create visual summaries of your email data and productivity insights
        </p>
      </div>

      {/* Email Context Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Your Email Context
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600">{emails.length}</div>
              <div className="text-sm text-muted-foreground">Total Emails</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-orange-600">{urgentEmails.length}</div>
              <div className="text-sm text-muted-foreground">Urgent Items</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">{extractTopics(emails).length}</div>
              <div className="text-sm text-muted-foreground">Topics</div>
            </div>
          </div>
          
          {extractTopics(emails).length > 0 && (
            <div className="mt-4">
              <p className="text-sm font-medium mb-2">Detected Topics:</p>
              <div className="flex flex-wrap gap-2">
                {extractTopics(emails).slice(0, 8).map((topic, index) => (
                  <Badge key={index} variant="secondary">{topic}</Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Prompt Input */}
      <Card>
        <CardHeader>
          <CardTitle>Describe Your Infographic</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Describe what kind of infographic you want to create..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="min-h-[100px]"
          />
          
          <div className="space-y-2">
            <p className="text-sm font-medium">Suggested Prompts:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {suggestedPrompts.map((suggestion, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => setPrompt(suggestion)}
                  className="text-left justify-start h-auto p-3"
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>

          <Button 
            onClick={generateInfographic}
            disabled={!prompt.trim() || isGenerating}
            className="w-full"
          >
            {isGenerating ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <ImageIcon className="h-4 w-4 mr-2" />
                Generate Infographic
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Error Display */}
      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <p className="text-red-800">Error: {error}</p>
            <p className="text-sm text-red-600 mt-2">
              Please try again with a different prompt or check your connection.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Generated Image */}
      {generatedImage && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Generated Infographic
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center">
              <img 
                src={generatedImage} 
                alt="Generated infographic"
                className="max-w-full h-auto rounded-lg shadow-lg"
                onError={() => setError("Failed to load generated image")}
              />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
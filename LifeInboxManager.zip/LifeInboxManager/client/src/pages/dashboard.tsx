import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/sidebar";
import EmailList from "@/components/email-list";
import EmailDetail from "@/components/email-detail";
import FinanceView from "@/components/finance-view";
import NotesView from "@/components/notes-view";
import ConnectionsPanel from "@/components/connections-panel";
import OnboardingBanner from "@/components/onboarding-banner";
import AISummaryInfographic from "@/components/ai-summary-infographic";
import EnhancedFocusSummary from "@/components/enhanced-focus-summary";
import ConversationalAIChat from "@/components/conversational-ai-chat";
import AIPriorityInbox from "@/components/ai-priority-inbox";
import PriorityInbox from "@/components/priority-inbox";
import { UrgentEmailBanner } from "@/components/urgent-email-banner";
import CommunicationAnalytics from "@/components/communication-analytics";
import EnhancedProductivityStreaks from "@/components/enhanced-productivity-streaks";
import SmartBatchActions from "@/components/smart-batch-actions";
import FeedbackButton from "@/components/feedback-button";
import AIChatModal from "@/components/ai-chat-modal";
import QuickCaptureModal from "@/components/quick-capture-modal";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [currentTab, setCurrentTab] = useState("dashboard");
  const [selectedEmailId, setSelectedEmailId] = useState<number | null>(null);
  const [selectedNoteId, setSelectedNoteId] = useState<number | null>(null);
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [quickCaptureOpen, setQuickCaptureOpen] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(true);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: dashboardData, isLoading: dashboardLoading } = useQuery({
    queryKey: ["/api/dashboard"],
    enabled: isAuthenticated,
  });

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'j') {
        e.preventDefault();
        setQuickCaptureOpen(true);
      }
      if (e.key === 'Escape') {
        setAiChatOpen(false);
        setQuickCaptureOpen(false);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (isLoading || !isAuthenticated) {
    return <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
        <p className="text-muted-foreground">Loading...</p>
      </div>
    </div>;
  }

  const renderMainContent = () => {
    switch (currentTab) {
      case "dashboard":
        return (
          <div className="flex-1 bg-white flex flex-col">
            <div className="p-8 border-b border-border">
              <h1 className="text-2xl font-bold text-foreground mb-2">Welcome back!</h1>
              <p className="text-muted-foreground">Here's what's happening across your digital life today.</p>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8">
              <div className="max-w-4xl space-y-8">
                
                {/* Onboarding Banner */}
                {showOnboarding && (
                  <OnboardingBanner 
                    onDismiss={() => setShowOnboarding(false)}
                    onActionClick={(action) => {
                      setCurrentTab(action);
                      if (action === "notes") {
                        setQuickCaptureOpen(true);
                      }
                    }}
                  />
                )}
                
                {/* Smart Urgent Email Detection Banner */}
                <UrgentEmailBanner />
                
                {/* Enhanced Focus Summary */}
                <EnhancedFocusSummary />

                {/* Communication Analytics */}
                <CommunicationAnalytics />

                {/* Productivity Streaks */}
                <EnhancedProductivityStreaks />

                {/* Smart Batch Actions */}
                <SmartBatchActions />

                {/* Conversational AI Chat */}
                <ConversationalAIChat />

                {/* Priority Emails */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-foreground">Priority Emails</h3>
                    <button 
                      onClick={() => setCurrentTab('email')}
                      className="text-sm text-primary hover:text-primary/80"
                    >
                      View All →
                    </button>
                  </div>
                  {dashboardData?.recentEmails?.length > 0 ? (
                    <div className="space-y-3">
                      {dashboardData.recentEmails.slice(0, 3).map((email: any) => (
                        <div 
                          key={email.id}
                          onClick={() => {
                            setSelectedEmailId(email.id);
                            setCurrentTab('email');
                          }}
                          className="flex items-center space-x-4 p-4 bg-muted/50 rounded-lg hover:bg-muted transition-colors cursor-pointer"
                        >
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-sm font-medium">
                            {(email.fromName || email.fromEmail || "?").charAt(0).toUpperCase()}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className="font-medium text-foreground">
                                {email.fromName || email.fromEmail?.split('@')[0] || "Email Contact"}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {email.receivedAt ? new Date(email.receivedAt).toLocaleDateString() : 'Recent'}
                              </p>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">{email.subject || "No Subject"}</p>
                            <p className="text-xs text-muted-foreground/60">{email.fromEmail}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      No emails yet. Connect your Gmail account to get started.
                    </div>
                  )}
                </div>

                {/* Active Tasks */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-foreground">Active Tasks</h3>
                    <button 
                      onClick={() => setCurrentTab('notes')}
                      className="text-sm text-primary hover:text-primary/80"
                    >
                      View All →
                    </button>
                  </div>
                  {dashboardData?.recentNotes?.length > 0 ? (
                    <div className="grid grid-cols-2 gap-4">
                      {dashboardData.recentNotes.map((note: any) => (
                        <div 
                          key={note.id}
                          onClick={() => {
                            setSelectedNoteId(note.id);
                            setCurrentTab('notes');
                          }}
                          className="p-4 border border-border rounded-lg hover:shadow-sm transition-shadow cursor-pointer"
                        >
                          <div className="flex items-start space-x-3">
                            <button className="w-4 h-4 border-2 border-muted-foreground rounded hover:border-primary transition-colors mt-0.5"></button>
                            <div className="flex-1">
                              <p className="text-sm font-medium text-foreground mb-1">{note.title || note.content?.slice(0, 50)}</p>
                              <p className="text-xs text-muted-foreground line-clamp-2">{note.content}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      No active tasks. Create your first note to get started.
                    </div>
                  )}
                </div>

              </div>
            </div>
          </div>
        );
      
      case "email":
        return (
          <div className="flex flex-1 overflow-hidden">
            <EmailList selectedEmailId={selectedEmailId} onSelectEmail={setSelectedEmailId} />
            <EmailDetail emailId={selectedEmailId} />
          </div>
        );
      
      case "finance":
        return <FinanceView />;
      
      case "notes":
        return <NotesView selectedNoteId={selectedNoteId} onSelectNote={setSelectedNoteId} />;
      
      case "priority-inbox":
        return (
          <div className="flex-1 p-6 overflow-y-auto">
            <div className="max-w-6xl mx-auto">
              <PriorityInbox />
            </div>
          </div>
        );

      case "ai-inbox":
        return (
          <div className="flex-1 p-6 overflow-y-auto">
            <div className="max-w-6xl mx-auto">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-foreground mb-2">AI Priority Inbox</h1>
                <p className="text-muted-foreground">Intelligent email filtering, priority detection, and conversational inbox management</p>
              </div>
              <AIPriorityInbox />
            </div>
          </div>
        );
      
      case "connections":
        return (
          <div className="flex-1 p-6 overflow-y-auto">
            <div className="max-w-4xl mx-auto">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-foreground mb-2">Account Connections</h1>
                <p className="text-muted-foreground">Connect your Gmail and bank accounts to unify your digital life</p>
              </div>
              <ConnectionsPanel />
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar 
        currentTab={currentTab} 
        onTabChange={setCurrentTab}
        onOpenAIChat={() => setAiChatOpen(true)}
        stats={{
          unreadEmailCount: dashboardData?.stats?.unreadEmailCount || 0,
          activeNotesCount: dashboardData?.stats?.activeNotesCount || 0,
        }}
      />
      
      {renderMainContent()}

      {aiChatOpen && (
        <AIChatModal open={aiChatOpen} onClose={() => setAiChatOpen(false)} />
      )}

      {quickCaptureOpen && (
        <QuickCaptureModal 
          open={quickCaptureOpen} 
          onClose={() => setQuickCaptureOpen(false)}
          onOpenQuickCapture={() => setQuickCaptureOpen(true)}
        />
      )}

      <FeedbackButton />
    </div>
  );
}

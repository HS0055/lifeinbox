import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, DollarSign, StickyNote, Sparkles, ArrowRight } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-primary-600 rounded-xl flex items-center justify-center">
              <Mail className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-slate-900">LifeInbox</h1>
          </div>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-8">
            Your scattered digital life—emails, finances and quick notes—unified into one clean, AI-assisted workspace.
          </p>
          <Button 
            size="lg" 
            className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-3 text-lg"
            onClick={() => window.location.href = '/api/login'}
          >
            Get Started <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                <Mail className="h-6 w-6 text-primary-600" />
              </div>
              <CardTitle>Unified Email</CardTitle>
              <CardDescription>
                Connect Gmail and manage all your emails in one clean interface with smart prioritization.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                <DollarSign className="h-6 w-6 text-emerald-600" />
              </div>
              <CardTitle>Financial Overview</CardTitle>
              <CardDescription>
                Track account balances, recent transactions, and spending patterns all in one place.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mb-4">
                <StickyNote className="h-6 w-6 text-amber-600" />
              </div>
              <CardTitle>Quick Notes</CardTitle>
              <CardDescription>
                Capture thoughts and tasks instantly with global shortcuts and smart organization.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* AI Assistant */}
        <Card className="border-0 shadow-xl bg-gradient-to-r from-emerald-50 to-blue-50">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-emerald-500 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="text-2xl">AI-Powered Assistant</CardTitle>
            <CardDescription className="text-lg">
              Ask LifeInbox anything about your emails, transactions, or notes. Get instant answers and smart suggestions.
            </CardDescription>
          </CardHeader>
        </Card>

        {/* CTA */}
        <div className="text-center mt-16">
          <p className="text-slate-600 mb-6">
            Ready to unify your digital life? Get started in under 3 minutes.
          </p>
          <Button 
            size="lg" 
            variant="outline"
            className="border-primary-600 text-primary-600 hover:bg-primary-50"
            onClick={() => window.location.href = '/api/login'}
          >
            Sign in to continue
          </Button>
        </div>
      </div>
    </div>
  );
}
